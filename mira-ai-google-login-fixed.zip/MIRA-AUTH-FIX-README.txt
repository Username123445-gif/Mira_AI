MIRA AI - GOOGLE SIGN-IN FIX

Changes made:
- Replaced the Lovable Cloud OAuth call with Supabase's native Google OAuth.
- Removed the old Lovable OAuth adapter that called /~oauth/initiate.
- Updated the local .env Supabase URL and publishable key to the new project values.

IMPORTANT - VERCEL ENVIRONMENT VARIABLES
Set ALL FOUR variables below in Vercel for Production, Preview, and Development:
- VITE_SUPABASE_URL = https://syodxtkcccndmsvcqxdy.supabase.co
- VITE_SUPABASE_PUBLISHABLE_KEY = your Supabase publishable key
- SUPABASE_URL = https://syodxtkcccndmsvcqxdy.supabase.co
- SUPABASE_PUBLISHABLE_KEY = your Supabase publishable key

The VITE_ variables are used by the browser. The non-VITE variables are used by server-side code.
Use Config visibility for the VITE_ variables. Do not expose any service-role or secret key.

SUPABASE AUTH URL SETTINGS
In Supabase > Authentication > URL Configuration:
- Site URL: https://mira-ai-assistance-d535c1xfn-mira-ai1.vercel.app
- Add this Redirect URL:
  https://mira-ai-assistance-d535c1xfn-mira-ai1.vercel.app/login

GOOGLE CLOUD
- Authorized JavaScript origin:
  https://mira-ai-assistance-d535c1xfn-mira-ai1.vercel.app
- Authorized redirect URI:
  https://syodxtkcccndmsvcqxdy.supabase.co/auth/v1/callback

IMPORTANT LIMITATION
This fixes the Google sign-in code path only. The project still uses Lovable services for AI responses, image generation, transcription, and parts of billing, and its new Supabase database still needs the app's schema/data and required server keys migrated before all Mira AI features can work independently of Lovable.
