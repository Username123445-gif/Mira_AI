# Mira AI roadmap

- [ ] Add optional reply/image notifications with saved on/off controls in Settings; verify permissions, persistence and background completion.

- [x] Add a live countdown bar at the top of the home page and chat showing time left until Mira AI 1.1 launches on January 1, 2027; it hides itself once that moment passes. Checked signed in on desktop and phone with no page errors

- [x] Refresh the Mira 1.1 sidebar tab and release preview with feature categories, existing artwork, and clearer upcoming-release styling; keep all plan promotions removed

- [x] Repair chat creation, preserve drafts while busy, add failed-message retry, and verify saved replies and follow-ups
- [x] Repair chat/gallery/delete-all confirmation pop-ups; removed update announcement stays off
- [x] Verify signed-in desktop/mobile chats and run all regression checks

- [x] Add a named welcome-back greeting and verify returning chats and name updates
- [x] Check returning-user flow: name save/reload and desktop/mobile passed; no runtime errors found

- [x] Brand + design system for Mira AI using the uploaded logo (colors, fonts)
- [x] Streaming chat with Mira (Lovable AI)
- [x] Separate chats: thread list, New chat, /chat/$threadId pages
- [x] Sign-in accounts; chats saved per user in Lovable Cloud
- [x] Page titles/descriptions
- [x] Fix account creation on preview (Google sign-in was switched off; now on)
- [x] Fix any other bugs found
- [x] Add LIVE AI: Mira searches the web for up-to-date answers
- [x] Settings page (answer style, about you, account)
- [x] Plans (Free / Plus / Pro) that give better answers; free to switch for now
- [x] Enable built-in payments — test and live accounts connected; live payments require identity verification and product review
- [x] Create Plus ($8/month) and Pro ($20/month) subscription products
- [x] Connect checkout, billing management, and payment-confirmed plan access
- [x] Verify Plus/Pro checkout opens, mobile layout, and payment access rules
- [x] Apply every listed Plus/Pro benefit only to the account with a verified paid subscription
- [ ] Complete test purchase and verify payment confirmation through paid chat — checkout payment form requires manual test completion
- [x] Add yearly Plus ($80/yr) and Pro ($200/yr) billing with a monthly/yearly toggle in Settings and on Pricing
- [x] Add Mira Ultra top tier ($49/mo, $490/yr) above Pro — confirmed by owner
- [x] Clarify credits: the user meant app creators' Lovable workspace credits, not customer credits; no customer Credits tab or spending rules added
- [x] Retire the unused customer credit ledger created before clarification; no customer credit grants, purchases or limits were added

- [ ] Mira in App Store / Google Play — installable groundwork done; store packaging needs owner developer accounts (Apple $99/yr, Google $25)
- [x] Bump Mira's version to v0.2 Beta everywhere from one place; verified header, home, chat, Settings and What's New
- [x] Update the update pop-up for v0.2 Beta and verify it appears for returning users
- [x] Keep the update pop-up running until December 1, 2026 (returns on each visit, stops after that date)
- [x] Verified badge beside "Mira AI" in the wordmark: home header, chat sidebar, phone header
- [ ] Show the "Mira AI founder" badge only on the owner's account — waiting for the account email to switch it on
- [x] Keep the founder badge beside the name even when the display name is changed or left blank

- [x] Add "Introducing NXT Media" partner spotlight to the home page below the hero: logo, headline, description, Explore button opening the NXT Media page (/nxt-media) with Discord join buttons; checked desktop/tablet/phone
- [x] Remove all plan UI at the user's request: home page plan cards and pricing links, the /pricing page, the Settings Plans tab, the Account upgrade banner and plan badge, the sidebar plan chip, and the Mira 1.1 paid-upgrades section; payment products, checkout code and the webhook were left in place but are no longer reachable; verified home/pricing/Settings/chat in the browser and 33 tests pass
