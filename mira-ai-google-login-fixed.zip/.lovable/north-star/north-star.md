<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

People get helpful, up-to-date answers to whatever they ask.

## Metric

Replies Mira completes for signed-in people each day
