CREATE TABLE public.subscriptions (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id uuid NOT NULL,
 paddle_subscription_id text NOT NULL,
 paddle_customer_id text NOT NULL,
 product_id text NOT NULL CHECK (product_id IN ('mira_plus','mira_pro')),
 price_id text NOT NULL CHECK (price_id IN ('mira_plus_monthly','mira_pro_monthly')),
 status text NOT NULL,
 current_period_start timestamptz,
 current_period_end timestamptz,
 cancel_at_period_end boolean NOT NULL DEFAULT false,
 environment text NOT NULL DEFAULT 'live' CHECK (environment IN ('sandbox','live')),
 provider_updated_at timestamptz NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE (paddle_subscription_id, environment)
);
GRANT SELECT ON public.subscriptions TO authenticated;
GRANT ALL ON public.subscriptions TO service_role;
ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users read own subscriptions" ON public.subscriptions FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE INDEX subscriptions_user_environment_idx ON public.subscriptions (user_id, environment);

REVOKE INSERT, UPDATE ON public.user_settings FROM authenticated;
GRANT INSERT (user_id, answer_style, about_me, updated_at) ON public.user_settings TO authenticated;
GRANT UPDATE (answer_style, about_me, updated_at) ON public.user_settings TO authenticated;
COMMENT ON COLUMN public.user_settings.plan IS 'DEPRECATED: paid plan access is derived only from verified public.subscriptions rows; legacy selections do not grant access.';

CREATE OR REPLACE FUNCTION public.apply_mira_subscription(payload jsonb)
RETURNS void LANGUAGE plpgsql SECURITY INVOKER SET search_path = public AS $$
BEGIN
 INSERT INTO public.subscriptions (user_id,paddle_subscription_id,paddle_customer_id,product_id,price_id,status,current_period_start,current_period_end,cancel_at_period_end,environment,provider_updated_at)
 VALUES ((payload->>'user_id')::uuid,payload->>'paddle_subscription_id',payload->>'paddle_customer_id',payload->>'product_id',payload->>'price_id',payload->>'status',(payload->>'current_period_start')::timestamptz,(payload->>'current_period_end')::timestamptz,COALESCE((payload->>'cancel_at_period_end')::boolean,false),payload->>'environment',(payload->>'provider_updated_at')::timestamptz)
 ON CONFLICT (paddle_subscription_id, environment) DO UPDATE SET
 product_id = EXCLUDED.product_id, price_id = EXCLUDED.price_id, status = EXCLUDED.status,
 current_period_start = EXCLUDED.current_period_start, current_period_end = EXCLUDED.current_period_end,
 cancel_at_period_end = EXCLUDED.cancel_at_period_end, provider_updated_at = EXCLUDED.provider_updated_at, updated_at = now()
 WHERE subscriptions.provider_updated_at <= EXCLUDED.provider_updated_at AND subscriptions.user_id = EXCLUDED.user_id;
END;
$$;
REVOKE ALL ON FUNCTION public.apply_mira_subscription(jsonb) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.apply_mira_subscription(jsonb) TO service_role;