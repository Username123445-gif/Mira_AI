CREATE TABLE public.credit_ledger (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id uuid NOT NULL,
 environment text NOT NULL DEFAULT 'live' CHECK (environment IN ('sandbox','live')),
 amount integer NOT NULL CHECK (amount <> 0),
 reason text NOT NULL CHECK (reason IN ('purchase','reward','usage','refund','adjustment')),
 reference text NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE (environment, reference)
);
GRANT SELECT ON public.credit_ledger TO authenticated;
GRANT ALL ON public.credit_ledger TO service_role;
ALTER TABLE public.credit_ledger ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Customers read own credit activity" ON public.credit_ledger FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE INDEX credit_ledger_owner_idx ON public.credit_ledger(user_id, environment, created_at DESC);
CREATE FUNCTION public.mira_credit_balance(check_env text DEFAULT 'live')
RETURNS bigint LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public AS $$
 SELECT COALESCE(SUM(amount), 0)::bigint FROM public.credit_ledger
 WHERE user_id = auth.uid() AND environment = check_env;
$$;
REVOKE ALL ON FUNCTION public.mira_credit_balance(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.mira_credit_balance(text) TO authenticated;