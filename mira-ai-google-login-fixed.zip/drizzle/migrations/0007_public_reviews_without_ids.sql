DROP POLICY IF EXISTS "Anyone can read reviews" ON public.reviews;
REVOKE SELECT ON public.reviews FROM anon;
CREATE POLICY "Users view own review" ON public.reviews FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.list_public_reviews()
RETURNS TABLE (id uuid, display_name text, rating smallint, comment text, created_at timestamptz, is_mine boolean)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT r.id, r.display_name, r.rating, r.comment, r.created_at, (r.user_id = auth.uid()) AS is_mine
  FROM public.reviews r ORDER BY r.created_at DESC LIMIT 100
$$;
REVOKE ALL ON FUNCTION public.list_public_reviews() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.list_public_reviews() TO anon, authenticated;