COMMENT ON TABLE public.credit_ledger IS 'DEPRECATED: unused customer credit feature created before clarification; request concerns Lovable workspace credits instead.';
REVOKE SELECT ON public.credit_ledger FROM authenticated;
REVOKE EXECUTE ON FUNCTION public.mira_credit_balance(text) FROM authenticated;
COMMENT ON FUNCTION public.mira_credit_balance(text) IS 'DEPRECATED: unused customer credit feature; not a Lovable workspace balance.';