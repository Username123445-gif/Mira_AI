CREATE TABLE public.generated_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  thread_id uuid REFERENCES public.threads(id) ON DELETE SET NULL,
  prompt text NOT NULL,
  storage_path text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, DELETE ON public.generated_images TO authenticated;
GRANT ALL ON public.generated_images TO service_role;
ALTER TABLE public.generated_images ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users view own images" ON public.generated_images FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users add own images" ON public.generated_images FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id AND storage_path LIKE auth.uid()::text || '/%');
CREATE POLICY "Users delete own images" ON public.generated_images FOR DELETE TO authenticated USING (auth.uid() = user_id);
CREATE INDEX generated_images_user_idx ON public.generated_images (user_id, created_at DESC);

CREATE POLICY "Users read own image files" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'generated-images' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "Users upload own image files" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'generated-images' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "Users delete own image files" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'generated-images' AND (storage.foldername(name))[1] = auth.uid()::text);