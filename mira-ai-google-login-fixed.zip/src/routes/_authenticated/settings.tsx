import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { Link, createFileRoute, useNavigate, useRouter } from "@tanstack/react-router";
import type { User } from "@supabase/supabase-js";
import { AppearanceTab } from "@/components/mira/AppearanceTab";
import { MemoryTab } from "@/components/mira/MemoryTab";
import { NotificationsTab } from "@/components/mira/NotificationsTab";
import { ImageGallery } from "@/components/mira/ImageGallery";
import { ConfirmDeleteDialog } from "@/components/mira/ConfirmDeleteDialog";
import { ArrowLeft, Bell, Brain, Images, Palette, Calendar, Download, KeyRound, LogOut, Mail, ShieldCheck, Sparkles, Trash2, UserRound } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { PasswordInput } from "@/components/mira/AuthShell";
import { AvatarUpload } from "@/components/mira/AvatarUpload";
import { useQuery } from "@tanstack/react-query";
import { MiraFounderBadge } from "@/components/mira/MiraFounderBadge";
import { MiraLogo } from "@/components/mira/MiraLogo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { accountName } from "@/lib/account-name";
import { isMiraFounder } from "@/lib/founder";
import { ABOUT_ME_MAX, ANSWER_STYLES, type AnswerStyle } from "@/lib/plans";
import { saveSettings, settingsQuery } from "@/lib/settings";
import { cn } from "@/lib/utils";
import { MIRA_VERSION } from "@/lib/version";

export const Route = createFileRoute("/_authenticated/settings")({
  head: () => ({
    meta: [
      { title: "Settings — Mira AI" },
      { name: "description", content: "Choose how Mira answers and manage your account." },
      { property: "og:title", content: "Settings — Mira AI" },
      { property: "og:description", content: "Choose how Mira answers and manage your account." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(settingsQuery()),
  component: SettingsPage,
});

function SettingsPage() {
  const { user } = Route.useRouteContext();
  const [tab, setTab] = useState("answers");

  return (
    <div className="min-h-dvh bg-night">
      <div className="mx-auto w-full max-w-4xl px-4 py-6 md:px-8 md:py-10">
        <Button asChild variant="ghost" size="sm" className="-ml-2 text-muted-foreground">
          <Link to="/chat">
            <ArrowLeft /> Back to chats
          </Link>
        </Button>
        <div className="relative mt-4 overflow-hidden rounded-3xl border border-border bg-card/60 p-6 md:p-8">
          <div className="pointer-events-none absolute -top-24 -left-16 size-64 rounded-full bg-gradient-mira opacity-20 blur-3xl" />
          <div className="relative flex items-center gap-4">
            <MiraLogo className="size-11" />
            <div>
              <h1 className="font-display text-4xl md:text-5xl">Settings</h1>
              <p className="mt-1 text-sm text-muted-foreground">How Mira answers, your gallery and your account.</p>
            </div>
          </div>
        </div>

        <Tabs value={tab} onValueChange={setTab} className="mt-8">
          <TabsList className="grid h-auto w-full grid-cols-2 rounded-2xl sm:grid-cols-5 bg-card/80 p-1.5">
            <TabsTrigger value="answers" className="gap-1.5 rounded-xl px-4 py-2"><Sparkles className="size-4" /> Answers</TabsTrigger>
            <TabsTrigger value="memory" className="gap-1.5 rounded-xl px-4 py-2"><Brain className="size-4" /> Memory</TabsTrigger>
            <TabsTrigger value="account" className="gap-1.5 rounded-xl px-4 py-2"><UserRound className="size-4" /> Account</TabsTrigger>
            <TabsTrigger value="gallery" className="gap-1.5 rounded-xl px-4 py-2"><Images className="size-4" /> Gallery</TabsTrigger>
            <TabsTrigger value="appearance" className="gap-1.5 rounded-xl px-4 py-2"><Palette className="size-4" /> Theme</TabsTrigger>
            <TabsTrigger value="notifications" className="gap-1.5 rounded-xl px-3 py-2"><Bell className="size-4" /> Notifications</TabsTrigger>
          </TabsList>
          <TabsContent value="answers" className="mt-6">
            <AnswersTab />
          </TabsContent>
          <TabsContent value="memory" className="mt-6">
            <MemoryTab />
          </TabsContent>
          <TabsContent value="account" className="mt-6">
            <AccountTab user={user} />
          </TabsContent>
          <TabsContent value="gallery" className="mt-6">
            <ImageGallery />
          </TabsContent>
          <TabsContent value="appearance" className="mt-6">
            <AppearanceTab />
          </TabsContent>
          <TabsContent value="notifications" className="mt-6">
            <NotificationsTab userId={user.id} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

function AnswersTab() {
  const queryClient = useQueryClient();
  const { data: settings } = useSuspenseQuery(settingsQuery());
  const [style, setStyle] = useState<AnswerStyle>(settings.answer_style);
  const [about, setAbout] = useState(settings.about_me);
  const [saving, setSaving] = useState(false);
  const dirty = style !== settings.answer_style || about !== settings.about_me;

  async function save() {
    setSaving(true);
    try {
      await saveSettings({ answer_style: style, about_me: about.trim() });
      await queryClient.invalidateQueries({ queryKey: ["settings"] });
      toast.success("Saved. Mira will use this in your next message.");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Couldn't save your settings.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="grid max-w-2xl gap-6">
      <section className="rounded-2xl border border-border bg-card/70 p-5">
        <h2 className="font-display text-2xl">Answer style</h2>
        <p className="mt-1 text-sm text-muted-foreground">How long and detailed should Mira's replies be?</p>
        <div role="radiogroup" aria-label="Answer style" className="mt-4 grid gap-3 sm:grid-cols-3">
          {ANSWER_STYLES.map((s) => (
            <button
              key={s.id}
              type="button"
              role="radio"
              aria-checked={style === s.id}
              onClick={() => setStyle(s.id)}
              className={cn(
                "rounded-xl border bg-card/70 p-4 text-left transition-colors hover:border-mira-periwinkle/60",
                style === s.id ? "border-mira-periwinkle" : "border-border",
              )}
            >
              <span className="block font-medium">{s.label}</span>
              <span className="mt-1 block text-xs text-muted-foreground">{s.description}</span>
            </button>
          ))}
        </div>
      </section>

      <section className="rounded-2xl border border-border bg-card/70 p-5">
        <Label htmlFor="about-me" className="font-display text-2xl font-normal">
          About you
        </Label>
        <p className="mt-1 text-sm text-muted-foreground">
          Anything Mira should know to tailor answers — your work, interests, or how you like to learn.
        </p>
        <Textarea
          id="about-me"
          value={about}
          maxLength={ABOUT_ME_MAX}
          onChange={(e) => setAbout(e.target.value)}
          placeholder="e.g. I'm a teacher in Chicago. I prefer simple explanations with examples."
          className="mt-4 min-h-32 bg-background/50"
        />
        <p className="mt-1 text-right text-xs text-muted-foreground">
          {about.length}/{ABOUT_ME_MAX}
        </p>
      </section>

      <div>
        <Button variant="hero" className="rounded-xl" disabled={!dirty || saving} onClick={save}>
          {saving ? "Saving…" : "Save changes"}
        </Button>
      </div>
    </div>
  );
}

function Section({ icon: Icon, title, children }: { icon: typeof Mail; title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-2xl border border-border bg-card/70 p-5">
      <h3 className="flex items-center gap-2 font-display text-lg"><Icon className="size-4 text-primary" /> {title}</h3>
      <div className="mt-4">{children}</div>
    </section>
  );
}

function AccountTab({ user }: { user: User }) {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const router = useRouter();
  const { data: settings } = useSuspenseQuery(settingsQuery());
  const savedName = accountName(user.user_metadata) ?? "";
  const [name, setName] = useState(savedName);
  const [savingName, setSavingName] = useState(false);
  const [password, setPassword] = useState("");
  const [savingPw, setSavingPw] = useState(false);
  const [busy, setBusy] = useState<"export" | "delete" | null>(null);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const initials = (savedName || "M").split(/\s+/).map((w) => w[0]).join("").slice(0, 2).toUpperCase();
  const { data: stats } = useQuery({
    queryKey: ["account-stats", user.id],
    queryFn: async () => {
      const [t, i] = await Promise.all([
        supabase.from("threads").select("id", { count: "exact", head: true }),
        supabase.from("generated_images").select("id", { count: "exact", head: true }),
      ]);
      return { chats: t.count ?? 0, images: i.count ?? 0 };
    },
  });
  const since = new Date(user.created_at).toLocaleDateString(undefined, { month: "long", year: "numeric" });

  async function saveName(e: React.FormEvent) {
    e.preventDefault();
    setSavingName(true);
    try {
      const { error } = await supabase.auth.updateUser({ data: { display_name: name.trim() } });
      if (error) throw error;
      await router.invalidate();
      toast.success("Name saved.");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Couldn't save your name.");
    } finally {
      setSavingName(false);
    }
  }

  async function savePassword(e: React.FormEvent) {
    e.preventDefault();
    if (password.length < 8) { toast.error("Use at least 8 characters."); return; }
    setSavingPw(true);
    const { error } = await supabase.auth.updateUser({ password });
    setSavingPw(false);
    if (error) { toast.error(error.message); return; }
    setPassword("");
    toast.success("Password updated.");
  }

  async function exportChats() {
    setBusy("export");
    try {
      const [{ data: threads, error: e1 }, { data: messages, error: e2 }] = await Promise.all([
        supabase.from("threads").select("id,title,created_at,updated_at").order("created_at"),
        supabase.from("messages").select("thread_id,role,parts,created_at").order("created_at"),
      ]);
      if (e1 || e2) throw e1 ?? e2;
      const data = (threads ?? []).map((t) => ({ ...t, messages: (messages ?? []).filter((m) => m.thread_id === t.id) }));
      const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }));
      const a = document.createElement("a");
      a.href = url;
      a.download = "mira-chats.json";
      a.click();
      URL.revokeObjectURL(url);
      toast.success(`Exported ${data.length} chats.`);
    } catch {
      toast.error("Couldn't export your chats.");
    } finally {
      setBusy(null);
    }
  }

  async function deleteAllChats() {
    setBusy("delete");
    try {
      const { error } = await supabase.from("threads").delete().eq("user_id", user.id);
      if (error) throw error;
      queryClient.removeQueries({ queryKey: ["threads"] });
      setConfirmDelete(false);
      toast.success("All chats deleted.");
    } catch {
      toast.error("Couldn't delete your chats. Please try again.");
    } finally {
      setBusy(null);
    }
  }

  async function signOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/login", replace: true });
  }

  return (
    <div className="grid gap-5">
      <div className="relative overflow-hidden rounded-2xl border border-border bg-card/70 p-6">
        <div className="pointer-events-none absolute -top-20 -right-20 size-56 rounded-full bg-gradient-mira opacity-20 blur-3xl" />
        <div className="relative flex flex-wrap items-center gap-4">
          <AvatarUpload userId={user.id} avatarPath={settings.avatar_path} initials={initials} />
          <div className="min-w-0 flex-1">
            <p className="flex items-center gap-2 font-display text-2xl">
              {savedName || "Your account"}
              {isMiraFounder(user.email) ? <MiraFounderBadge className="size-5" /> : null}
            </p>
            <p className="flex items-center gap-1.5 break-all text-sm text-muted-foreground"><Mail className="size-3.5 shrink-0" /> {user.email}</p>
            <p className="mt-1 flex items-center gap-1.5 text-xs text-muted-foreground"><Calendar className="size-3.5" /> Member since {since} · {MIRA_VERSION}</p>
          </div>
        </div>
        <div className="relative mt-5 grid grid-cols-3 gap-3">
          {[
            ["Chats", stats?.chats ?? "—"],
            ["Images", stats?.images ?? "—"],
            ["Sign-in", user.app_metadata?.provider === "google" ? "Google" : "Email"],
          ].map(([label, value]) => (
            <div key={String(label)} className="rounded-xl border border-border bg-background/40 px-3 py-2.5">
              <p className="text-[11px] tracking-wide text-muted-foreground uppercase">{label}</p>
              <p className="mt-0.5 font-display text-xl">{value}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="grid gap-5 md:grid-cols-2">
        <Section icon={UserRound} title="Profile">
          <form onSubmit={saveName} className="grid gap-3">
            <Label htmlFor="account-name">Display name</Label>
            <Input id="account-name" autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} />
            <Button type="submit" variant="hero" className="w-fit" disabled={savingName || name.trim() === savedName}>
              {savingName ? "Saving…" : "Save name"}
            </Button>
          </form>
        </Section>

        <Section icon={KeyRound} title="Password">
          <form onSubmit={savePassword} className="grid gap-3">
            <Label htmlFor="new-password">New password</Label>
            <PasswordInput id="new-password" autoComplete="new-password" value={password} onChange={setPassword} />
            <p className="text-xs text-muted-foreground">At least 8 characters.</p>
            <Button type="submit" variant="glass" className="w-fit" disabled={savingPw || !password}>
              {savingPw ? "Updating…" : "Update password"}
            </Button>
          </form>
        </Section>
      </div>

      <Section icon={ShieldCheck} title="Your data">
        <p className="text-sm text-muted-foreground">Download a copy of all your chats, or permanently clear your chat history.</p>
        <div className="mt-4 flex flex-wrap gap-3">
          <Button variant="glass" disabled={busy !== null} onClick={exportChats}><Download /> {busy === "export" ? "Exporting…" : "Export chats"}</Button>
          <Button variant="ghost" disabled={busy !== null} className="text-destructive" onClick={() => setConfirmDelete(true)}><Trash2 /> Delete all chats</Button>
        </div>
      </Section>

      <ConfirmDeleteDialog open={confirmDelete} busy={busy === "delete"} title="Delete all chats?"
        description="Every saved conversation will be permanently removed. Your account and gallery remain. This can't be undone."
        confirmLabel="Delete all chats" onOpenChange={setConfirmDelete} onConfirm={deleteAllChats} />

      <Button variant="glass" className="w-fit rounded-xl" onClick={signOut}>
        <LogOut /> Sign out
      </Button>
    </div>
  );
}
