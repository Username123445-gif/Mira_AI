import { useSuspenseQuery } from "@tanstack/react-query";
import { Link, createFileRoute } from "@tanstack/react-router";

import { ChatWindow } from "@/components/mira/ChatWindow";
import { Button } from "@/components/ui/button";
import { threadMessagesQuery } from "@/lib/threads";

export const Route = createFileRoute("/_authenticated/chat/$threadId")({
  head: () => ({ meta: [
    { title: "Your conversation — Mira AI" },
    { name: "description", content: "Continue your private conversation with Mira, with live web answers." },
    { property: "og:title", content: "Your conversation — Mira AI" },
    { property: "og:description", content: "Continue your private conversation with Mira, with live web answers." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" },
  ] }),
  loader: ({ context, params }) => context.queryClient.ensureQueryData(threadMessagesQuery(params.threadId)),
  pendingComponent: () => <div className="flex-1" />,
  component: ThreadPage,
});

function ThreadPage() {
  const { threadId } = Route.useParams();
  const { data } = useSuspenseQuery(threadMessagesQuery(threadId));

  if (!data.exists) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center gap-4 p-8 text-center">
        <h1 className="font-display text-3xl">This chat isn't here</h1>
        <p className="text-sm text-muted-foreground">It may have been deleted.</p>
        <Button asChild variant="hero" className="rounded-full">
          <Link to="/chat">Start a new chat</Link>
        </Button>
      </div>
    );
  }

  return <ChatWindow key={threadId} threadId={threadId} initialMessages={data.messages} />;
}
