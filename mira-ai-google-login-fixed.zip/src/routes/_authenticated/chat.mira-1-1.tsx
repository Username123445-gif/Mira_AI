import { Link, createFileRoute } from "@tanstack/react-router";
import {
  ArrowLeft,
  ArrowUpRight,
  Bell,
  Brain,
  CalendarDays,
  FileText,
  History,
  MessageSquare,
  Moon,
  RotateCcw,
  Settings,
  Share2,
  SlidersHorizontal,
  Sparkles,
  Trash2,
  Zap,
} from "lucide-react";

import banner from "@/assets/mira-1-1-banner-v2.png.asset.json";
import miraOneOneMark from "@/assets/mira-1-1-mark-hd.png.asset.json";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const description = "Explore what's planned for Mira AI 1.1 on January 1, 2027: memory, searchable chat history, custom instructions, and a cleaner chat experience.";

export const Route = createFileRoute("/_authenticated/chat/mira-1-1")({
  head: () => ({ meta: [
    { title: "Mira 1.1 — Coming January 1, 2027 | Mira AI" },
    { name: "description", content: description },
    { property: "og:title", content: "Mira 1.1 — Coming January 1, 2027 | Mira AI" },
    { property: "og:description", content: description },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: MiraPreview,
});

const features = [
  { icon: Brain, title: "Mira Memory", text: "Remember your preferences and important details between chats, so every conversation feels more personal." },
  { icon: History, title: "Chat History", text: "Revisit and search previous conversations to find the answers and ideas you want to return to." },
  { icon: SlidersHorizontal, title: "Custom Instructions", text: "Choose how Mira responds, from the tone she uses to the details that matter to you." },
  { icon: MessageSquare, title: "Improved Chat UI", text: "Cleaner messages, smoother animations, and a better mobile layout." },
  { icon: RotateCcw, title: "Regenerate Response", text: "Get another answer when the first response isn't quite what you were looking for." },
  { icon: Trash2, title: "Clear Chat", text: "Easily clear a conversation and start fresh." },
  { icon: Settings, title: "Mira Settings", text: "Manage memory, appearance, and chat preferences in one place." },
  { icon: Share2, title: "Share Chats", text: "Send a read-only link to any conversation so friends and teammates can see Mira's answer." },
  { icon: FileText, title: "File Uploads", text: "Drop in documents and images and ask Mira questions about them right in the chat." },
  { icon: Bell, title: "Smart Notifications", text: "Get a gentle nudge when a long answer or generated image is ready." },
  { icon: Moon, title: "Appearance Themes", text: "Pick light, dark, or a look that follows your device — Mira matches your style." },
  { icon: Zap, title: "Faster Answers", text: "Quicker first words and smoother streaming, even on slower connections." },
] as const;

const collections = [
  { id: "all", label: "Everything", indices: features.map((_, index) => index) },
  { id: "personal", label: "Personal", indices: [0, 2, 6, 10] },
  { id: "conversations", label: "Conversations", indices: [1, 4, 5, 7, 8] },
  { id: "experience", label: "Experience", indices: [3, 9, 11] },
] as const;

function MiraPreview() {
  return (
    <main className="min-h-0 flex-1 overflow-y-auto">
      <div className="mx-auto max-w-5xl px-5 py-5 md:px-10 md:py-8">
        <Button asChild variant="ghost" size="sm" className="-ml-3 mb-5 text-muted-foreground">
          <Link to="/chat" preload={false}><ArrowLeft /> Back to chats</Link>
        </Button>
        <header className="motion-safe:animate-rise pb-7">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <span className="inline-flex items-center gap-2 text-xs font-medium uppercase text-mira-ice"><img src={miraOneOneMark.url} alt="" className="size-5 rounded-sm object-contain" /> The next chapter</span>
            <span className="inline-flex items-center gap-2 text-xs text-muted-foreground"><CalendarDays className="size-4 text-primary" /> Planned release · January 1, 2027</span>
          </div>
          <h1 className="mt-4 font-display text-5xl md:text-6xl">Mira AI <span className="text-gradient-mira">1.1</span></h1>
          <p className="mt-4 max-w-2xl text-base leading-relaxed text-muted-foreground">More personal. More possibilities. A new chapter for the conversations, ideas, and details that matter to you.</p>
        </header>
        <img src={banner.url} alt="Mira 1.1 promotional artwork" className="aspect-video max-h-80 w-full rounded-lg object-contain motion-safe:animate-rise md:max-h-[360px]" />
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border py-4 text-xs">
          <span className="flex items-center gap-2 text-primary"><Sparkles className="size-3.5" /> {features.length} planned upgrades</span>
          <span className="text-muted-foreground">Upcoming release preview</span>
        </div>
        <section aria-labelledby="features-title" className="py-8 md:py-10">
          <div className="mb-6">
            <h2 id="features-title" className="font-display text-3xl">A closer look at what's next</h2>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">From a Mira that remembers you to more ways to create and connect.</p>
          </div>
          <Tabs defaultValue="all">
            <TabsList aria-label="Upcoming feature categories" className="grid h-auto w-full grid-cols-2 gap-1 md:inline-flex md:w-auto">
              {collections.map(({ id, label }) => <TabsTrigger key={id} value={id} className="px-4 py-2">{label}</TabsTrigger>)}
            </TabsList>
            {collections.map(({ id, indices }) => (
              <TabsContent key={id} value={id} className="mt-5">
                <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                  {features.filter((_, index) => indices.some((item) => item === index)).map(({ icon: Icon, title, text }) => (
                    <article key={title} className="group flex flex-col rounded-lg border border-border bg-card p-5 transition-colors hover:border-primary/40 hover:bg-accent/40 motion-safe:animate-rise">
                      <div className="mb-5 flex items-center justify-between gap-3">
                        <span className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-mira-ice"><Icon className="size-5" /></span>
                        <span className="text-[10px] font-medium uppercase text-muted-foreground">Planned for 1.1</span>
                      </div>
                      <h3 className="text-base font-semibold">{title}</h3>
                      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{text}</p>
                    </article>
                  ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </section>
        <section className="flex flex-col justify-between gap-5 border-t border-border py-7 md:flex-row md:items-center">
          <div className="max-w-lg">
            <h2 className="font-display text-xl">Coming next. Not live just yet.</h2>
            <p className="mt-2 text-xs leading-relaxed text-muted-foreground">These updates are planned for Mira 1.1. Your current Mira remains v0.2 Beta, and you can keep chatting as usual.</p>
          </div>
          <div className="shrink-0">
            <Button asChild variant="glass">
              <Link to="/whats-new">Latest release notes <ArrowUpRight /></Link>
            </Button>
          </div>
        </section>
      </div>
    </main>
  );
}
