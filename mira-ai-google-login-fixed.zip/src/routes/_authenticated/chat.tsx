import { Outlet, createFileRoute } from "@tanstack/react-router";
import { Menu } from "lucide-react";
import { useState } from "react";

import { MiraFounderBadge } from "@/components/mira/MiraFounderBadge";
import { ChristmasUpdate } from "@/components/mira/ChristmasUpdate";
import { MiraOneOneCountdown } from "@/components/mira/MiraOneOneCountdown";
import { MiraWordmark } from "@/components/mira/MiraLogo";
import { ThreadSidebar } from "@/components/mira/ThreadSidebar";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTitle } from "@/components/ui/sheet";
import { accountName } from "@/lib/account-name";
import { isMiraFounder } from "@/lib/founder";

export const Route = createFileRoute("/_authenticated/chat")({
  head: () => ({
    meta: [
      { title: "Chat with Mira — Mira AI" },
      { name: "description", content: "Your conversations with Mira, the helpful AI from Mira AI." },
      { property: "og:title", content: "Chat with Mira — Mira AI" },
      { property: "og:description", content: "Your conversations with Mira, the helpful AI from Mira AI." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ChatLayout,
});

function ChatLayout() {
  const { user } = Route.useRouteContext();
  const [open, setOpen] = useState(false);
  const name = accountName(user.user_metadata);
  const founder = isMiraFounder(user.email);

  return (
    <div className="flex h-dvh flex-col overflow-hidden bg-background">
      <MiraOneOneCountdown />
      <ChristmasUpdate />
      <div className="flex min-h-0 flex-1 overflow-hidden">
        <aside className="hidden w-72 shrink-0 border-r border-sidebar-border md:block">
          <ThreadSidebar email={user.email} name={name} />
        </aside>

        <Sheet open={open} onOpenChange={setOpen}>
          <SheetContent side="left" className="w-72 border-sidebar-border p-0">
            <SheetTitle className="sr-only">Chats</SheetTitle>
            <ThreadSidebar email={user.email} name={name} onNavigate={() => setOpen(false)} />
          </SheetContent>
        </Sheet>

        <div className="flex min-w-0 flex-1 flex-col">
          <div className="flex items-center gap-2 border-b border-border px-3 py-2 md:hidden">
            <Button variant="ghost" size="icon-sm" aria-label="Open chats" onClick={() => setOpen(true)}>
              <Menu />
            </Button>
            <MiraWordmark />
          </div>
          <header className="shrink-0 border-b border-border px-4 py-3 md:px-6">
            <h2 className="break-words font-display text-xl leading-snug md:text-2xl">
              Welcome back{name ? <>, <span className="text-gradient-mira">{name}</span></> : ""}{founder ? <MiraFounderBadge className="ml-[0.15em] size-[0.8em] align-[-0.06em]" /> : ""}.
            </h2>
            <p className="text-xs text-muted-foreground">Your chats are saved to your account.</p>
          </header>
          <Outlet />
        </div>
      </div>
    </div>
  );
}
