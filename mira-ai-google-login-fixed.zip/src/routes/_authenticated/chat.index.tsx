import { createFileRoute, redirect } from "@tanstack/react-router";

import { getOrCreateEmptyThread } from "@/lib/threads";

export const Route = createFileRoute("/_authenticated/chat/")({
  head: () => ({ meta: [
    { title: "Open your Mira chat — Mira AI" },
    { name: "description", content: "Start a new conversation with Mira or return to your latest empty chat." },
    { property: "og:title", content: "Open your Mira chat — Mira AI" },
    { property: "og:description", content: "Start a new conversation with Mira or return to your latest empty chat." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" },
  ] }),
  loader: async ({ preload, context }) => {
    // Hovering a link must never create a chat or redirect the current conversation.
    if (preload) return;
    const threadId = await getOrCreateEmptyThread();
    await context.queryClient.invalidateQueries({ queryKey: ["threads"], exact: true });
    throw redirect({ to: "/chat/$threadId", params: { threadId }, replace: true });
  },
  pendingComponent: () => <div className="flex-1" />,
  component: () => null,
});
