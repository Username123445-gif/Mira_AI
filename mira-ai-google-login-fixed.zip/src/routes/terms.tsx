import { Link, createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/mira/LegalPage";

const desc = "The terms that apply when you use Mira AI, the AI assistant by Mira AI.";
export const Route = createFileRoute("/terms")({
  head: () => ({ meta: [
    { title: "Terms & Conditions — Mira AI" }, { name: "description", content: desc },
    { property: "og:title", content: "Terms & Conditions — Mira AI" }, { property: "og:description", content: desc },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" },
  ] }),
  component: Terms,
});

function Terms() {
  return (
    <LegalPage title="Terms & Conditions" updated="November 22, 2026">
      <p>These terms are a contract between you and <strong>Mira AI</strong> ("we", "us"), the seller and operator of the Mira AI assistant (the "Service"). By creating an account or continuing to use the Service, you agree to these terms.</p>
      <h2>The Service</h2>
      <p>Mira is an AI chat assistant that answers questions, helps with writing and learning, and can search the web for current information. You must be of legal age to enter a contract, or have authority to bind the organization you use the Service for.</p>
      <h2>Your account</h2>
      <p>Provide accurate information, keep your login details confidential, and you are responsible for activity under your account.</p>
      <h2>Acceptable use</h2>
      <p>You must not misuse the Service, including:</p>
      <ul>
        <li>using it for anything unlawful, fraudulent, or for spam;</li>
        <li>infringing anyone's intellectual property or privacy;</li>
        <li>generating illegal content, hate speech, harassment, deceptive deepfakes or impersonation, or malware;</li>
        <li>attempting to jailbreak, bypass safety filters or technical limits, reverse engineer, scrape, probe, or interfere with the Service's security;</li>
        <li>reselling or redistributing the Service without our permission.</li>
      </ul>
      <h2>Your prompts and Mira's answers</h2>
      <p>You are responsible for your prompts, for having the rights to any content you provide, and for how you use answers. As between you and us, you keep your rights in your inputs and may use the outputs, subject to these terms and the law. You grant us a limited licence to host and process your content solely to provide the Service.</p>
      <p><strong>Accuracy:</strong> AI answers can be wrong, incomplete or out of date, even with web search. Verify important information. Mira is not a substitute for professional medical, legal, financial or other regulated advice without qualified human oversight.</p>
      <p>We may remove or restrict content, refuse or filter outputs, and suspend accounts to enforce these terms. Rights-holders can report infringing content through our support contact; repeated infringement leads to account termination.</p>
      <h2>Intellectual property</h2>
      <p>Mira AI owns the Service and its intellectual property, including software, documentation, the Mira name and logo. We grant you a limited, non-exclusive, non-transferable right to use the Service.</p>
      <h2>Payments and subscriptions</h2>
      <p>Our order process is conducted by our online reseller Paddle.com. Paddle.com is the Merchant of Record for all our orders. Paddle provides all customer service inquiries and handles returns. Payment, billing, tax, renewal and cancellation terms are set out in <a href="https://www.paddle.com/legal/checkout-buyer-terms" target="_blank" rel="noreferrer">Paddle's Buyer Terms</a>. Refunds are described in our <Link to="/refunds">Refund Policy</Link>.</p>
      <h2>Service level</h2>
      <p>We work to keep Mira available and accurate, but we do not guarantee uninterrupted or error-free performance. The Service is provided "as is" and, to the fullest extent permitted by law, we disclaim implied warranties such as merchantability and fitness for a particular purpose.</p>
      <h2>Suspension and termination</h2>
      <p>We may suspend or terminate access for material breach of these terms, non-payment, security or fraud risk, or repeated or serious policy violations. You may stop using the Service at any time. When an account ends, its chats may be deleted.</p>
      <h2>Liability</h2>
      <p>To the extent permitted by law, we are not liable for indirect or consequential losses (such as lost profits, data or goodwill), and our total liability is limited to the fees you paid us in the 12 months before the claim. Nothing limits liability for fraud, death or personal injury where the law does not allow it. You will indemnify us for claims arising from your content, unlawful use or breach of these terms.</p>
      <h2>General</h2>
      <p>We are not responsible for delays caused by events beyond our reasonable control. You may not assign these terms without our consent; we may assign them in a merger or acquisition. We may update these terms and will post the new version here. Questions? Contact Mira AI through the support details on this site.</p>
    </LegalPage>
  );
}
