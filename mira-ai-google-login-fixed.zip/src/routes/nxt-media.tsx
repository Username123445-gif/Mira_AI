import { Link, createFileRoute } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, Image as ImageIcon, Megaphone, Palette, Clapperboard, MessageCircle } from "lucide-react";
import logo from "@/assets/ntx-media-logo.png.asset.json";
import { SiteFooter } from "@/components/mira/SiteFooter";
import { Button } from "@/components/ui/button";

const DISCORD = "https://discord.gg/3F6VPrMykt";
const desc = "NXT Media is a creative media company delivering high-quality thumbnails, advertising, branding and digital content.";

export const Route = createFileRoute("/nxt-media")({
  head: () => ({ meta: [
    { title: "NXT Media — Creative media studio" }, { name: "description", content: desc },
    { property: "og:title", content: "NXT Media — Creative media studio" }, { property: "og:description", content: desc },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" },
  ] }),
  component: NxtMedia,
});

const services = [
  { icon: ImageIcon, title: "Thumbnails", text: "Scroll-stopping thumbnails built to lift clicks for creators and channels." },
  { icon: Megaphone, title: "Advertising", text: "Ad creatives for social, display and launches that make people look twice." },
  { icon: Palette, title: "Branding", text: "Logos, colour systems and identity kits that make a brand feel consistent everywhere." },
  { icon: Clapperboard, title: "Digital content", text: "Banners, posts and media assets for channels, communities and campaigns." },
];
const steps = [
  { n: "01", title: "Tell us the idea", text: "Share your goal, style and deadline in our Discord." },
  { n: "02", title: "We design", text: "Our team creates concepts tailored to your audience." },
  { n: "03", title: "Refine & deliver", text: "We polish with your feedback and hand over final files." },
];

function NxtMedia() {
  return (
    <div className="bg-stars min-h-screen">
      <main className="mx-auto max-w-5xl px-6 py-10">
        <Link to="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"><ArrowLeft className="size-4" /> Back to Mira AI</Link>

        <section className="animate-rise mt-12 flex flex-col items-center text-center">
          <span className="relative inline-flex size-32 items-center justify-center md:size-40">
            <span aria-hidden className="bg-gradient-mira absolute inset-[16%] animate-glow rounded-full blur-2xl" />
            <img src={logo.url} alt="NXT Media logo" className="animate-float relative size-full object-contain drop-shadow-mira" />
          </span>
          <h1 className="mt-6 font-display text-5xl leading-[1.05] tracking-tight md:text-6xl"><span className="text-gradient-mira italic">NXT Media</span></h1>
          <p className="mt-5 max-w-2xl text-muted-foreground md:text-lg">{desc}</p>
          <Button asChild variant="hero" size="xl" className="mt-8">
            <a href={DISCORD} target="_blank" rel="noopener noreferrer">Join our Discord <ArrowRight /></a>
          </Button>
        </section>

        <section className="mt-24">
          <h2 className="text-center font-display text-3xl md:text-4xl">What we do</h2>
          <div className="mt-8 grid gap-4 sm:grid-cols-2">
            {services.map(({ icon: Icon, title, text }) => (
              <div key={title} className="rounded-2xl border border-border bg-card/40 p-6 backdrop-blur-sm transition-colors hover:border-mira-periwinkle/40">
                <Icon className="size-6 text-mira-periwinkle" />
                <h3 className="mt-4 font-display text-xl">{title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{text}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="mt-24">
          <h2 className="text-center font-display text-3xl md:text-4xl">How we work</h2>
          <div className="mt-8 grid gap-4 md:grid-cols-3">
            {steps.map((s) => (
              <div key={s.n} className="rounded-2xl border border-border bg-card/40 p-6">
                <span className="text-gradient-mira font-display text-3xl italic">{s.n}</span>
                <h3 className="mt-3 font-display text-lg">{s.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{s.text}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="relative mt-24 overflow-hidden rounded-3xl border border-border bg-card/40 p-10 text-center">
          <span aria-hidden className="bg-gradient-mira pointer-events-none absolute -top-24 left-1/2 size-64 -translate-x-1/2 rounded-full opacity-20 blur-3xl" />
          <MessageCircle className="relative mx-auto size-8 text-mira-periwinkle" />
          <h2 className="relative mt-4 font-display text-3xl">Ready to start a project?</h2>
          <p className="relative mx-auto mt-3 max-w-lg text-muted-foreground">Come say hi in the NXT Media Discord — ask questions, see our latest work and request a design.</p>
          <Button asChild variant="hero" size="xl" className="relative mt-6">
            <a href={DISCORD} target="_blank" rel="noopener noreferrer">Join our Discord <ArrowRight /></a>
          </Button>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}
