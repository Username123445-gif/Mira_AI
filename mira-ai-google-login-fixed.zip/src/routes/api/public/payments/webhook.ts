import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { gatewayFetch, syncSubscription, verifyPaymentSignature } from "@/lib/payments.server";

export const Route = createFileRoute("/api/public/payments/webhook")({
  server: { handlers: { POST: async ({ request }) => {
    const environment = new URL(request.url).searchParams.get("env");
    if (environment !== "sandbox" && environment !== "live") return new Response("Invalid environment", { status: 400 });
    const secret = process.env[environment === "sandbox" ? "PAYMENTS_SANDBOX_WEBHOOK_SECRET" : "PAYMENTS_LIVE_WEBHOOK_SECRET"];
    if (!secret) return new Response("Payments not configured", { status: 503 });
    const body = await request.text();
    if (!await verifyPaymentSignature(body, request.headers.get("paddle-signature"), secret)) {
      return new Response("Invalid signature", { status: 401 });
    }
    try {
      const event = z.object({ event_type: z.string(), data: z.object({ id: z.string(), subscription_id: z.string().nullable().optional() }) })
        .parse(JSON.parse(body));
      if (event.event_type.startsWith("subscription.")) {
        await syncSubscription(event.data.id, environment);
      } else if (event.event_type === "transaction.completed" || event.event_type === "transaction.payment_failed") {
        let subscriptionId = event.data.subscription_id;
        if (!subscriptionId && event.event_type === "transaction.completed") {
          const response = await gatewayFetch(environment, `/transactions/${encodeURIComponent(event.data.id)}`);
          subscriptionId = z.object({ data: z.object({ subscription_id: z.string().nullable() }) }).parse(await response.json()).data.subscription_id;
        }
        if (subscriptionId) await syncSubscription(subscriptionId, environment);
      }
      return Response.json({ received: true });
    } catch {
      console.error("[payments] Payment event could not be applied; delivery will retry.");
      return new Response("Payment processing failed", { status: 500 });
    }
  } } },
});