import { createClient } from "@supabase/supabase-js";
import { createFileRoute } from "@tanstack/react-router";

import { MAX_TRANSCRIBE_BYTES, transcribe } from "@/lib/transcribe.server";

function text(status: number, message: string) {
  return new Response(message, { status, headers: { "content-type": "text/plain; charset=utf-8" } });
}

export const Route = createFileRoute("/api/transcribe")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const url = process.env["SUPABASE_URL"];
        const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
        const apiKey = process.env["LOVABLE_API_KEY"];
        if (!url || !key || !apiKey) return text(500, "Voice input isn't set up yet.");

        const auth = request.headers.get("authorization") ?? "";
        const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
        if (!token) return text(401, "Please sign in to use voice input.");
        const supabase = createClient(url, key, {
          auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
        });
        const { data, error } = await supabase.auth.getClaims(token);
        if (error || !data?.claims?.sub) return text(401, "Your session has expired. Please sign in again.");

        const declared = Number(request.headers.get("content-length") ?? "0");
        if (declared > MAX_TRANSCRIBE_BYTES + 64 * 1024) return text(413, "That recording is too long. Try a shorter one.");

        let file: unknown;
        try {
          file = (await request.formData()).get("file");
        } catch {
          return text(400, "Couldn't read that recording. Please try again.");
        }
        if (!(file instanceof File) || file.size < 2048) return text(400, "Didn't catch anything. Please try again.");
        if (file.size > MAX_TRANSCRIBE_BYTES) return text(413, "That recording is too long. Try a shorter one.");
        if (!file.type.startsWith("audio/")) return text(400, "That isn't an audio recording.");

        try {
          const upstream = await transcribe(apiKey, file, request.signal);
          return new Response(upstream.body, {
            status: upstream.status,
            headers: {
              "Content-Type": upstream.headers.get("Content-Type") ?? "application/json",
              "Cache-Control": "no-cache",
            },
          });
        } catch (err) {
          if (request.signal.aborted) return text(499, "Cancelled.");
          throw err;
        }
      },
    },
  },
});
