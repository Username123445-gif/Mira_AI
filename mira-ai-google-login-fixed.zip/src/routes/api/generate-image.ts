import { createClient } from "@supabase/supabase-js";
import { createFileRoute } from "@tanstack/react-router";

import { generateImage, imageSettings } from "@/lib/image-gateway.server";

function text(status: number, message: string) {
  return new Response(message, { status, headers: { "content-type": "text/plain; charset=utf-8" } });
}

export const Route = createFileRoute("/api/generate-image")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const url = process.env["SUPABASE_URL"];
        const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
        const apiKey = process.env["LOVABLE_API_KEY"];
        if (!url || !key || !apiKey) return text(500, "Image creation isn't set up yet.");

        // Only signed-in people can create images.
        const auth = request.headers.get("authorization") ?? "";
        const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
        if (!token) return text(401, "Please sign in to create images.");
        const supabase = createClient(url, key, {
          auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
        });
        const { data, error } = await supabase.auth.getClaims(token);
        if (error || !data?.claims?.sub) return text(401, "Your session has expired. Please sign in again.");

        let body: { prompt?: unknown; stream?: unknown };
        try {
          body = await request.json();
        } catch {
          return text(400, "Please describe the image you want.");
        }
        const prompt = typeof body.prompt === "string" ? body.prompt.trim().slice(0, 4000) : "";
        if (!prompt) return text(400, "Please describe the image you want.");

        const upstream = await generateImage({ ...imageSettings, apiKey }, prompt, body.stream !== false);
        return new Response(upstream.body, {
          status: upstream.status,
          headers: {
            "Content-Type": upstream.headers.get("Content-Type") ?? "application/json",
            "Cache-Control": "no-cache",
          },
        });
      },
    },
  },
});
