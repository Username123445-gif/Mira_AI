import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { MailCheck } from "lucide-react";
import { useState, type FormEvent } from "react";

import { SocialSignIn } from "@/components/mira/AuthButtons";
import { AuthShell, FormError, PasswordInput, Spinner, friendlyAuthError, useRedirectIfSignedIn } from "@/components/mira/AuthShell";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/signup")({
  head: () => ({
    meta: [
      { title: "Create your account — Mira AI" },
      { name: "description", content: "Create a free Mira AI account and keep your chats saved on every device." },
      { property: "og:title", content: "Create your account — Mira AI" },
      { property: "og:description", content: "Create a free Mira AI account and keep your chats saved on every device." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: SignupPage,
});

function SignupPage() {
  const navigate = useNavigate();
  const goToChat = () => navigate({ to: "/chat", replace: true });
  useRedirectIfSignedIn(goToChat);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [agreed, setAgreed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sentTo, setSentTo] = useState<string | null>(null);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    if (password.length < 8) return setError("Password must be at least 8 characters.");
    if (!agreed) return setError("Please accept the Terms of Service and Privacy Policy to continue.");
    setBusy(true);
    const { data, error: err } = await supabase.auth.signUp({
      email: email.trim(),
      password,
      options: {
        emailRedirectTo: `${window.location.origin}/login`,
        data: { ...(name.trim() ? { display_name: name.trim() } : {}), terms_accepted_at: new Date().toISOString() },
      },
    });
    setBusy(false);
    if (err) return setError(friendlyAuthError(err));
    if (data.session) return goToChat();
    setSentTo(email.trim());
  }

  if (sentTo) {
    return (
      <AuthShell title="Check your email" subtitle="One more step to start chatting with Mira."
        footer={<>Already confirmed? <Link to="/login" className="text-primary hover:underline">Sign in</Link></>}>
        <div className="flex flex-col items-center gap-3 text-center">
          <MailCheck className="size-10 text-primary" />
          <p className="text-sm">We sent a verification link to <strong>{sentTo}</strong>. Click it to activate your account.</p>
          <p className="text-xs text-muted-foreground">Can't find it? Check your spam folder.</p>
        </div>
      </AuthShell>
    );
  }

  return (
    <AuthShell title="Create your account" subtitle="Your chats with Mira, saved on every device."
      footer={<>Already have an account? <Link to="/login" className="text-primary hover:underline">Sign in</Link></>}>
      <SocialSignIn onSignedIn={goToChat} label="Sign up with Google" />
      <div className="my-6 flex items-center gap-3 text-xs text-muted-foreground">
        <span className="h-px flex-1 bg-border" /> or with email <span className="h-px flex-1 bg-border" />
      </div>
      <form onSubmit={onSubmit} className="grid gap-4">
        <div className="grid gap-2">
          <Label htmlFor="name">Name (optional)</Label>
          <Input id="name" autoComplete="name" maxLength={80} value={name} onChange={(e) => setName(e.target.value)} className="h-11 rounded-xl" />
        </div>
        <div className="grid gap-2">
          <Label htmlFor="email">Email</Label>
          <Input id="email" type="email" autoComplete="email" required maxLength={255} value={email} onChange={(e) => setEmail(e.target.value)} className="h-11 rounded-xl" />
        </div>
        <div className="grid gap-2">
          <Label htmlFor="password">Password</Label>
          <PasswordInput id="password" value={password} onChange={setPassword} autoComplete="new-password" />
          <p className="text-xs text-muted-foreground">At least 8 characters.</p>
        </div>
        <div className="flex items-start gap-3">
          <Checkbox id="terms" checked={agreed} onCheckedChange={(v) => setAgreed(v === true)} className="mt-0.5" />
          <Label htmlFor="terms" className="text-sm leading-snug font-normal text-muted-foreground">
            I agree to the <Link to="/terms" className="text-primary hover:underline">Terms of Service</Link> and{" "}
            <Link to="/privacy" className="text-primary hover:underline">Privacy Policy</Link>.
          </Label>
        </div>
        <FormError message={error} />
        <Button type="submit" variant="hero" className="h-11 rounded-full" disabled={busy}>
          {busy ? <><Spinner /> Creating account…</> : "Create account"}
        </Button>
      </form>
    </AuthShell>
  );
}
