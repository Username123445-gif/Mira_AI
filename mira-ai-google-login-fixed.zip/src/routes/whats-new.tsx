import { Link, createFileRoute } from "@tanstack/react-router";
import {
  FileText,
  Globe,
  Image as ImageIcon,
  KeyRound,
  MessageSquareHeart,
  Mic,
  Palette,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Type,
  UserRound,
} from "lucide-react";

import { LegalPage } from "@/components/mira/LegalPage";
import { Button } from "@/components/ui/button";
import { MIRA_VERSION, MIRA_VERSION_SLUG } from "@/lib/version";

const desc = `What's new in Mira AI ${MIRA_VERSION}: a redesigned Settings page, a stronger Account page and more.`;

export const Route = createFileRoute("/whats-new")({
  head: () => ({
    meta: [
      { title: "What's New — Mira AI" },
      { name: "description", content: desc },
      { property: "og:title", content: "What's New — Mira AI" },
      { property: "og:description", content: desc },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: WhatsNew,
});

const RELEASES: {
  version: string;
  tagline: string;
  items: { icon: typeof Sparkles; title: string; text: string }[];
}[] = [
  {
    version: MIRA_VERSION,
    tagline: "Speak to Mira, generate images, and enjoy a full Settings makeover.",
    items: [
      {
        icon: Mic,
        title: "Speak your questions",
        text: "Tap the microphone in the chat box and talk instead of typing — your words appear in the message box, ready to edit or send.",
      },
      {
        icon: ImageIcon,
        title: "Image generation",
        text: "Turn on the Image button, describe a picture, and Mira draws it right in the chat. Finished pictures are saved to your account and live in Settings → Gallery.",
      },
      {
        icon: Palette,
        title: "Settings, redesigned",
        text: "Answers, Account, Gallery and Theme now open with the Mira mark, sit in matching cards, and fill the screen on phones.",
      },
      {
        icon: UserRound,
        title: "A richer Account page",
        text: "Your initials, name, email, the month you joined, how many chats and pictures you have, and how you sign in — all on one profile card.",
      },
      {
        icon: KeyRound,
        title: "Change password in Settings",
        text: "Update your password without leaving Settings, right where you manage everything else.",
      },
      {
        icon: ShieldCheck,
        title: "Your data, in your hands",
        text: "Download every chat as a file, or delete your whole chat history after confirming — no support request needed.",
      },
      {
        icon: Sparkles,
        title: `Version ${MIRA_VERSION}`,
        text: "Mira AI's beta keeps moving — this release is about making Settings and your account feel finished.",
      },
    ],
  },
  {
    version: "v0.1 Beta",
    tagline: "Mira's first beta: a fresh look, an installable app and live web answers.",
    items: [
      {
        icon: Type,
        title: "A fresh new look",
        text: "Mira AI upgraded its typography — elegant Fraunces headlines and clean Outfit body text, with a glowing gradient “AI” wordmark.",
      },
      {
        icon: Smartphone,
        title: "Install Mira as an app",
        text: "Add Mira AI to your phone's home screen and open it like a real app — no store download needed.",
      },
      {
        icon: Globe,
        title: "Live web answers",
        text: "Mira searches the internet in real time for up-to-date info like news and prices, with sources cited inline.",
      },
      {
        icon: MessageSquareHeart,
        title: "Welcome back, by name",
        text: "Mira greets you by name when you return, and you can set or change your name in Settings → Account.",
      },
      {
        icon: FileText,
        title: "Terms, Privacy and Refunds pages",
        text: "Clear public pages explain how your data is handled and our 30-day money-back guarantee.",
      },
    ],
  },
];

function WhatsNew() {
  return (
    <LegalPage title="What's new in Mira AI">
      <p>
        <span className="rounded-full border border-primary/40 bg-primary/10 px-2.5 py-0.5 text-xs font-medium tracking-wide text-primary">
          {MIRA_VERSION}
        </span>
      </p>
      <p>
        Here's everything that's new in Mira AI, newest first — starting with version{" "}
        {MIRA_VERSION_SLUG}, a full Settings makeover and more control over your account.
      </p>

      {RELEASES.map((release, index) => (
        <section key={release.version} className={index === 0 ? "" : "mt-10"}>
          <h2 className="font-display text-2xl tracking-tight">
            {release.version}
            <span className="ml-2 align-middle text-sm font-normal text-muted-foreground">
              {release.tagline}
            </span>
          </h2>

          <div className="not-prose mt-4 grid gap-3 sm:grid-cols-2">
            {release.items.map(({ icon: Icon, title, text }) => (
              <div
                key={title}
                className="flex items-start gap-3 rounded-2xl border border-border bg-card/70 p-4"
              >
                <span className="bg-gradient-mira mt-0.5 flex size-9 shrink-0 items-center justify-center rounded-lg text-primary-foreground">
                  <Icon className="size-4" />
                </span>
                <span>
                  <span className="block text-sm font-semibold text-foreground">{title}</span>
                  <span className="mt-0.5 block text-[13px] leading-snug text-muted-foreground">
                    {text}
                  </span>
                </span>
              </div>
            ))}
          </div>
        </section>
      ))}

      <div className="not-prose mt-8 flex flex-wrap gap-3">
        <Button asChild className="bg-gradient-mira rounded-xl text-primary-foreground hover:brightness-110">
          <Link to="/chat">Start chatting</Link>
        </Button>
      </div>
    </LegalPage>
  );
}
