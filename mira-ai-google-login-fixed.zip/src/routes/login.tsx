import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";

import { SocialSignIn } from "@/components/mira/AuthButtons";
import { AuthShell, FormError, PasswordInput, Spinner, friendlyAuthError, useRedirectIfSignedIn } from "@/components/mira/AuthShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Sign in — Mira AI" },
      { name: "description", content: "Sign in to Mira AI to pick up your chats on any device." },
      { property: "og:title", content: "Sign in — Mira AI" },
      { property: "og:description", content: "Sign in to Mira AI to pick up your chats on any device." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const navigate = useNavigate();
  const goToChat = () => navigate({ to: "/chat", replace: true });
  useRedirectIfSignedIn(goToChat);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    const { error: err } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    setBusy(false);
    if (err) return setError(friendlyAuthError(err));
    goToChat();
  }

  return (
    <AuthShell title="Welcome back" subtitle="Sign in to continue your chats with Mira."
      footer={<>Don't have an account? <Link to="/signup" className="text-primary hover:underline">Sign up</Link></>}>
      <SocialSignIn onSignedIn={goToChat} label="Sign in with Google" />
      <div className="my-6 flex items-center gap-3 text-xs text-muted-foreground">
        <span className="h-px flex-1 bg-border" /> or with email <span className="h-px flex-1 bg-border" />
      </div>
      <form onSubmit={onSubmit} className="grid gap-4">
        <div className="grid gap-2">
          <Label htmlFor="email">Email</Label>
          <Input id="email" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="h-11 rounded-xl" />
        </div>
        <div className="grid gap-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="password">Password</Label>
            <Link to="/forgot-password" className="text-xs text-muted-foreground hover:text-foreground">Forgot password?</Link>
          </div>
          <PasswordInput id="password" value={password} onChange={setPassword} autoComplete="current-password" />
        </div>
        <FormError message={error} />
        <Button type="submit" variant="hero" className="h-11 rounded-full" disabled={busy}>
          {busy ? <><Spinner /> Signing in…</> : "Sign in"}
        </Button>
      </form>
    </AuthShell>
  );
}
