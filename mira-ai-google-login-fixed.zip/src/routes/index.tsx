import { InstallAppButton } from "@/components/mira/InstallAppButton";
import { Link, createFileRoute } from "@tanstack/react-router";
import {
  ArrowRight,
  BookOpen,
  Globe,
  Image as ImageIcon,
  Lightbulb,
  Mic,
  Newspaper,
  PenLine,
  Rocket,
  Sparkles,
} from "lucide-react";

import { MiraLogo, MiraWordmark } from "@/components/mira/MiraLogo";
import { MiraOneOneCountdown } from "@/components/mira/MiraOneOneCountdown";
import { TestimonialsSpotlight } from "@/components/mira/TestimonialsSpotlight";
import { SiteFooter } from "@/components/mira/SiteFooter";
import { Button } from "@/components/ui/button";
import { useSession } from "@/hooks/use-session";
import { MIRA_VERSION } from "@/lib/version";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Mira AI — meet Mira, your helpful AI" },
      {
        name: "description",
        content: "Mira is a calm, capable AI that helps you think, write, learn and get things done.",
      },
      { property: "og:title", content: "Mira AI — meet Mira, your helpful AI" },
      {
        property: "og:description",
        content: "Mira is a calm, capable AI that helps you think, write, learn and get things done.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const highlights = [
  { icon: PenLine, title: "Write", text: "Drafts, emails and edits that sound like you." },
  { icon: Lightbulb, title: "Think", text: "Untangle ideas, plans and decisions out loud." },
  { icon: BookOpen, title: "Learn", text: "Clear explanations of anything, at your pace." },
  { icon: Globe, title: "Live web", text: "Up-to-date answers with sources, straight from the web." },
];

const news = [
  {
    icon: Mic,
    date: "Latest",
    title: `Mira ${MIRA_VERSION} is here`,
    text: "Speak your questions with the new microphone, and generate images right in the chat — saved to your Gallery.",
  },
  {
    icon: Rocket,
    date: "Coming Jan 1, 2027",
    title: "Mira AI 1.1",
    text: "Mira Memory, searchable chat history, custom instructions, regenerate response and a cleaner chat UI are on the way.",
  },
  {
    icon: ImageIcon,
    date: "Now live",
    title: "Install Mira as an app",
    text: "Add Mira AI to your phone or computer and open it like a real app — no store download needed.",
  },
];

function Index() {
  const { session, ready } = useSession();
  const signedIn = ready && !!session;

  return (
    <div className="bg-night relative min-h-screen overflow-hidden">
      <div aria-hidden className="bg-stars pointer-events-none absolute inset-0 opacity-60" />

      <MiraOneOneCountdown />

      <header className="relative z-10 mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <MiraWordmark />
        <div className="flex items-center gap-2">
        <InstallAppButton className="hidden sm:inline-flex" />
        {signedIn ? (
          <Button asChild variant="glass" className="rounded-full">
            <Link to="/chat">Open Mira</Link>
          </Button>
        ) : (
          <Button asChild variant="glass" className="rounded-full">
            <Link to="/login">Sign in</Link>
          </Button>
        )}
        </div>
      </header>

      <main className="relative z-10 mx-auto flex max-w-6xl flex-col items-center px-6 pt-10 pb-24 text-center md:pt-16">
        <MiraLogo glow className="animate-float size-40 md:size-52" />

        <div
          className="animate-rise mt-8 inline-flex items-center gap-2 rounded-full border border-border bg-card/60 px-4 py-1.5 text-xs font-medium text-muted-foreground backdrop-blur-sm"
          style={{ animationDelay: "60ms" }}
        >
          <Sparkles className="size-3.5 text-mira-periwinkle" />
          {MIRA_VERSION} · now with live web answers
        </div>

        <h1 className="animate-rise mt-6 font-display text-6xl leading-[0.95] tracking-tight md:text-8xl">
          Meet <span className="text-gradient-mira italic">Mira</span>
        </h1>
        <p
          className="animate-rise mt-6 max-w-xl text-lg text-muted-foreground md:text-xl"
          style={{ animationDelay: "120ms" }}
        >
          A calm, capable AI that helps you think, write, learn and get things done.
        </p>

        <div className="animate-rise mt-10 flex flex-col items-center gap-3 sm:flex-row" style={{ animationDelay: "220ms" }}>
          <Button asChild variant="hero" size="xl">
            <Link to="/chat">
              Start chatting <ArrowRight />
            </Link>
          </Button>
          {!signedIn && (
            <Button asChild variant="ghost" size="xl" className="text-muted-foreground">
              <Link to="/login">I already have an account</Link>
            </Button>
          )}
        </div>

        <section className="mt-24 grid w-full max-w-5xl gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {highlights.map(({ icon: Icon, title, text }, i) => (
            <div
              key={title}
              className="animate-rise rounded-2xl border border-border bg-card/60 p-6 text-left backdrop-blur-sm transition-colors hover:border-mira-periwinkle/40"
              style={{ animationDelay: `${320 + i * 90}ms` }}
            >
              <span className="bg-gradient-mira inline-flex size-9 items-center justify-center rounded-xl text-primary-foreground">
                <Icon className="size-4" />
              </span>
              <h2 className="mt-4 font-display text-2xl">{title}</h2>
              <p className="mt-1 text-sm text-muted-foreground">{text}</p>
            </div>
          ))}
        </section>

        <TestimonialsSpotlight />

        <section className="animate-rise mt-24 w-full max-w-5xl" style={{ animationDelay: "640ms" }}>
          <div className="flex items-center justify-center gap-2">
            <Newspaper className="size-5 text-mira-periwinkle" />
            <h2 className="font-display text-3xl md:text-4xl">
              Mira <span className="text-gradient-mira italic">News</span>
            </h2>
          </div>
          <p className="mt-2 text-sm text-muted-foreground md:text-base">
            The latest from the Mira AI team.
          </p>
          <div className="mt-8 grid gap-4 md:grid-cols-3">
            {news.map(({ icon: Icon, date, title, text }) => (
              <article
                key={title}
                className="rounded-2xl border border-border bg-card/60 p-6 text-left backdrop-blur-sm transition-colors hover:border-mira-periwinkle/40"
              >
                <div className="flex items-center justify-between">
                  <span className="bg-gradient-mira inline-flex size-9 items-center justify-center rounded-xl text-primary-foreground">
                    <Icon className="size-4" />
                  </span>
                  <span className="rounded-full border border-border bg-card/70 px-2.5 py-0.5 text-[11px] font-medium text-muted-foreground">
                    {date}
                  </span>
                </div>
                <h3 className="mt-4 font-display text-xl">{title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{text}</p>
              </article>
            ))}
          </div>
          <Button asChild variant="glass" className="mt-8 rounded-full">
            <Link to="/whats-new">
              Read the full changelog <ArrowRight />
            </Link>
          </Button>
        </section>
      </main>

      <SiteFooter />
    </div>
  );
}
