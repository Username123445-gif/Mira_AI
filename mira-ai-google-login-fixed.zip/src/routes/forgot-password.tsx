import { createFileRoute, Link } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";

import { AuthShell, FormError, FormNotice, Spinner, friendlyAuthError } from "@/components/mira/AuthShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/forgot-password")({
  head: () => ({
    meta: [
      { title: "Forgot password — Mira AI" },
      { name: "description", content: "Reset your Mira AI password with a secure link sent to your email." },
      { property: "og:title", content: "Forgot password — Mira AI" },
      { property: "og:description", content: "Reset your Mira AI password with a secure link sent to your email." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ForgotPasswordPage,
});

function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setNotice(null);
    const { error: err } = await supabase.auth.resetPasswordForEmail(email.trim(), {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    setBusy(false);
    if (err) return setError(friendlyAuthError(err));
    setNotice("If that email has a Mira account, a reset link is on its way.");
  }

  return (
    <AuthShell title="Reset your password" subtitle="We'll email you a secure link to set a new one."
      footer={<>Remembered it? <Link to="/login" className="text-primary hover:underline">Sign in</Link></>}>
      <form onSubmit={onSubmit} className="grid gap-4">
        <div className="grid gap-2">
          <Label htmlFor="email">Email</Label>
          <Input id="email" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="h-11 rounded-xl" />
        </div>
        <FormError message={error} />
        <FormNotice message={notice} />
        <Button type="submit" variant="hero" className="h-11 rounded-full" disabled={busy}>
          {busy ? <><Spinner /> Sending…</> : "Send reset link"}
        </Button>
      </form>
    </AuthShell>
  );
}
