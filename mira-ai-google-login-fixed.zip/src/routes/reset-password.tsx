import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { toast } from "sonner";

import { AuthShell, FormError, PasswordInput, Spinner, friendlyAuthError } from "@/components/mira/AuthShell";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Set a new password — Mira AI" },
      { name: "description", content: "Choose a new password for your Mira AI account." },
      { property: "og:title", content: "Set a new password — Mira AI" },
      { property: "og:description", content: "Choose a new password for your Mira AI account." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ResetPassword,
});

function ResetPassword() {
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    if (password.length < 8) return setError("Password must be at least 8 characters.");
    setBusy(true);
    const { error: err } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (err) return setError(friendlyAuthError(err));
    toast.success("Password updated.");
    navigate({ to: "/chat", replace: true });
  }

  return (
    <AuthShell title="Set a new password" subtitle="Pick something strong you haven't used before.">
      <form onSubmit={onSubmit} className="grid gap-4">
        <div className="grid gap-2">
          <Label htmlFor="new-password">New password</Label>
          <PasswordInput id="new-password" value={password} onChange={setPassword} autoComplete="new-password" />
        </div>
        <FormError message={error} />
        <Button type="submit" variant="hero" className="h-11 rounded-full" disabled={busy}>
          {busy ? <><Spinner /> Saving…</> : "Save password"}
        </Button>
      </form>
    </AuthShell>
  );
}
