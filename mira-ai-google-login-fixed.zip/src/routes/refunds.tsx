import { Link, createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/mira/LegalPage";

const desc = "Mira AI offers a 30-day money-back guarantee on Plus and Pro subscriptions.";
export const Route = createFileRoute("/refunds")({
  head: () => ({ meta: [
    { title: "Refund Policy — Mira AI" }, { name: "description", content: desc },
    { property: "og:title", content: "Refund Policy — Mira AI" }, { property: "og:description", content: desc },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" },
  ] }),
  component: Refunds,
});

function Refunds() {
  return (
    <LegalPage title="Refund Policy" updated="November 22, 2026">
      <p><strong>30-day money-back guarantee.</strong> If you're not satisfied with a Mira purchase, you can request a full refund within 30 days of your order date.</p>
      <h2>How to request a refund</h2>
      <p>Refunds are processed by our payment provider and Merchant of Record, Paddle. To request one, visit <a href="https://paddle.net" target="_blank" rel="noreferrer">paddle.net</a> and look up your order using the email on your receipt, or reply to your Paddle receipt email. You can also contact Mira AI support and we'll help.</p>
      <h2>Cancelling</h2>
      <p>You can cancel at any time by contacting Mira AI support or your payment provider. Cancelling stops future renewals; it does not by itself issue a refund, so request one as described above if you're within 30 days.</p>
      <p>See also our <Link to="/terms">Terms</Link> and <a href="https://www.paddle.com/legal/refund-policy" target="_blank" rel="noreferrer">Paddle's refund policy</a>.</p>
    </LegalPage>
  );
}
