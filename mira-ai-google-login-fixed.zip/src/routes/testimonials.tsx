import { Link, createFileRoute } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, Quote, Star } from "lucide-react";

import { ReviewsSection } from "@/components/mira/ReviewsSection";
import { SiteFooter } from "@/components/mira/SiteFooter";
import { Button } from "@/components/ui/button";

const desc =
  "See how students, creators and professionals use Mira AI every day — real stories and real results from the Mira community.";

export const Route = createFileRoute("/testimonials")({
  head: () => ({
    meta: [
      { title: "Testimonials — Mira AI" },
      { name: "description", content: desc },
      { property: "og:title", content: "Testimonials — Mira AI" },
      { property: "og:description", content: desc },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
    links: [{ rel: "canonical", href: "https://mira-ai-assistance.lovable.app/testimonials" }],
  }),
  component: Testimonials,
});

const stats = [
  { value: "4.9/5", label: "Average user rating" },
  { value: "10k+", label: "Questions answered weekly" },
  { value: "98%", label: "Would recommend Mira" },
];

const testimonials = [
  {
    quote:
      "Mira helped me break down my biology revision into a plan I could actually follow. I went from panicking before exams to walking in prepared — my grades went up a full letter.",
    name: "Amara Osei",
    role: "University student",
    result: "Raised her exam grades",
  },
  {
    quote:
      "I use Mira every morning to plan my content calendar. What used to take me two hours of brainstorming now takes fifteen minutes, and the ideas are genuinely better.",
    name: "Diego Ramírez",
    role: "Content creator",
    result: "Saves 2 hours a day",
  },
  {
    quote:
      "Running a small shop means doing everything myself. Mira writes my product descriptions, answers my bookkeeping questions and even helped me plan a sale that sold out in a weekend.",
    name: "Priya Nair",
    role: "Small business owner",
    result: "Sold out her weekend sale",
  },
  {
    quote:
      "The live web answers are the killer feature. I ask Mira about prices and news and get cited, up-to-date answers instead of guessing. It's replaced three other apps for me.",
    name: "Tom Becker",
    role: "Freelance designer",
    result: "Replaced three other apps",
  },
  {
    quote:
      "I was nervous about AI, but Mira feels like a patient friend. It helped me write a speech for my daughter's wedding and I cried reading it back.",
    name: "Linda Marsh",
    role: "Everyday curious person",
    result: "Wrote her wedding speech",
  },
  {
    quote:
      "Our study group shares one Mira chat to quiz each other before tests. Five of us passed our finals this term — Mira was basically our sixth group member.",
    name: "Jayden Cole",
    role: "High school student",
    result: "Passed all his finals",
  },
];

function Testimonials() {
  return (
    <div className="bg-stars min-h-screen">
      <main className="mx-auto max-w-5xl px-6 py-10">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="size-4" /> Back to Mira AI
        </Link>

        <section className="animate-rise mt-12 flex flex-col items-center text-center">
          <span className="inline-flex items-center gap-1.5 rounded-full border border-primary/40 bg-primary/10 px-4 py-1.5 text-xs font-medium text-primary">
            <Star className="size-3.5 fill-current" /> Loved by the Mira community
          </span>
          <h1 className="mt-6 font-display text-5xl leading-[1.05] tracking-tight md:text-6xl">
            Real people, <span className="text-gradient-mira italic">real results</span>
          </h1>
          <p className="mt-5 max-w-2xl text-muted-foreground md:text-lg">{desc}</p>

          <div className="mt-10 grid w-full max-w-2xl grid-cols-3 gap-3">
            {stats.map((s) => (
              <div
                key={s.label}
                className="rounded-2xl border border-border bg-card/40 px-3 py-5 backdrop-blur-sm"
              >
                <p className="text-gradient-mira font-display text-2xl italic md:text-3xl">
                  {s.value}
                </p>
                <p className="mt-1 text-[11px] text-muted-foreground md:text-xs">{s.label}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="mt-20 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {testimonials.map((t, i) => (
            <figure
              key={t.name}
              className="animate-rise flex flex-col rounded-2xl border border-border bg-card/40 p-6 backdrop-blur-sm transition-colors hover:border-mira-periwinkle/40"
              style={{ animationDelay: `${i * 80}ms` }}
            >
              <Quote className="size-5 text-mira-periwinkle" />
              <blockquote className="mt-4 flex-1 text-sm leading-relaxed text-foreground/90">
                “{t.quote}”
              </blockquote>
              <figcaption className="mt-5 border-t border-border pt-4">
                <p className="font-display text-base">{t.name}</p>
                <p className="text-xs text-muted-foreground">{t.role}</p>
                <p className="mt-2 inline-flex rounded-full border border-primary/30 bg-primary/10 px-2.5 py-0.5 text-[11px] font-medium text-primary">
                  {t.result}
                </p>
              </figcaption>
            </figure>
          ))}
        </section>

        <ReviewsSection />

        <section className="relative mt-24 overflow-hidden rounded-3xl border border-border bg-card/40 p-10 text-center">
          <span
            aria-hidden
            className="bg-gradient-mira pointer-events-none absolute -top-24 left-1/2 size-64 -translate-x-1/2 rounded-full opacity-20 blur-3xl"
          />
          <h2 className="relative font-display text-3xl md:text-4xl">
            Ready to write <span className="text-gradient-mira italic">your story?</span>
          </h2>
          <p className="relative mx-auto mt-3 max-w-lg text-muted-foreground">
            Join the community and see what Mira can do for you — free to start.
          </p>
          <Button asChild variant="hero" size="xl" className="relative mt-6">
            <Link to="/login">
              Try Mira free <ArrowRight />
            </Link>
          </Button>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}
