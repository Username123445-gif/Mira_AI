import { createFileRoute, redirect } from "@tanstack/react-router";

// Old address kept working: everything now lives at /login.
export const Route = createFileRoute("/auth")({
  beforeLoad: () => {
    throw redirect({ to: "/login", replace: true });
  },
});
