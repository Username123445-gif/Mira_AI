import { createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/mira/LegalPage";

const desc = "How Mira AI collects, uses and protects your personal data.";
export const Route = createFileRoute("/privacy")({
  head: () => ({ meta: [
    { title: "Privacy Notice — Mira AI" }, { name: "description", content: desc },
    { property: "og:title", content: "Privacy Notice — Mira AI" }, { property: "og:description", content: desc },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" },
  ] }),
  component: Privacy,
});

function Privacy() {
  return (
    <LegalPage title="Privacy Notice" updated="November 22, 2026">
      <p><strong>Mira AI</strong> is the data controller for personal data processed through the Mira AI assistant. This notice explains what we collect, why, and your choices.</p>
      <h2>What we collect and why</h2>
      <ul>
        <li><strong>Account data</strong> (email, display name, login credentials, or Google sign-in profile) — to create and secure your account. Legal basis: contract.</li>
        <li><strong>Chats</strong> (your messages, files you attach, Mira's replies and cited sources) and <strong>settings</strong> (answer style, "About you") — to provide the Service and keep your history. Legal basis: contract.</li>
        <li><strong>Subscription status</strong> (plan, renewal dates, customer reference from Paddle) — to give paid features to the account that paid. Legal basis: contract.</li>
        <li><strong>Technical and usage data</strong> (described below) — to keep the site secure, fix errors and improve Mira. Legal basis: legitimate interests.</li>
        <li><strong>Support messages</strong> — to answer you. Legal basis: legitimate interests.</li>
      </ul>
      <h2>Who we share data with</h2>
      <ul>
        <li><strong>Service providers</strong>: our hosting, database and sign-in provider (Lovable Cloud); AI model providers that generate answers and perform web searches for your prompts (via the Lovable AI Gateway, including OpenAI); Google if you sign in with Google.</li>
        <li><strong>Paddle</strong>, our Merchant of Record, for selling subscriptions, payments, subscription management, tax compliance and invoicing.</li>
        <li><strong>Professional advisers</strong> (legal, accounting) where needed.</li>
        <li><strong>Authorities</strong> where required by law.</li>
      </ul>
      <p>We do not sell your personal data.</p>
      <h2>Visitor analytics</h2>
      <p>Our site uses Lovable's built-in visitor analytics. It uses no cookies, stores nothing on your device, doesn't keep IP addresses and doesn't identify visitors. It records the pages visited, where visitors came from, their country, browser, operating system and device type, how long they stay, how fast pages load, errors, and which buttons and links are clicked. Detailed data is kept for 90 days and daily summaries for a year. This is recorded for every visitor. Lovable collects this data for us. <a href="https://lovable.dev/privacy" target="_blank" rel="noreferrer">Lovable's privacy policy</a> explains how it handles it.</p>
      <h2>Cookies and local storage</h2>
      <p>We don't use advertising or analytics cookies. We use essential browser storage to keep you signed in and to remember that you've seen update announcements. Paddle's checkout may set its own cookies when you pay. You can clear this storage in your browser settings, which signs you out.</p>
      <h2>Retention</h2>
      <p>We keep account data, chats and settings while your account is active. You can delete chats at any time. When data is no longer needed, or after you ask us to delete your account, we delete or anonymise it, except where we must keep records by law.</p>
      <h2>International transfers</h2>
      <p>Our providers may process data outside your country, including in the United States. Where required, we rely on safeguards such as Standard Contractual Clauses or adequacy decisions.</p>
      <h2>Your rights</h2>
      <p>Depending on where you live, you may have the right to access, correct, delete, restrict or object to processing of your data, to data portability, and to withdraw consent. You can also complain to your local data protection authority. Contact Mira AI through the support details on this site; we respond within one month.</p>
      <h2>Security</h2>
      <p>We use appropriate technical and organisational measures, including encryption in transit, access controls, and account-level data separation so only you can read your chats.</p>
    </LegalPage>
  );
}
