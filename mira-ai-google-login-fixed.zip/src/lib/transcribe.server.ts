const MAX_BYTES = 24 * 1024 * 1024;
export const MAX_TRANSCRIBE_BYTES = MAX_BYTES;

export function transcribe(apiKey: string, file: File, signal?: AbortSignal) {
  const form = new FormData();
  form.append("model", "openai/gpt-transcribe");
  form.append("file", file, file.name);
  form.append("response_format", "json");
  form.append("stream", "true");
  return fetch("https://ai.gateway.lovable.dev/v1/audio/transcriptions", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}` },
    body: form,
    ...(signal ? { signal } : {}),
  });
}
