/** Names come from account metadata, never from the private email address. */
export function accountName(metadata: Record<string, unknown>): string | null {
  for (const key of ["display_name", "full_name", "name"]) {
    const value = metadata[key];
    if (typeof value !== "string") continue;
    const name = value.trim().replace(/\s+/g, " ");
    if (name && !name.includes("@")) return name;
  }
  return null;
}