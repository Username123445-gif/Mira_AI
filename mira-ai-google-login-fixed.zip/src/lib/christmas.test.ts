import { describe, expect, it } from "vitest";
import { isChristmasUpdateActive } from "./christmas";
describe("christmas update", () => {
  it("shows on Dec 31 2026", () => expect(isChristmasUpdateActive(new Date(2026, 11, 31, 23, 59))).toBe(true));
  it("ends Jan 1 2027", () => expect(isChristmasUpdateActive(new Date(2027, 0, 1, 0, 0))).toBe(false));
});
