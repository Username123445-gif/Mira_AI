import { useQuery } from "@tanstack/react-query";
import { settingsQuery } from "@/lib/settings";
import { supabase } from "@/integrations/supabase/client";

const BUCKET = "avatars";
const MAX_BYTES = 5 * 1024 * 1024;
const ALLOWED = new Set(["image/png", "image/jpeg", "image/webp", "image/gif"]);

/** Upload a new profile picture and remember it on the user's settings. Returns nothing; throws on failure. */
export async function uploadAvatar(userId: string, file: File): Promise<void> {
  if (!ALLOWED.has(file.type)) throw new Error("Use a PNG, JPG, WebP or GIF image.");
  if (file.size > MAX_BYTES) throw new Error("That image is over 5 MB. Pick a smaller one.");
  const ext = file.type === "image/png" ? "png" : file.type === "image/webp" ? "webp" : file.type === "image/gif" ? "gif" : "jpg";
  const path = `${userId}/avatar.${ext}`;
  const up = await supabase.storage.from(BUCKET).upload(path, file, { contentType: file.type, upsert: true });
  if (up.error) throw up.error;
  await saveAvatarPath(userId, path);
}

/** Remove the user's profile picture. */
export async function removeAvatar(userId: string, path: string): Promise<void> {
  await saveAvatarPath(userId, null);
  await supabase.storage.from(BUCKET).remove([path]);
}

/** Short-lived private link to the user's avatar, or null when none is set. */
export async function avatarUrl(path: string | null): Promise<string | null> {
  if (!path) return null;
  const { data, error } = await supabase.storage.from(BUCKET).createSignedUrl(path, 60 * 60);
  if (error) return null;
  return data.signedUrl;
}

async function saveAvatarPath(userId: string, path: string | null): Promise<void> {
  const changes = { avatar_path: path, updated_at: new Date().toISOString() };
  const { data: existing, error: readError } = await supabase.from("user_settings").select("user_id").eq("user_id", userId).maybeSingle();
  if (readError) throw new Error(readError.message);
  const { error } = existing
    ? await supabase.from("user_settings").update(changes).eq("user_id", userId)
    : await supabase.from("user_settings").insert({ user_id: userId, ...changes });
  if (error) throw new Error(error.message);
}

/** Signed link to the signed-in user's saved profile picture; refreshes whenever settings change. */
export function useMyAvatarUrl(): string | null {
  const { data: settings } = useQuery(settingsQuery());
  const path = settings?.avatar_path ?? null;
  const { data } = useQuery({ queryKey: ["avatar-url", path], queryFn: () => avatarUrl(path), enabled: !!path, staleTime: 50 * 60 * 1000 });
  return path ? (data ?? null) : null;
}
