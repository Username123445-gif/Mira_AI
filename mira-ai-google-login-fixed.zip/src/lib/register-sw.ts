// The only place Mira's app service worker is registered.
const PREVIEW_LABEL = /^(?:id-preview|preview)(?:-[a-z0-9]+)?--.+$/;

function refused(): boolean {
  if (!import.meta.env.PROD) return true;
  if (window.self !== window.top) return true;
  if (new URLSearchParams(window.location.search).get("sw") === "off") return true;
  const h = window.location.hostname.toLowerCase();
  const label = h.split(".")[0] ?? "";
  for (const d of ["lovable.app", "gpt-eng.com", "gptengineer.run"]) {
    if (h.endsWith(`.${d}`) && (PREVIEW_LABEL.test(label) || /^project--.+-dev$/.test(label))) return true;
  }
  for (const d of ["lovableproject.com", "lovableproject-dev.com", "beta.lovable.dev"]) {
    if (h === d || h.endsWith(`.${d}`)) return true;
  }
  return false;
}

async function unregisterAppSw() {
  const regs = await navigator.serviceWorker.getRegistrations();
  await Promise.all(
    regs.filter((r) => (r.active ?? r.waiting ?? r.installing)?.scriptURL.endsWith("/sw.js")).map((r) => r.unregister()),
  );
}

export function registerMiraServiceWorker() {
  if (typeof window === "undefined" || !("serviceWorker" in navigator)) return;
  if (refused()) {
    void unregisterAppSw();
    return;
  }
  navigator.serviceWorker.register("/sw.js").then((reg) => {
    // Check for a newly published version every hour and when the app regains focus.
    setInterval(() => void reg.update(), 60 * 60 * 1000);
    document.addEventListener("visibilitychange", () => document.visibilityState === "visible" && void reg.update());
  }).catch(() => {});
  let reloaded = !navigator.serviceWorker.controller; // skip reload on first install
  navigator.serviceWorker.addEventListener("controllerchange", () => {
    if (reloaded) return;
    reloaded = true;
    window.location.reload();
  });
}
