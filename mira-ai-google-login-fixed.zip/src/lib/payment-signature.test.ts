import { describe, expect, it } from "vitest";
import { verifyPaymentSignature } from "@/lib/payments.server";

describe("verified payment events", () => {
  it("accepts a signed payment event and rejects modified or expired events", async () => {
    const secret = "test-signing-secret";
    const timestamp = "1795312800";
    const body = '{"event_type":"subscription.created"}';
    const encoder = new TextEncoder();
    const key = await crypto.subtle.importKey("raw", encoder.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
    const signed = await crypto.subtle.sign("HMAC", key, encoder.encode(`${timestamp}:${body}`));
    const hash = Array.from(new Uint8Array(signed), (b) => b.toString(16).padStart(2, "0")).join("");
    const signature = `ts=${timestamp};h1=${hash}`;
    const now = Number(timestamp) * 1000;
    expect(await verifyPaymentSignature(body, signature, secret, now)).toBe(true);
    expect(await verifyPaymentSignature(body + " ", signature, secret, now)).toBe(false);
    expect(await verifyPaymentSignature(body, signature, secret, now + 301000)).toBe(false);
    expect(await verifyPaymentSignature(body, null, secret, now)).toBe(false);
  });
});