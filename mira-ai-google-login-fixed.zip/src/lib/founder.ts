// Only the account that owns Mira AI shows the "Mira AI founder" badge.
// Set MIRA_FOUNDER_EMAIL to the email on that account; nobody else gets it.
export const MIRA_FOUNDER_EMAIL = "mikhailharris14@gmail.com";

export function isMiraFounder(
  email?: string | null,
  founderEmail: string = MIRA_FOUNDER_EMAIL,
): boolean {
  const founder = founderEmail.trim().toLowerCase();
  if (!founder || !email) return false;
  return email.trim().toLowerCase() === founder;
}
