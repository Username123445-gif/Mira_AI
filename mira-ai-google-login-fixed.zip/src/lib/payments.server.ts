import type { SupabaseClient } from "@supabase/supabase-js";
import { z } from "zod";
import type { Database } from "@/integrations/supabase/types";
import { isMiraFounder } from "@/lib/founder";
import { getPaymentEnvironment, paidPlan, type BillingState, type PaymentEnvironment } from "@/lib/billing";

export async function readBilling(client: SupabaseClient<Database>, userId: string): Promise<BillingState> {
  const environment = getPaymentEnvironment();
  const { data, error } = await client.from("subscriptions").select("*").eq("user_id", userId)
    .eq("environment", environment).order("created_at", { ascending: false });
  if (error) throw new Error("Couldn't verify your subscription. Please try again.");
  const rows = data ?? [];
  // The founder account gets Mira Pro for free; email is verified server-side by the auth service.
  const { data: auth } = await client.auth.getUser();
  const founder = auth.user?.id === userId && !!auth.user.email_confirmed_at && isMiraFounder(auth.user.email);
  return { environment, plan: founder ? "pro" : paidPlan(rows, environment), subscription: rows.find((row) => row.status !== "canceled") ?? null };
}

export async function gatewayFetch(environment: PaymentEnvironment, path: string, init?: RequestInit): Promise<Response> {
  const connectionKey = process.env[environment === "sandbox" ? "PADDLE_SANDBOX_API_KEY" : "PADDLE_LIVE_API_KEY"];
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!connectionKey || !apiKey) throw new Error("Payments aren't configured yet.");
  const response = await fetch(`https://connector-gateway.lovable.dev/paddle${path}`, {
    ...init,
    headers: { "Content-Type": "application/json", "X-Connection-Api-Key": connectionKey, "Lovable-API-Key": apiKey, ...init?.headers },
  });
  if (!response.ok) {
    const body = await response.text();
    // Do not log customer data or portal URLs from provider responses.
    let code = "unknown";
    try { code = z.object({ error: z.object({ code: z.string() }) }).parse(JSON.parse(body)).error.code; } catch { /* non-JSON error */ }
    console.error("[payments] Provider error", response.status, code);
    if (code === "transaction_checkout_not_enabled") throw new Error("Live payments need verification and approval before checkout can open.");
    throw new Error(`Payment service error (${response.status}, ${code}). Please try again.`);
  }
  return response;
}

export async function resolvePrice(priceId: string, environment: PaymentEnvironment): Promise<string> {
  const response = await gatewayFetch(environment, `/prices?external_id=${encodeURIComponent(priceId)}`);
  const result = z.object({ data: z.array(z.object({ id: z.string(), status: z.string() })) }).parse(await response.json());
  const price = result.data.find((row) => row.status === "active");
  if (!price) throw new Error("This plan isn't available for checkout yet. Please try again after payments are ready.");
  return price.id;
}

export async function verifyPaymentSignature(body: string, signature: string | null, secret: string, now = Date.now()): Promise<boolean> {
  if (!signature) return false;
  const fields = signature.split(";").map((field) => field.trim().split("="));
  const timestamp = fields.find(([key]) => key === "ts")?.[1];
  const hashes = fields.filter(([key]) => key === "h1").map(([, value]) => value);
  if (!timestamp || !/^\d+$/.test(timestamp) || Math.abs(now / 1000 - Number(timestamp)) > 300) return false;
  const encoder = new TextEncoder();
  const key = await crypto.subtle.importKey("raw", encoder.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const signed = await crypto.subtle.sign("HMAC", key, encoder.encode(`${timestamp}:${body}`));
  const expected = Array.from(new Uint8Array(signed), (byte) => byte.toString(16).padStart(2, "0")).join("");
  return hashes.some((hash) => {
    if (!hash || hash.length !== expected.length) return false;
    let difference = 0;
    for (let i = 0; i < expected.length; i++) difference |= expected.charCodeAt(i) ^ hash.charCodeAt(i);
    return difference === 0;
  });
}

const subscriptionSchema = z.object({
  id: z.string(), customer_id: z.string(), status: z.string(), updated_at: z.string().datetime(),
  custom_data: z.object({ userId: z.string().uuid() }),
  current_billing_period: z.object({ starts_at: z.string(), ends_at: z.string() }).nullable(),
  scheduled_change: z.object({ action: z.string() }).nullable(),
  items: z.array(z.object({
    price: z.object({ import_meta: z.object({ external_id: z.string() }).nullable() }),
    product: z.object({ import_meta: z.object({ external_id: z.string() }).nullable() }),
  })).length(1),
});

/** Re-read provider state instead of trusting an older webhook snapshot. */
export async function syncSubscription(id: string, environment: PaymentEnvironment): Promise<void> {
  const response = await gatewayFetch(environment, `/subscriptions/${encodeURIComponent(id)}`);
  const { data } = z.object({ data: subscriptionSchema }).parse(await response.json());
  const item = data.items[0];
  const priceId = item?.price.import_meta?.external_id;
  const productId = item?.product.import_meta?.external_id;
  const knownPrice =
    (productId === "mira_plus" && ["mira_plus_monthly", "mira_plus_yearly"].includes(priceId ?? "")) ||
    (productId === "mira_pro" && ["mira_pro_monthly", "mira_pro_yearly"].includes(priceId ?? "")) ||
    (productId === "mira_ultra" && ["mira_ultra_monthly", "mira_ultra_yearly"].includes(priceId ?? ""));
  if (!knownPrice) {
    throw new Error("Unrecognized Mira subscription product.");
  }
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { error } = await supabaseAdmin.rpc("apply_mira_subscription", { payload: {
    user_id: data.custom_data.userId, paddle_subscription_id: data.id, paddle_customer_id: data.customer_id,
    product_id: productId, price_id: priceId, status: data.status,
    current_period_start: data.current_billing_period?.starts_at ?? null,
    current_period_end: data.current_billing_period?.ends_at ?? null,
    cancel_at_period_end: data.scheduled_change?.action === "cancel", environment,
    provider_updated_at: data.updated_at,
  } });
  if (error) throw new Error("Couldn't save payment confirmation.");
}