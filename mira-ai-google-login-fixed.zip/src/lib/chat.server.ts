import { createOpenAI } from "@ai-sdk/openai";
import { createClient } from "@supabase/supabase-js";
import {
  APICallError,
  convertToModelMessages,
  streamText,
  type UIMessage,
} from "ai";
import { z } from "zod";

import type { Database, Json } from "@/integrations/supabase/types";
import {
  createLovableAiGatewayRunIdFetch,
  getLovableAiGatewayRunId,
  withLovableAiGatewayRunIdHeader,
} from "@/lib/ai/run-id.server";
import { MIRA_INSTRUCTIONS, friendlyAiError, titleFromText } from "@/lib/ai/mira-prompt";
import { getPlan, personalInstructions } from "@/lib/plans";
import { readBilling } from "@/lib/payments.server";

const GATEWAY_URL = "https://ai.gateway.lovable.dev/v1";

const bodySchema = z.object({
  threadId: z.string().uuid(),
  message: z.object({
    id: z.string().min(1),
    role: z.literal("user"),
    parts: z.array(z.record(z.unknown())).min(1),
  }),
});

function text(status: number, message: string) {
  return new Response(message, { status, headers: { "content-type": "text/plain; charset=utf-8" } });
}

function createSupabaseFetch(supabaseKey: string): typeof fetch {
  return (input, init) => {
    const headers = new Headers(
      typeof Request !== "undefined" && input instanceof Request ? input.headers : undefined,
    );
    if (init?.headers) new Headers(init.headers).forEach((value, key) => headers.set(key, value));
    if (
      (supabaseKey.startsWith("sb_publishable_") || supabaseKey.startsWith("sb_secret_")) &&
      headers.get("Authorization") === `Bearer ${supabaseKey}`
    ) {
      headers.delete("Authorization");
    }
    headers.set("apikey", supabaseKey);
    return fetch(input, { ...init, headers });
  };
}

const MAX_SAVED_SOURCES = 8;

/** Keep saved replies small: at most a handful of unique web sources. */
export function compactParts(parts: UIMessage["parts"]): UIMessage["parts"] {
  const seen = new Set<string>();
  return parts.filter((p) => {
    if (p.type !== "source-url") return true;
    if (seen.has(p.url) || seen.size >= MAX_SAVED_SOURCES) return false;
    seen.add(p.url);
    return true;
  });
}

function textOf(message: UIMessage) {
  return message.parts
    .map((p) => (p.type === "text" ? p.text : ""))
    .join(" ")
    .trim();
}

export async function handleChat(request: Request): Promise<Response> {
  const SUPABASE_URL = process.env["SUPABASE_URL"];
  const SUPABASE_PUBLISHABLE_KEY = process.env["SUPABASE_PUBLISHABLE_KEY"];
  const LOVABLE_API_KEY = process.env["LOVABLE_API_KEY"];
  if (!SUPABASE_URL || !SUPABASE_PUBLISHABLE_KEY || !LOVABLE_API_KEY) {
    console.error("[chat] Missing server configuration");
    return text(500, "Mira isn't set up correctly yet. Please try again later.");
  }

  // 1. Verify the caller's session.
  const authHeader = request.headers.get("authorization") ?? "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : "";
  if (!token || token.split(".").length !== 3) return text(401, "Please sign in to chat with Mira.");

  const supabase = createClient<Database>(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
    global: {
      fetch: createSupabaseFetch(SUPABASE_PUBLISHABLE_KEY),
      headers: { Authorization: `Bearer ${token}` },
    },
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
  });
  const { data: claimsData, error: claimsError } = await supabase.auth.getClaims(token);
  const userId = claimsData?.claims?.sub;
  if (claimsError || !userId) return text(401, "Your session has expired. Please sign in again.");

  // 2. Validate input.
  let parsed: z.infer<typeof bodySchema>;
  try {
    parsed = bodySchema.parse(await request.json());
  } catch {
    return text(400, "That message couldn't be sent. Please try again.");
  }
  const { threadId } = parsed;
  const userMessage = parsed.message as unknown as UIMessage;

  // 3. The thread must belong to the caller (RLS scopes the read to their rows).
  const { data: thread, error: threadError } = await supabase
    .from("threads")
    .select("id, title")
    .eq("id", threadId)
    .maybeSingle();
  if (threadError) {
    console.error("[chat] thread lookup failed", threadError);
    return text(500, "Mira couldn't open this chat. Please try again.");
  }
  if (!thread) return text(404, "This chat doesn't exist or isn't yours.");

  const { data: rows, error: historyError } = await supabase
    .from("messages")
    .select("message_id, role, parts")
    .eq("thread_id", threadId)
    .order("created_at", { ascending: true });
  if (historyError) {
    console.error("[chat] history load failed", historyError);
    return text(500, "Mira couldn't load this chat. Please try again.");
  }

  // Regenerate: when this message is already saved, drop it and everything after so Mira answers it afresh.
  const allRows = rows ?? [];
  const existingAt = allRows.findIndex((r) => r.message_id === userMessage.id);
  if (existingAt >= 0) {
    const stale = allRows.slice(existingAt + 1).map((r) => r.message_id);
    if (stale.length) {
      const { error: staleError } = await supabase.from("messages").delete().eq("thread_id", threadId).in("message_id", stale);
      if (staleError) console.error("[chat] clearing old reply failed", staleError);
    }
  }
  const history: UIMessage[] = (existingAt >= 0 ? allRows.slice(0, existingAt) : allRows)
    .map((r) => ({
      id: r.message_id,
      role: r.role as UIMessage["role"],
      parts: r.parts as unknown as UIMessage["parts"],
    }));

  // 4. Persist the user's message before streaming.
  const { error: saveUserError } = await supabase.from("messages").upsert(
    {
      thread_id: threadId,
      user_id: userId,
      message_id: userMessage.id,
      role: "user",
      parts: userMessage.parts as unknown as Json,
    },
    { onConflict: "thread_id,message_id" },
  );
  if (saveUserError) {
    console.error("[chat] saving user message failed", saveUserError);
    return text(500, "Mira couldn't save your message. Please try again.");
  }

  const threadUpdate: { updated_at: string; title?: string } = { updated_at: new Date().toISOString() };
  if (history.length === 0 && thread.title === "New chat") {
    threadUpdate.title = titleFromText(textOf(userMessage));
  }
  const { error: threadUpdateError } = await supabase.from("threads").update(threadUpdate).eq("id", threadId);
  if (threadUpdateError) console.error("[chat] thread update failed", threadUpdateError);

  const messages = [...history, userMessage];

  // Only this caller's verified subscription unlocks paid benefits; settings shape the style.
  const { data: settings, error: settingsError } = await supabase
    .from("user_settings")
    .select("answer_style, about_me")
    .maybeSingle();
  if (settingsError) console.error("[chat] settings load failed", settingsError);
  const { data: memories, error: memoryError } = await supabase
    .from("user_memories").select("content").order("created_at").limit(50);
  if (memoryError) console.error("[chat] memory load failed", memoryError);
  const memoryText = memories?.length
    ? `\n\nThings the user asked you to remember (use when relevant):\n${memories.map((m) => `- ${m.content}`).join("\n")}`
    : "";
  let paidPlanId = "free";
  try {
    paidPlanId = (await readBilling(supabase, userId)).plan;
  } catch (error) {
    console.error("[chat] subscription check failed; using Free", error instanceof Error ? error.message : "unknown");
  }
  const plan = getPlan(paidPlanId);

  // Resend only plain text/files: reasoning, web-search calls and sources are display-only,
  // so history never depends on encrypted or provider-executed items.
  const modelMessages = await convertToModelMessages(
    messages.map((m) => ({ ...m, parts: m.parts.filter((p) => p.type === "text" || p.type === "file") })),
  );

  // 5. Stream Mira's reply through Lovable AI.
  const runIdFetch = createLovableAiGatewayRunIdFetch(getLovableAiGatewayRunId(request));
  const provider = createOpenAI({
    baseURL: GATEWAY_URL,
    apiKey: LOVABLE_API_KEY,
    headers: { "Lovable-API-Key": LOVABLE_API_KEY, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    fetch: runIdFetch.fetch,
  });

  const result = streamText({
    model: provider.responses(plan.model),
    instructions: `${MIRA_INSTRUCTIONS}\n\n${personalInstructions(settings ?? {})}${memoryText}\n\nToday's date (UTC): ${new Date().toISOString().slice(0, 10)}.`,
    messages: modelMessages,
    tools: { web_search: provider.tools.webSearch({ searchContextSize: plan.webSearchDepth }) },
    abortSignal: request.signal,
    providerOptions: {
      openai: {
        forceReasoning: true,
        reasoningEffort: plan.reasoningEffort,
        reasoningSummary: "auto",
        store: false,
        include: ["reasoning.encrypted_content"],
      },
    },
  });

  const response = result.toUIMessageStreamResponse({
    originalMessages: messages,
    sendReasoning: true,
    sendSources: true,
    generateMessageId: () => crypto.randomUUID(),
    onError: (error) => {
      const status = APICallError.isInstance(error) ? error.statusCode : undefined;
      console.error("[chat] AI stream error", status, error);
      return friendlyAiError(status);
    },
    onFinish: async ({ responseMessage }) => {
      if (!responseMessage || responseMessage.role !== "assistant") return;
      const hasContent = responseMessage.parts.some(
        (p) => (p.type === "text" && p.text.trim()) || p.type === "reasoning",
      );
      if (!hasContent) return;
      const { error } = await supabase.from("messages").upsert(
        {
          thread_id: threadId,
          user_id: userId,
          message_id: responseMessage.id,
          role: "assistant",
          parts: compactParts(responseMessage.parts) as unknown as Json,
        },
        { onConflict: "thread_id,message_id" },
      );
      if (error) console.error("[chat] saving Mira's reply failed", error);
      await supabase.from("threads").update({ updated_at: new Date().toISOString() }).eq("id", threadId);
    },
  });

  return withLovableAiGatewayRunIdHeader(response, runIdFetch);
}
