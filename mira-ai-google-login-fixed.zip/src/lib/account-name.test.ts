import { describe, expect, it } from "vitest";

import { accountName } from "./account-name";

describe("account names", () => {
  it("uses the saved name before the sign-in provider name", () => {
    expect(accountName({ display_name: "Mikhail Harris", full_name: "Other Name" })).toBe("Mikhail Harris");
  });

  it("supports names supplied by social sign-in", () => {
    expect(accountName({ full_name: "Mikhail Harris" })).toBe("Mikhail Harris");
    expect(accountName({ name: "Mikhail" })).toBe("Mikhail");
  });

  it("handles missing or malformed names without exposing an email address", () => {
    expect(accountName({ email: "private@example.com" })).toBeNull();
    expect(accountName({ full_name: "private@example.com", name: 42 })).toBeNull();
    expect(accountName({ display_name: "   ", full_name: "  Mikhail   Harris  " })).toBe("Mikhail Harris");
  });
});