import { describe, expect, it } from "vitest";

import { isMiraFounder } from "./founder";

describe("isMiraFounder", () => {
  it("marks the founder account, ignoring case and stray spaces", () => {
    expect(isMiraFounder("Mikhail@Example.com", "mikhail@example.com")).toBe(true);
    expect(isMiraFounder("  mikhail@example.com  ", "Mikhail@Example.com")).toBe(true);
  });

  it("does not mark anyone else as the founder", () => {
    expect(isMiraFounder("someone@else.com", "mikhail@example.com")).toBe(false);
    expect(isMiraFounder("mikhail@example.com.evil.com", "mikhail@example.com")).toBe(false);
  });

  it("marks nobody when no founder email is configured or the user has no email", () => {
    expect(isMiraFounder("mikhail@example.com", "")).toBe(false);
    expect(isMiraFounder(null, "mikhail@example.com")).toBe(false);
    expect(isMiraFounder(undefined, "mikhail@example.com")).toBe(false);
  });
});
