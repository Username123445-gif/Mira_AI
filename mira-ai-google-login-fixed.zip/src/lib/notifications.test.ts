import { beforeEach, describe, expect, it, vi } from "vitest";
import { notificationsEnabled, notifyMira, setNotificationsEnabled } from "./notifications";

describe("Mira notifications", () => {
  const show = vi.fn();
  beforeEach(() => {
    localStorage.clear();
    vi.restoreAllMocks();
    show.mockClear();
    vi.stubGlobal("isSecureContext", true);
    vi.stubGlobal("Notification", class {
      static permission = "granted";
      constructor(title: string, options: NotificationOptions) { show(title, options); }
    });
    Object.defineProperty(navigator, "serviceWorker", { configurable: true, value: undefined });
    vi.spyOn(document, "hasFocus").mockReturnValue(false);
  });
  it("defaults to off", async () => {
    expect(notificationsEnabled("owner")).toBe(false);
    expect(await notifyMira("owner", "chat", "answer")).toBe(false);
    expect(show).not.toHaveBeenCalled();
  });
  it("saves on/off separately for each account", () => {
    setNotificationsEnabled("owner", true);
    expect(notificationsEnabled("owner")).toBe(true);
    expect(notificationsEnabled("other")).toBe(false);
    setNotificationsEnabled("owner", false);
    expect(notificationsEnabled("owner")).toBe(false);
  });
  it("shows an enabled background reply without private content", async () => {
    setNotificationsEnabled("owner", true);
    expect(await notifyMira("owner", "chat", "answer")).toBe(true);
    expect(show).toHaveBeenCalledWith("Mira has replied", { body: "Open Mira to see it.", icon: "/icon-192.png", tag: "mira-answer-chat" });
  });
  it("does not interrupt a focused chat", async () => {
    setNotificationsEnabled("owner", true);
    vi.spyOn(document, "hasFocus").mockReturnValue(true);
    expect(await notifyMira("owner", "chat", "answer")).toBe(false);
    expect(show).not.toHaveBeenCalled();
  });
  it("does not send when browser permission is blocked", async () => {
    setNotificationsEnabled("owner", true);
    vi.stubGlobal("Notification", { permission: "denied" });
    expect(await notifyMira("owner", "chat", "answer")).toBe(false);
    expect(show).not.toHaveBeenCalled();
  });
  it("shows a completed image alert", async () => {
    setNotificationsEnabled("owner", true);
    expect(await notifyMira("owner", "chat", "image")).toBe(true);
    expect(show.mock.calls[0]?.[0]).toBe("Your Mira image is ready");
  });
});