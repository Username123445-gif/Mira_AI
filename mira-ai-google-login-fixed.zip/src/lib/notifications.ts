export const NOTIFICATION_EVENT = "mira-notifications";

export function notificationPermission(): NotificationPermission | "unsupported" {
  return typeof window !== "undefined" && "Notification" in window && window.isSecureContext
    ? Notification.permission
    : "unsupported";
}

export function notificationsEnabled(userId: string): boolean {
  try { return localStorage.getItem(`mira-notifications:${userId}`) === "on"; }
  catch { return false; }
}

export function setNotificationsEnabled(userId: string, enabled: boolean) {
  localStorage.setItem(`mira-notifications:${userId}`, enabled ? "on" : "off");
  window.dispatchEvent(new Event(NOTIFICATION_EVENT));
}

export async function notifyMira(userId: string, threadId: string, kind: "answer" | "image", test = false): Promise<boolean> {
  if (!notificationsEnabled(userId) || notificationPermission() !== "granted") return false;
  if (!test && document.visibilityState === "visible" && document.hasFocus()) return false;
  const title = test ? "Mira AI notifications are on" : kind === "image" ? "Your Mira image is ready" : "Mira has replied";
  // Never expose private prompts, replies or account details on the lock screen.
  const options: NotificationOptions = {
    body: test ? "You're all set." : "Open Mira to see it.",
    icon: "/icon-192.png",
    tag: `mira-${kind}-${threadId}`,
  };
  try {
    const registration = await navigator.serviceWorker?.getRegistration();
    // Preferences can change while checking the worker registration.
    if (!notificationsEnabled(userId)) return false;
    if (registration?.active) {
      await registration.showNotification(title, options);
    } else {
      const notification = new Notification(title, options);
      notification.onclick = () => {
        window.focus();
        notification.close();
      };
    }
    return true;
  } catch { return false; }
}