export type ThemeMode = "dark" | "light";
const THEME_KEY = "mira-theme";
const SNOW_KEY = "mira-snow";
const EVENT = "mira-appearance";

export function getTheme(): ThemeMode {
  try { return localStorage.getItem(THEME_KEY) === "light" ? "light" : "dark"; } catch { return "dark"; }
}
export function getSnow(): boolean {
  try { return localStorage.getItem(SNOW_KEY) !== "off"; } catch { return true; }
}
export function applyTheme(mode: ThemeMode) {
  const el = document.documentElement;
  el.classList.toggle("light", mode === "light");
  el.classList.toggle("dark", mode === "dark");
}
export function setTheme(mode: ThemeMode) {
  try { localStorage.setItem(THEME_KEY, mode); } catch {}
  applyTheme(mode);
  window.dispatchEvent(new Event(EVENT));
}
export function setSnow(on: boolean) {
  try { localStorage.setItem(SNOW_KEY, on ? "on" : "off"); } catch {}
  window.dispatchEvent(new Event(EVENT));
}
export function onAppearanceChange(cb: () => void) {
  window.addEventListener(EVENT, cb);
  window.addEventListener("storage", cb);
  return () => { window.removeEventListener(EVENT, cb); window.removeEventListener("storage", cb); };
}
/** Runs before paint so the saved theme never flashes. */
export const THEME_BOOT_SCRIPT = `try{if(localStorage.getItem("${THEME_KEY}")==="light"){var d=document.documentElement;d.classList.remove("dark");d.classList.add("light")}}catch(e){}`;
