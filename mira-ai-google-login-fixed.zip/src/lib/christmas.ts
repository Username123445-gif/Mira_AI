/** Christmas update shows until local midnight, January 1, 2027. */
export const CHRISTMAS_UPDATE_ENDS = () => new Date(2027, 0, 1, 0, 0, 0);
export function isChristmasUpdateActive(now: Date) {
  return now.getTime() < CHRISTMAS_UPDATE_ENDS().getTime();
}
