import { createParser } from "eventsource-parser";

/** Uploads a recording and streams back the transcript text. */
export async function transcribeRecording(
  file: File,
  headers: Record<string, string>,
  onText: (text: string) => void,
): Promise<string> {
  const form = new FormData();
  form.append("file", file, file.name);
  const res = await fetch("/api/transcribe", { method: "POST", headers, body: form });
  if (!res.ok || !res.body) {
    const body = await res.text().catch(() => "");
    let message = body;
    try {
      const j = JSON.parse(body);
      message = j?.error?.message ?? j?.message ?? body;
    } catch {}
    throw new Error(
      res.status === 402
        ? "Mira is out of AI credits right now. Please try again later."
        : res.status === 429
          ? "Mira is busy right now. Please try again in a moment."
          : message || "Couldn't understand that recording. Please try again.",
    );
  }
  let text = "";
  let done = false;
  let failure: string | null = null;
  const parser = createParser({
    onEvent(ev) {
      if (ev.data === "[DONE]") return;
      try {
        const d = JSON.parse(ev.data);
        if (d.type === "transcript.text.delta" && typeof d.delta === "string") {
          text += d.delta;
          onText(text);
        } else if (d.type === "transcript.text.done" && typeof d.text === "string") {
          text = d.text;
          done = true;
          onText(text);
        } else if (d.type === "error" || d.error) {
          failure = d.error?.message ?? d.message ?? "Transcription failed.";
        }
      } catch {}
    },
  });
  const reader = res.body.pipeThrough(new TextDecoderStream()).getReader();
  for (;;) {
    const { value, done: end } = await reader.read();
    if (end) break;
    parser.feed(value);
  }
  if (failure) throw new Error(failure);
  if (!done && !text) throw new Error("Couldn't understand that recording. Please try again.");
  return text.trim();
}
