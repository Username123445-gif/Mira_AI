import { describe, expect, it } from "vitest";
import { CANCELLATION_TIMING, PLAN_CHANGE_BILLING, paidPlan, subscriptionPlan, type Subscription } from "@/lib/billing";

const now = Date.parse("2026-11-22T00:00:00Z");
const row = (patch: Partial<Subscription> = {}): Subscription => ({
  id: "1", user_id: "u", paddle_subscription_id: "sub", paddle_customer_id: "ctm", product_id: "mira_plus",
  price_id: "mira_plus_monthly", status: "active", current_period_start: null, current_period_end: "2026-12-22T00:00:00Z",
  cancel_at_period_end: false, environment: "live", provider_updated_at: "2026-11-21T00:00:00Z",
  created_at: "2026-11-21T00:00:00Z", updated_at: "2026-11-21T00:00:00Z", ...patch,
});

describe("paid Mira access", () => {
  it("changes plans immediately with prorated billing", () => {
    expect(PLAN_CHANGE_BILLING).toBe("prorated_immediately");
  });
  it("requests immediate cancellation from the payment service", () => {
    expect(CANCELLATION_TIMING).toBe("immediately");
  });
  it("gives a buyer Plus only after a verified active Plus subscription", () => {
    expect(subscriptionPlan(row(), "live", now)).toBe("plus");
  });
  it("gives a buyer Pro for an active Pro subscription", () => {
    expect(subscriptionPlan(row({ product_id: "mira_pro", price_id: "mira_pro_monthly" }), "live", now)).toBe("pro");
  });
  it("gives a buyer Ultra for an active Ultra subscription", () => {
    expect(subscriptionPlan(row({ product_id: "mira_ultra", price_id: "mira_ultra_monthly" }), "live", now)).toBe("ultra");
  });
  it("treats yearly prices the same as monthly for the same plan", () => {
    expect(subscriptionPlan(row({ price_id: "mira_plus_yearly" }), "live", now)).toBe("plus");
    expect(subscriptionPlan(row({ product_id: "mira_pro", price_id: "mira_pro_yearly" }), "live", now)).toBe("pro");
    expect(subscriptionPlan(row({ product_id: "mira_ultra", price_id: "mira_ultra_yearly" }), "live", now)).toBe("ultra");
  });
  it("picks the highest plan when someone has more than one active subscription", () => {
    expect(paidPlan([row(), row({ product_id: "mira_ultra", price_id: "mira_ultra_monthly" })], "live", now)).toBe("ultra");
    expect(paidPlan([row(), row({ product_id: "mira_pro", price_id: "mira_pro_monthly" })], "live", now)).toBe("pro");
  });
  it("ends paid access immediately when canceled, even if paid time remains", () => {
    expect(subscriptionPlan(row({ status: "canceled" }), "live", now)).toBe("free");
    expect(subscriptionPlan(row({ cancel_at_period_end: true }), "live", now)).toBe("free");
  });
  it("never lets test payments unlock the live app", () => {
    expect(paidPlan([row({ environment: "sandbox" })], "live", now)).toBe("free");
  });
});