import type { Database } from "@/integrations/supabase/types";
import type { PlanId } from "@/lib/plans";

export type PaymentEnvironment = "sandbox" | "live";
export type PaidPlanId = Exclude<PlanId, "free">;
export type Subscription = Database["public"]["Tables"]["subscriptions"]["Row"];
export type BillingState = { plan: PlanId; subscription: Subscription | null; environment: PaymentEnvironment };

export type BillingInterval = "monthly" | "yearly";
export const PAID_PRICES: Record<PaidPlanId, Record<BillingInterval, string>> = {
  plus: { monthly: "mira_plus_monthly", yearly: "mira_plus_yearly" },
  pro: { monthly: "mira_pro_monthly", yearly: "mira_pro_yearly" },
  ultra: { monthly: "mira_ultra_monthly", yearly: "mira_ultra_yearly" },
};
export const ALL_PAID_PRICE_IDS = Object.values(PAID_PRICES).flatMap((byInterval) => Object.values(byInterval));
export const PLAN_CHANGE_BILLING = "prorated_immediately";
export const CANCELLATION_TIMING = "immediately";

/** Build-time token selection prevents a caller choosing test access on the live app. */
export function getPaymentEnvironment(): PaymentEnvironment {
  return import.meta.env['VITE_PAYMENTS_CLIENT_TOKEN']?.startsWith("test_") ? "sandbox" : "live";
}

export function subscriptionPlan(row: Subscription, environment: PaymentEnvironment, now = Date.now()): PlanId {
  if (row.environment !== environment) return "free";
  // Cancellation ends access immediately, including portal cancellations scheduled for later.
  if (row.cancel_at_period_end || !["active", "past_due"].includes(row.status)) return "free";
  if (!row.current_period_end || Date.parse(row.current_period_end) <= now) return "free";
  if (row.product_id === "mira_ultra" && row.price_id.startsWith("mira_ultra")) return "ultra";
  if (row.product_id === "mira_pro" && row.price_id.startsWith("mira_pro")) return "pro";
  if (row.product_id === "mira_plus" && row.price_id.startsWith("mira_plus")) return "plus";
  return "free";
}

export function paidPlan(rows: Subscription[], environment: PaymentEnvironment, now = Date.now()): PlanId {
  const plans = rows.map((row) => subscriptionPlan(row, environment, now));
  if (plans.includes("ultra")) return "ultra";
  if (plans.includes("pro")) return "pro";
  return plans.includes("plus") ? "plus" : "free";
}