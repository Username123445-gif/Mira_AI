import { supabase } from "@/integrations/supabase/client";

const BUCKET = "generated-images";

export type SavedImage = { id: string; prompt: string; storage_path: string; created_at: string; url: string };

/** Save a finished image to the signed-in user's private gallery. */
export async function saveGeneratedImage(dataUrl: string, prompt: string, threadId: string | null) {
  const { data: auth } = await supabase.auth.getUser();
  const uid = auth.user?.id;
  if (!uid) throw new Error("Please sign in to save images.");
  const blob = await (await fetch(dataUrl)).blob();
  const path = `${uid}/${crypto.randomUUID()}.png`;
  const up = await supabase.storage.from(BUCKET).upload(path, blob, { contentType: "image/png" });
  if (up.error) throw up.error;
  const { data, error } = await supabase
    .from("generated_images")
    .insert({ user_id: uid, prompt, storage_path: path, thread_id: threadId })
    .select("id")
    .single();
  if (error) {
    await supabase.storage.from(BUCKET).remove([path]);
    throw error;
  }
  return data.id;
}

/** List the user's images (optionally for one chat), with short-lived private links. */
export async function listGeneratedImages(threadId?: string): Promise<SavedImage[]> {
  let q = supabase.from("generated_images").select("id,prompt,storage_path,created_at").order("created_at", {
    ascending: !!threadId,
  });
  if (threadId) q = q.eq("thread_id", threadId);
  const { data, error } = await q.limit(200);
  if (error) throw error;
  if (!data.length) return [];
  const { data: signed, error: sErr } = await supabase.storage
    .from(BUCKET)
    .createSignedUrls(data.map((d) => d.storage_path), 60 * 60);
  if (sErr) throw sErr;
  return data.map((d, i) => ({ ...d, url: signed[i]?.signedUrl ?? "" }));
}

export async function deleteGeneratedImage(img: Pick<SavedImage, "id" | "storage_path">) {
  const { error } = await supabase.from("generated_images").delete().eq("id", img.id);
  if (error) throw error;
  await supabase.storage.from(BUCKET).remove([img.storage_path]);
}
