import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { CANCELLATION_TIMING, PAID_PRICES, PLAN_CHANGE_BILLING } from "@/lib/billing";
import { gatewayFetch, readBilling, resolvePrice, syncSubscription } from "@/lib/payments.server";

const planInput = z.object({ plan: z.enum(["plus", "pro", "ultra"]), interval: z.enum(["monthly", "yearly"]).default("monthly") });

export const getBilling = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth])
  .handler(async ({ context }) => readBilling(context.supabase, context.userId));

export const prepareCheckout = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => planInput.parse(input))
  .handler(async ({ data, context }) => {
    const billing = await readBilling(context.supabase, context.userId);
    if (billing.subscription) throw new Error("You already have a subscription. Change your existing plan instead.");
    const priceId = await resolvePrice(PAID_PRICES[data.plan][data.interval], billing.environment);
    return { priceId, userId: context.userId };
  });

export const getBillingPortal = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const billing = await readBilling(context.supabase, context.userId);
    if (!billing.subscription) throw new Error("No current subscription to manage.");
    const response = await gatewayFetch(billing.environment, `/customers/${billing.subscription.paddle_customer_id}/portal-sessions`, {
      method: "POST", body: JSON.stringify({ subscription_ids: [billing.subscription.paddle_subscription_id] }),
    });
    return z.object({ data: z.object({ urls: z.object({ general: z.object({ overview: z.string().url() }) }) }) })
      .parse(await response.json()).data.urls.general.overview;
  });

export const previewPlanChange = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => planInput.parse(input))
  .handler(async ({ data, context }) => {
    const billing = await readBilling(context.supabase, context.userId);
    if (!billing.subscription || (billing.plan === data.plan && billing.subscription.price_id === PAID_PRICES[data.plan][data.interval])) throw new Error("Choose a different paid plan.");
    const priceId = await resolvePrice(PAID_PRICES[data.plan][data.interval], billing.environment);
    const response = await gatewayFetch(billing.environment, `/subscriptions/${billing.subscription.paddle_subscription_id}/preview`, {
      method: "PATCH", body: JSON.stringify({ items: [{ price_id: priceId, quantity: 1 }], proration_billing_mode: PLAN_CHANGE_BILLING }),
    });
    const preview = z.object({ data: z.object({ currency_code: z.string(), immediate_transaction: z.object({
      details: z.object({ totals: z.object({ total: z.string(), grand_total: z.string().optional() }) }),
    }).nullable() }) }).parse(await response.json()).data;
    return { currency: preview.currency_code, amount: preview.immediate_transaction?.details.totals.grand_total ?? preview.immediate_transaction?.details.totals.total ?? "0" };
  });

export const changePlan = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => planInput.extend({ expectedAmount: z.string(), expectedCurrency: z.string() }).parse(input))
  .handler(async ({ data, context }) => {
    const billing = await readBilling(context.supabase, context.userId);
    if (!billing.subscription || (billing.plan === data.plan && billing.subscription.price_id === PAID_PRICES[data.plan][data.interval])) throw new Error("Choose a different paid plan.");
    const priceId = await resolvePrice(PAID_PRICES[data.plan][data.interval], billing.environment);
    const body = JSON.stringify({ items: [{ price_id: priceId, quantity: 1 }], proration_billing_mode: PLAN_CHANGE_BILLING, on_payment_failure: "prevent_change" });
    const previewResponse = await gatewayFetch(billing.environment, `/subscriptions/${billing.subscription.paddle_subscription_id}/preview`, { method: "PATCH", body });
    const preview = z.object({ data: z.object({ currency_code: z.string(), immediate_transaction: z.object({
      details: z.object({ totals: z.object({ total: z.string(), grand_total: z.string().optional() }) }),
    }).nullable() }) }).parse(await previewResponse.json()).data;
    const amount = preview.immediate_transaction?.details.totals.grand_total ?? preview.immediate_transaction?.details.totals.total ?? "0";
    if (amount !== data.expectedAmount || preview.currency_code !== data.expectedCurrency) throw new Error("The amount changed. Please review the new price before confirming.");
    await gatewayFetch(billing.environment, `/subscriptions/${billing.subscription.paddle_subscription_id}`, { method: "PATCH", body });
    await syncSubscription(billing.subscription.paddle_subscription_id, billing.environment);
  });

export const cancelSubscription = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const billing = await readBilling(context.supabase, context.userId);
    if (!billing.subscription) throw new Error("No current subscription to cancel.");
    await gatewayFetch(billing.environment, `/subscriptions/${billing.subscription.paddle_subscription_id}/cancel`, {
      method: "POST", body: JSON.stringify({ effective_from: CANCELLATION_TIMING }),
    });
    await syncSubscription(billing.subscription.paddle_subscription_id, billing.environment);
  });