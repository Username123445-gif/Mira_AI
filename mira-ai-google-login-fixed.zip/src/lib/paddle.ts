import type { Paddle, PaddleEventData } from "@paddle/paddle-js";
import { getPaymentEnvironment } from "@/lib/billing";

let paddlePromise: Promise<Paddle | undefined> | undefined;
let checkoutListener: ((event: PaddleEventData) => void) | undefined;

export async function openMiraCheckout(options: { priceId: string; userId: string; onEvent: (event: PaddleEventData) => void }) {
  const token = import.meta.env['VITE_PAYMENTS_CLIENT_TOKEN'];
  if (!token) throw new Error("Payments aren't configured yet.");
  checkoutListener = options.onEvent;
  if (!paddlePromise) {
    const { initializePaddle } = await import("@paddle/paddle-js");
    paddlePromise = initializePaddle({ token, environment: getPaymentEnvironment() === "sandbox" ? "sandbox" : "production",
      eventCallback: (event) => checkoutListener?.(event),
    });
  }
  let paddle: Paddle | undefined;
  try { paddle = await paddlePromise; } catch (error) { paddlePromise = undefined; throw error; }
  if (!paddle) { paddlePromise = undefined; throw new Error("Checkout couldn't load. Please try again."); }
  paddle.Checkout.open({
    items: [{ priceId: options.priceId, quantity: 1 }],
    customData: { userId: options.userId },
    settings: { displayMode: "overlay", variant: "one-page", theme: "dark", allowLogout: false,
      successUrl: `${window.location.origin}/settings?checkout=success`,
    },
  });
}