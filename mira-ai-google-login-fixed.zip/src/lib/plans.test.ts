import { describe, expect, it } from "vitest";

import { getPlan, personalInstructions, PLANS } from "@/lib/plans";

describe("Mira plans", () => {
  it("charges Free $0, Plus $8, Pro $20 and Ultra $49 a month", () => {
    expect(PLANS.map((p) => [p.id, p.priceMonthly])).toEqual([
      ["free", 0],
      ["plus", 8],
      ["pro", 20],
      ["ultra", 49],
    ]);
  });

  it("gives yearly billing two months free: Plus $80, Pro $200, Ultra $490 a year", () => {
    expect(PLANS.map((p) => [p.id, p.priceYearly])).toEqual([
      ["free", 0],
      ["plus", 80],
      ["pro", 200],
      ["ultra", 490],
    ]);
  });

  it("gives higher plans deeper thinking", () => {
    expect(getPlan("free").reasoningEffort).toBe("low");
    expect(getPlan("plus").reasoningEffort).toBe("medium");
    expect(getPlan("pro").reasoningEffort).toBe("high");
    expect(getPlan("ultra").reasoningEffort).toBe("high");
  });

  it("uses the newest model only on Pro and Ultra", () => {
    expect(getPlan("pro").model).toBe("openai/gpt-6.2-astra");
    expect(getPlan("ultra").model).toBe("openai/gpt-6.2-astra");
    expect(getPlan("plus").model).toBe("openai/gpt-6-astra");
  });

  it("falls back to Free for people without a saved plan", () => {
    expect(getPlan(undefined).id).toBe("free");
    expect(getPlan("enterprise").id).toBe("free");
  });

  it("gives Plus, Pro and Ultra buyers more thorough web research", () => {
    expect(PLANS.map((p) => [p.id, p.webSearchDepth])).toEqual([["free", "low"], ["plus", "medium"], ["pro", "high"], ["ultra", "high"]]);
  });

  it("adds the 'about you' note only when the person wrote one", () => {
    expect(personalInstructions({ answer_style: "concise", about_me: "" })).not.toContain("shared about themselves");
    expect(personalInstructions({ answer_style: "concise", about_me: "I'm a nurse" })).toContain("I'm a nurse");
  });
});
