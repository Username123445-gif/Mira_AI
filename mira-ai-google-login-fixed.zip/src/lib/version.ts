// Single source of truth for the Mira AI version.
export const MIRA_VERSION = "v0.2 Beta";
export const MIRA_VERSION_SLUG = "v0.2";

export const MIRA_VERSION_TAGLINE = `Mira AI ${MIRA_VERSION}`;
