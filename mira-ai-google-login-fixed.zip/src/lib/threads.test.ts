import { beforeEach, describe, expect, it, vi } from "vitest";

const mock = vi.hoisted(() => ({
  messageCount: 0, imageCount: 0, imageError: false,
  insert: vi.fn(),
  from: vi.fn(),
  getUser: vi.fn(),
}));
vi.mock("@/integrations/supabase/client", () => ({ supabase: {
  auth: { getUser: mock.getUser }, from: mock.from,
} }));

import { getOrCreateEmptyThread } from "./threads";

beforeEach(() => {
  vi.clearAllMocks();
  mock.messageCount = 0;
  mock.imageCount = 0;
  mock.imageError = false;
  mock.getUser.mockResolvedValue({ data: { user: { id: "owner" } }, error: null });
  mock.from.mockImplementation((table: string) => {
    const query = {
      select: vi.fn(() => query), order: vi.fn(() => query), limit: vi.fn(() => query),
      insert: mock.insert.mockImplementation(() => query),
      maybeSingle: vi.fn().mockResolvedValue({ data: { id: "latest" }, error: null }),
      single: vi.fn().mockResolvedValue({ data: { id: "created" }, error: null }),
      eq: vi.fn().mockImplementation(() => Promise.resolve({
        count: table === "messages" ? mock.messageCount : mock.imageCount,
        error: table === "generated_images" && mock.imageError ? { message: "Images unavailable" } : null,
      })),
    };
    return query;
  });
});

describe("New chat", () => {
  it("reuses a truly empty thread", async () => {
    expect(await getOrCreateEmptyThread()).toBe("latest");
    expect(mock.insert).not.toHaveBeenCalled();
  });
  it("starts a fresh conversation when the latest thread contains an image but no text", async () => {
    mock.imageCount = 1;
    expect(await getOrCreateEmptyThread()).toBe("created");
    expect(mock.insert).toHaveBeenCalledWith({ user_id: "owner" });
  });
  it("starts a fresh conversation when the latest thread contains text", async () => {
    mock.messageCount = 2;
    expect(await getOrCreateEmptyThread()).toBe("created");
    expect(mock.from).not.toHaveBeenCalledWith("generated_images");
  });
  it("coalesces simultaneous navigation into one thread creation", async () => {
    mock.messageCount = 2;
    const results = await Promise.all([getOrCreateEmptyThread(), getOrCreateEmptyThread()]);
    expect(results).toEqual(["created", "created"]);
    expect(mock.insert).toHaveBeenCalledTimes(1);
  });
  it("does not treat an image lookup failure as an empty chat and permits a later retry", async () => {
    mock.imageError = true;
    await expect(getOrCreateEmptyThread()).rejects.toThrow("Images unavailable");
    expect(mock.insert).not.toHaveBeenCalled();
    mock.imageError = false;
    expect(await getOrCreateEmptyThread()).toBe("latest");
  });
});