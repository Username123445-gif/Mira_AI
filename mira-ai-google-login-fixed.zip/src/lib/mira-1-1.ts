// Mira AI 1.1 launch moment, in the viewer's own local time (local midnight, Jan 1 2027).
export const MIRA_ONE_ONE_RELEASE = new Date(2027, 0, 1);

export const MIRA_ONE_ONE_RELEASE_LABEL = "January 1, 2027";

export type MiraOneOneCountdown = {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  /** Milliseconds left, or 0 once the release moment has passed. */
  totalMs: number;
  /** True once Mira AI 1.1 is out, so callers can stop showing the timer. */
  isLive: boolean;
};

export function miraOneOneCountdown(
  now: Date,
  release: Date = MIRA_ONE_ONE_RELEASE,
): MiraOneOneCountdown {
  const totalMs = release.getTime() - now.getTime();
  if (totalMs <= 0) {
    return { days: 0, hours: 0, minutes: 0, seconds: 0, totalMs: 0, isLive: true };
  }

  const totalSeconds = Math.floor(totalMs / 1000);
  return {
    days: Math.floor(totalSeconds / 86_400),
    hours: Math.floor(totalSeconds / 3_600) % 24,
    minutes: Math.floor(totalSeconds / 60) % 60,
    seconds: totalSeconds % 60,
    totalMs,
    isLive: false,
  };
}
