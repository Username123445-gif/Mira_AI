import { queryOptions } from "@tanstack/react-query";
import type { UIMessage } from "ai";

import { supabase } from "@/integrations/supabase/client";

export type Thread = { id: string; title: string; updated_at: string };

export const threadsQuery = () =>
  queryOptions({
    queryKey: ["threads"],
    queryFn: async (): Promise<Thread[]> => {
      const { data, error } = await supabase
        .from("threads")
        .select("id, title, updated_at")
        .order("updated_at", { ascending: false });
      if (error) throw new Error(error.message);
      return data ?? [];
    },
  });

export const threadMessagesQuery = (threadId: string) =>
  queryOptions({
    queryKey: ["threads", threadId, "messages"],
    queryFn: async (): Promise<{ exists: boolean; messages: UIMessage[] }> => {
      const { data: thread, error: threadError } = await supabase
        .from("threads")
        .select("id")
        .eq("id", threadId)
        .maybeSingle();
      if (threadError) throw new Error(threadError.message);
      if (!thread) return { exists: false, messages: [] };

      const { data, error } = await supabase
        .from("messages")
        .select("message_id, role, parts")
        .eq("thread_id", threadId)
        .order("created_at", { ascending: true });
      if (error) throw new Error(error.message);
      return {
        exists: true,
        messages: (data ?? []).map((r) => ({
          id: r.message_id,
          role: r.role as UIMessage["role"],
          parts: r.parts as unknown as UIMessage["parts"],
        })),
      };
    },
  });

let pendingEmptyThread: Promise<string> | undefined;

/** Coalesce concurrent client navigation requests so one visit creates only one chat. */
export function getOrCreateEmptyThread(): Promise<string> {
  if (pendingEmptyThread) return pendingEmptyThread;
  pendingEmptyThread = findOrCreateEmptyThread().finally(() => { pendingEmptyThread = undefined; });
  return pendingEmptyThread;
}

/** A chat with saved images is not empty, even when it has no text messages. */
async function findOrCreateEmptyThread(): Promise<string> {
  const { data: userData, error: userError } = await supabase.auth.getUser();
  if (userError || !userData.user) throw new Error("Please sign in again.");

  const { data: latest, error: latestError } = await supabase
    .from("threads")
    .select("id")
    .order("updated_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  if (latestError) throw new Error(latestError.message);

  if (latest) {
    const { count, error: countError } = await supabase
      .from("messages")
      .select("id", { count: "exact", head: true })
      .eq("thread_id", latest.id);
    if (countError) throw new Error(countError.message);
    if (!count) {
      const { count: imageCount, error: imageError } = await supabase
        .from("generated_images")
        .select("id", { count: "exact", head: true })
        .eq("thread_id", latest.id);
      if (imageError) throw new Error(imageError.message);
      if (imageCount === 0) return latest.id;
    }
  }

  const { data: created, error: createError } = await supabase
    .from("threads")
    .insert({ user_id: userData.user.id })
    .select("id")
    .single();
  if (createError) throw new Error(createError.message);
  return created.id;
}

export async function deleteThread(threadId: string) {
  const { error } = await supabase.from("threads").delete().eq("id", threadId);
  if (error) throw new Error(error.message);
}
