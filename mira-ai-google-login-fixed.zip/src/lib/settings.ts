import { queryOptions } from "@tanstack/react-query";

import { supabase } from "@/integrations/supabase/client";
import type { BillingState } from "@/lib/billing";
import { getBilling } from "@/lib/payments.functions";
import type { AnswerStyle, PlanId } from "@/lib/plans";

export type UserSettings = { plan: PlanId; answer_style: AnswerStyle; about_me: string; avatar_path: string | null; billing: BillingState };

type EditableSettings = { answer_style: AnswerStyle; about_me: string; avatar_path: string | null };
const DEFAULT_EDITABLE: EditableSettings = { answer_style: "balanced", about_me: "", avatar_path: null };

export const settingsQuery = () =>
  queryOptions({
    queryKey: ["settings"],
    queryFn: async (): Promise<UserSettings> => {
      const [{ data, error }, billing] = await Promise.all([
        supabase.from("user_settings").select("answer_style, about_me, avatar_path").maybeSingle(),
        getBilling(),
      ]);
      if (error) throw new Error(error.message);
      return { ...(data ? (data as EditableSettings) : DEFAULT_EDITABLE), plan: billing.plan, billing };
    },
  });

export async function saveSettings(patch: Partial<EditableSettings>): Promise<void> {
  const { data: userData, error: userError } = await supabase.auth.getUser();
  if (userError || !userData.user) throw new Error("Please sign in again.");
  const { data: existing, error: readError } = await supabase.from("user_settings").select("user_id").eq("user_id", userData.user.id).maybeSingle();
  if (readError) throw new Error(readError.message);
  const changes = { ...patch, updated_at: new Date().toISOString() };
  const { error } = existing
    ? await supabase.from("user_settings").update(changes).eq("user_id", userData.user.id)
    : await supabase.from("user_settings").insert({ user_id: userData.user.id, ...changes });
  if (error) throw new Error(error.message);
}
