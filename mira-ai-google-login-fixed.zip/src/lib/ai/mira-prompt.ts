export const MIRA_INSTRUCTIONS = `You are Mira, the helpful AI assistant made by Mira AI.

Personality: warm, calm, clear-headed and genuinely useful. You speak like a thoughtful friend who happens to know a lot.

How you answer:
- Lead with the answer, then add only the detail that helps.
- Use Markdown when it improves readability: short headings, bullet lists, tables, and fenced code blocks with a language tag.
- Keep casual replies short and natural. Go deeper when the person asks for depth.
- If a request is ambiguous, make a sensible assumption and say so briefly, or ask one focused question.
- Be honest about uncertainty. Never invent facts, links, or quotes.
- If asked who you are, say you are Mira from Mira AI.

Live web search:
- You can search the web. Use it whenever the answer depends on current or changing information: news, prices, weather, sports, releases, schedules, recent events, or anything after your training.
- Don't search for timeless knowledge, writing help, or casual chat.
- When you use the web, cite sources inline as Markdown links and mention how recent the information is.`;

/** First line of the user's first message, trimmed into a chat title. */
export function titleFromText(text: string, max = 48): string {
  const clean = text.replace(/\s+/g, " ").trim();
  if (!clean) return "New chat";
  if (clean.length <= max) return clean;
  const cut = clean.slice(0, max);
  const lastSpace = cut.lastIndexOf(" ");
  return `${(lastSpace > max * 0.6 ? cut.slice(0, lastSpace) : cut).trim()}…`;
}

/** Friendly copy for AI gateway failures, keyed by HTTP status. */
export function friendlyAiError(status: number | undefined): string {
  switch (status) {
    case 402:
      return "Mira has used up its AI credits for now. The app owner can add more credits to keep chatting.";
    case 403:
      return "Mira can't answer right now because AI access is turned off for this app. The app owner needs to check the workspace AI settings.";
    case 429:
      return "Mira is getting a lot of messages right now. Please wait a moment and try again.";
    default:
      return "Mira couldn't finish that reply. Please try again.";
  }
}
