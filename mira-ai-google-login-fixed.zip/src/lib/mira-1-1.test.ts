import { describe, expect, it } from "vitest";

import { MIRA_ONE_ONE_RELEASE, miraOneOneCountdown } from "./mira-1-1";

describe("miraOneOneCountdown", () => {
  it("counts down to the Mira AI 1.1 launch moment", () => {
    const release = new Date(2027, 0, 1);
    const tenDaysThreeHours = new Date(2026, 11, 21, 21, 0, 0);

    expect(miraOneOneCountdown(tenDaysThreeHours, release)).toMatchObject({
      days: 10,
      hours: 3,
      minutes: 0,
      seconds: 0,
      isLive: false,
    });
  });

  it("reports the release as live once the launch moment arrives", () => {
    const release = new Date(2027, 0, 1);

    expect(miraOneOneCountdown(release, release)).toEqual({
      days: 0,
      hours: 0,
      minutes: 0,
      seconds: 0,
      totalMs: 0,
      isLive: true,
    });
    expect(miraOneOneCountdown(new Date(2027, 0, 1, 5), release).isLive).toBe(true);
  });

  it("targets January 1, 2027 at local midnight", () => {
    expect(MIRA_ONE_ONE_RELEASE.getFullYear()).toBe(2027);
    expect(MIRA_ONE_ONE_RELEASE.getMonth()).toBe(0);
    expect(MIRA_ONE_ONE_RELEASE.getDate()).toBe(1);
    expect(MIRA_ONE_ONE_RELEASE.getHours()).toBe(0);
  });
});
