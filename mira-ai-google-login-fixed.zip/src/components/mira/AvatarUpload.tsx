import { useQueryClient } from "@tanstack/react-query";
import { ImageUp, Trash2 } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { avatarUrl, removeAvatar, uploadAvatar } from "@/lib/avatar";

export function AvatarUpload({ userId, avatarPath, initials }: { userId: string; avatarPath: string | null; initials: string }) {
  const queryClient = useQueryClient();
  const inputRef = useRef<HTMLInputElement>(null);
  const [url, setUrl] = useState<string | null>(null);
  const [busy, setBusy] = useState<"upload" | "remove" | null>(null);

  useEffect(() => {
    let alive = true;
    avatarUrl(avatarPath).then((u) => {
      if (alive) setUrl(u);
    });
    return () => {
      alive = false;
    };
  }, [avatarPath]);

  async function onPick(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setBusy("upload");
    try {
      await uploadAvatar(userId, file);
      await queryClient.invalidateQueries({ queryKey: ["settings"] });
      await queryClient.invalidateQueries({ queryKey: ["avatar-url"] });
      toast.success("Profile picture updated.");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Couldn't upload that image.");
    } finally {
      setBusy(null);
    }
  }

  async function onRemove() {
    if (!avatarPath) return;
    setBusy("remove");
    try {
      await removeAvatar(userId, avatarPath);
      await queryClient.invalidateQueries({ queryKey: ["settings"] });
      await queryClient.invalidateQueries({ queryKey: ["avatar-url"] });
      toast.success("Profile picture removed.");
    } catch {
      toast.error("Couldn't remove your picture. Please try again.");
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="flex items-center gap-4">
      <div className="grid size-16 shrink-0 place-items-center overflow-hidden rounded-full bg-gradient-mira font-display text-2xl text-primary-foreground">
        {url ? <img src={url} alt="Your profile picture" className="size-full object-cover" /> : initials}
      </div>
      <div className="grid gap-2">
        <div className="flex flex-wrap gap-2">
          <Button variant="glass" size="sm" disabled={busy !== null} onClick={() => inputRef.current?.click()}>
            <ImageUp /> {busy === "upload" ? "Uploading…" : url ? "Change picture" : "Upload picture"}
          </Button>
          {url ? (
            <Button variant="ghost" size="sm" className="text-destructive" disabled={busy !== null} onClick={onRemove}>
              <Trash2 /> {busy === "remove" ? "Removing…" : "Remove"}
            </Button>
          ) : null}
        </div>
        <p className="text-xs text-muted-foreground">PNG, JPG, WebP or GIF, up to 5 MB. Only you can see it.</p>
      </div>
      <input ref={inputRef} type="file" accept="image/png,image/jpeg,image/webp,image/gif" className="hidden" onChange={onPick} />
    </div>
  );
}
