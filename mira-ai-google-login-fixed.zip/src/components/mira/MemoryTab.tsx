import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Brain, Plus, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";

export const MEMORY_MAX = 300;
const key = ["memories"];

export function MemoryTab() {
  const qc = useQueryClient();
  const [text, setText] = useState("");
  const { data = [], isLoading } = useQuery({
    queryKey: key,
    queryFn: async () => {
      const { data, error } = await supabase.from("user_memories").select("id, content").order("created_at");
      if (error) throw new Error(error.message);
      return data;
    },
  });
  const add = useMutation({
    mutationFn: async (content: string) => {
      const { error } = await supabase.from("user_memories").insert({ content });
      if (error) throw new Error(error.message);
    },
    onSuccess: () => { setText(""); void qc.invalidateQueries({ queryKey: key }); toast.success("Mira will remember that."); },
    onError: () => toast.error("Couldn't save that memory. Please try again."),
  });
  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("user_memories").delete().eq("id", id);
      if (error) throw new Error(error.message);
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: key }),
    onError: () => toast.error("Couldn't forget that memory. Please try again."),
  });

  return (
    <section className="rounded-3xl border border-border bg-card/60 p-6">
      <div className="flex items-center gap-2"><Brain className="size-5 text-primary" /><h2 className="font-display text-xl">Mira Memory</h2></div>
      <p className="mt-1 text-sm text-muted-foreground">Things Mira remembers about you in every chat. Only you can see them.</p>
      <form
        className="mt-4 flex gap-2"
        onSubmit={(e) => { e.preventDefault(); const v = text.trim(); if (v) add.mutate(v); }}
      >
        <Input value={text} maxLength={MEMORY_MAX} onChange={(e) => setText(e.target.value)} placeholder="e.g. I'm vegetarian and live in Chicago" aria-label="New memory" />
        <Button type="submit" variant="hero" disabled={!text.trim() || add.isPending}><Plus /> Add</Button>
      </form>
      <ul className="mt-4 grid gap-2">
        {isLoading && <li className="text-sm text-muted-foreground">Loading…</li>}
        {!isLoading && data.length === 0 && <li className="text-sm text-muted-foreground">No memories yet.</li>}
        {data.map((m) => (
          <li key={m.id} className="flex items-center gap-2 rounded-xl border border-border bg-background/40 px-3 py-2 text-sm">
            <span className="flex-1">{m.content}</span>
            <Button variant="ghost" size="icon-sm" aria-label={`Forget "${m.content}"`} onClick={() => remove.mutate(m.id)}><Trash2 className="size-3.5" /></Button>
          </li>
        ))}
      </ul>
    </section>
  );
}
