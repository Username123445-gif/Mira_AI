import { useEffect, useState } from "react";

import { getSnow, onAppearanceChange } from "@/lib/appearance";
import { isChristmasUpdateActive } from "@/lib/christmas";

const flakes = Array.from({ length: 36 }, (_, i) => ({
  left: (i * 37) % 100,
  size: 0.5 + ((i * 7) % 10) / 10,
  duration: 9 + ((i * 13) % 12),
  delay: -((i * 11) % 20),
  opacity: 0.35 + ((i * 3) % 6) / 10,
}));

/** Festive snowfall + holiday stripe, active until January 1, 2027. */
export function ChristmasTheme() {
  const [on, setOn] = useState(false);
  const [snow, setSnowOn] = useState(true);
  useEffect(() => {
    setOn(isChristmasUpdateActive(new Date()));
    const sync = () => setSnowOn(getSnow());
    sync();
    return onAppearanceChange(sync);
  }, []);
  if (!on) return null;
  return (
    <>
      <div aria-hidden className="bg-holiday pointer-events-none fixed inset-x-0 top-0 z-50 h-1" />
      {snow && <div aria-hidden className="pointer-events-none fixed inset-0 z-40 overflow-hidden">
        {flakes.map((f, i) => (
          <span
            key={i}
            className="snowflake"
            style={{
              left: `${f.left}%`,
              fontSize: `${f.size}rem`,
              animationDuration: `${f.duration}s`,
              animationDelay: `${f.delay}s`,
              opacity: f.opacity,
            }}
          >
            ❄
          </span>
        ))}
      </div>}
    </>
  );
}
