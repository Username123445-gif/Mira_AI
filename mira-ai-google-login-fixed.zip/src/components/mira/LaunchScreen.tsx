import { useEffect, useState } from "react";
import { MiraLogo } from "@/components/mira/MiraLogo";
import { isStandalone } from "@/hooks/use-install-prompt";

/** Branded splash shown briefly when Mira opens as an installed app. */
export function LaunchScreen() {
  const [phase, setPhase] = useState<"hidden" | "show" | "fade">("hidden");
  useEffect(() => {
    if (!isStandalone() || sessionStorage.getItem("mira-launched")) return;
    sessionStorage.setItem("mira-launched", "1");
    setPhase("show");
    const a = setTimeout(() => setPhase("fade"), 900);
    const b = setTimeout(() => setPhase("hidden"), 1300);
    return () => { clearTimeout(a); clearTimeout(b); };
  }, []);
  if (phase === "hidden") return null;
  return (
    <div
      aria-hidden
      className={`bg-night fixed inset-0 z-[100] flex flex-col items-center justify-center gap-4 transition-opacity duration-400 ${phase === "fade" ? "opacity-0" : "opacity-100"}`}
    >
      <div className="animate-pulse"><MiraLogo className="size-20" /></div>
      <p className="font-display text-2xl text-foreground">Mira <span className="text-gradient-mira font-bold italic">AI</span></p>
    </div>
  );
}
