import { MiraVerifiedBadge } from "@/components/mira/MiraLogo";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";

/**
 * The verified mark, clickable: clicking it opens a small card saying
 * "Mira AI founder". Sizing is left to the caller via className.
 */
export function MiraFounderBadge({ className }: { className?: string }) {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <button
          type="button"
          aria-label="Verified — Mira AI founder"
          className={cn(
            "inline-flex size-4 shrink-0 cursor-pointer items-center justify-center rounded-full transition-transform hover:scale-110 focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none",
            className,
          )}
        >
          <MiraVerifiedBadge className="size-full" />
        </button>
      </PopoverTrigger>
      <PopoverContent align="start" className="w-auto min-w-48 rounded-2xl border-border bg-popover p-3">
        <div className="flex items-center gap-2.5">
          <MiraVerifiedBadge className="size-7" />
          <div className="min-w-0">
            <p className="font-display text-base leading-tight">Mira AI founder</p>
            <p className="text-xs text-muted-foreground">Official Mira AI account</p>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}
