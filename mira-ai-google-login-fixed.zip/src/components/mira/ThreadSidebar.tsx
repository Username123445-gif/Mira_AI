import { InstallAppButton } from "@/components/mira/InstallAppButton";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Link, useNavigate, useParams } from "@tanstack/react-router";
import { ArrowUpRight, ChevronsUpDown, LogOut, UserRound, MessageSquare, Plus, Settings, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { useState } from "react";

import miraOneOneMark from "@/assets/mira-1-1-mark-hd.png.asset.json";
import { ConfirmDeleteDialog } from "@/components/mira/ConfirmDeleteDialog";
import { MiraFounderBadge } from "@/components/mira/MiraFounderBadge";
import { MiraWordmark } from "@/components/mira/MiraLogo";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { supabase } from "@/integrations/supabase/client";
import { isMiraFounder } from "@/lib/founder";
import { useMyAvatarUrl } from "@/lib/avatar";
import { deleteThread, threadsQuery, type Thread } from "@/lib/threads";
import { cn } from "@/lib/utils";

export function ThreadSidebar({ email, name, onNavigate }: { email?: string | undefined; name?: string | null; onNavigate?: () => void }) {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const params = useParams({ strict: false }) as { threadId?: string };
  const activeId = params.threadId;
  const { data: threads = [], isLoading, isError, refetch } = useQuery(threadsQuery());
  const [search, setSearch] = useState("");
  const shown = threads.filter((t) => t.title.toLowerCase().includes(search.trim().toLowerCase()));
  const [deleteTarget, setDeleteTarget] = useState<Thread | null>(null);
  const [deleting, setDeleting] = useState(false);
  const avatar = useMyAvatarUrl();

  async function handleDelete(id: string) {
    setDeleting(true);
    try {
      await deleteThread(id);
      queryClient.setQueryData<Thread[]>(threadsQuery().queryKey, (list) => list?.filter((thread) => thread.id !== id));
      queryClient.removeQueries({ queryKey: ["threads", id] });
      setDeleteTarget(null);
      if (id === activeId) {
        onNavigate?.();
        await navigate({ to: "/chat", replace: true });
      }
      await queryClient.invalidateQueries({ queryKey: ["threads"], exact: true });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Couldn't delete that chat.");
    } finally {
      setDeleting(false);
    }
  }

  async function handleSignOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/login", replace: true });
  }

  return (
    <div className="flex h-full flex-col bg-sidebar text-sidebar-foreground">
      <div className="flex items-center justify-between px-4 pt-5 pb-4">
        <Link to="/" onClick={onNavigate}>
          <MiraWordmark />
        </Link>
      </div>

      <div className="px-3">
        <Button asChild variant="glass" className="w-full justify-start rounded-xl">
          <Link to="/chat" preload={false} onClick={onNavigate}>
            <Plus /> New chat
          </Link>
        </Button>
      </div>

      <nav className="mt-5 flex-1 overflow-y-auto px-3 pb-4" aria-label="Chats">
        <p className="px-2 pb-2 text-xs font-medium tracking-wide text-muted-foreground uppercase">Chats</p>
        {isLoading && <p className="px-2 text-sm text-muted-foreground">Loading…</p>}
        {isError && <div className="px-2 text-sm text-muted-foreground">Couldn't load chats. <Button variant="ghost" size="sm" onClick={() => void refetch()}>Try again</Button></div>}
        {!isLoading && !isError && threads.length === 0 && (
          <p className="px-2 text-sm text-muted-foreground">Your chats will appear here.</p>
        )}
        {threads.length > 0 && (
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search chats…"
            aria-label="Search chats"
            className="mb-2 w-full rounded-lg border border-border bg-background/40 px-3 py-1.5 text-sm outline-none focus:ring-2 focus:ring-ring"
          />
        )}
        {search.trim() && shown.length === 0 && <p className="px-2 text-sm text-muted-foreground">No chats match.</p>}
        <ul className="grid gap-0.5">
          {shown.map((t) => (
            <li
              key={t.id}
              className={cn(
                "group relative flex items-center rounded-lg transition-colors hover:bg-sidebar-accent",
                t.id === activeId && "bg-sidebar-accent",
              )}
            >
              <Link
                to="/chat/$threadId"
                params={{ threadId: t.id }}
                onClick={onNavigate}
                className="flex min-w-0 flex-1 items-center gap-2 px-2 py-2 text-sm"
              >
                <MessageSquare className="size-3.5 shrink-0 text-muted-foreground" />
                <span className="truncate">{t.title}</span>
              </Link>
              <Button
                variant="ghost"
                size="icon-sm"
                type="button"
                aria-label={`Delete chat "${t.title}"`}
                onClick={() => setDeleteTarget(t)}
                className="mr-1 shrink-0 text-muted-foreground transition-opacity hover:text-destructive md:opacity-0 md:group-hover:opacity-100 focus-visible:opacity-100"
              >
                <Trash2 className="size-3.5" />
              </Button>
            </li>
          ))}
        </ul>
      </nav>

      <div className="grid gap-1 border-t border-sidebar-border p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
        <InstallAppButton variant="ghost" className="justify-start rounded-lg px-2 font-normal" />
        <Button asChild variant="glass" className="group my-1 h-auto justify-start gap-3 rounded-lg px-3 py-3 font-normal">
          <Link to="/chat/mira-1-1" onClick={onNavigate} activeProps={{ className: "border-primary/40 bg-sidebar-accent text-sidebar-accent-foreground" }}>
            <span className="flex size-9 shrink-0 items-center justify-center overflow-hidden rounded-lg">
              <img src={miraOneOneMark.url} alt="" className="size-full object-contain" />
            </span>
            <span className="flex min-w-0 flex-1 flex-col items-start gap-0.5">
              <span className="font-semibold">Mira 1.1</span>
              <span className="text-[11px] text-muted-foreground">Coming Jan 1, 2027</span>
            </span>
            <ArrowUpRight className="text-muted-foreground transition-colors group-hover:text-primary" />
          </Link>
        </Button>
        <Link
          to="/settings"
          onClick={onNavigate}
          className="flex items-center gap-2 rounded-lg px-2 py-2 text-sm transition-colors hover:bg-sidebar-accent"
        >
          <Settings className="size-4 text-muted-foreground" />
          <span className="flex-1">Settings</span>
        </Link>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button type="button" aria-label="Account menu"
              className="flex w-full items-center gap-2 rounded-xl px-2 py-1.5 text-left transition-colors hover:bg-sidebar-accent">
              <span className="flex size-7 shrink-0 items-center justify-center overflow-hidden rounded-full bg-gradient-mira text-xs font-semibold text-primary-foreground">
                {avatar ? <img src={avatar} alt="Your profile picture" className="size-full object-cover" /> : (name || email || "?").trim().charAt(0).toUpperCase()}
              </span>
              <span className="flex min-w-0 flex-1 items-center gap-1.5 text-xs text-muted-foreground">
                <span className="truncate">{name || email}</span>
                {isMiraFounder(email) ? <MiraFounderBadge className="size-3.5" /> : null}
              </span>
              <ChevronsUpDown className="size-3.5 text-muted-foreground" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent side="top" align="start" className="w-56">
            <DropdownMenuLabel className="truncate text-xs font-normal text-muted-foreground">{email}</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem asChild>
              <Link to="/settings" onClick={onNavigate}><UserRound /> Account settings</Link>
            </DropdownMenuItem>
            <DropdownMenuItem onSelect={() => void handleSignOut()}>
              <LogOut /> Sign out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
      <ConfirmDeleteDialog open={deleteTarget !== null} busy={deleting}
        title="Delete this chat?" description={`“${deleteTarget?.title ?? ""}” will be permanently removed. This can't be undone.`}
        confirmLabel="Delete chat" onOpenChange={(next) => { if (!next) setDeleteTarget(null); }}
        onConfirm={async () => { if (deleteTarget) await handleDelete(deleteTarget.id); }} />
    </div>
  );
}
