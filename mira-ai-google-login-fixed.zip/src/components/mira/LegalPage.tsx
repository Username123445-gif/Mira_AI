import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { MiraWordmark } from "@/components/mira/MiraLogo";
import { SiteFooter } from "@/components/mira/SiteFooter";

export function LegalPage({ title, updated, children }: { title: string; updated?: string; children: ReactNode }) {
  return (
    <div className="bg-night relative min-h-screen">
      <header className="mx-auto flex max-w-4xl items-center justify-between px-6 py-6">
        <Link to="/"><MiraWordmark /></Link>
      </header>
      <main className="mx-auto max-w-3xl px-6 pb-16">
        <h1 className="font-display text-5xl">{title}</h1>
        {updated && <p className="mt-2 text-sm text-muted-foreground">Last updated {updated}</p>}
        <div className="mt-8 space-y-4 text-sm leading-relaxed text-muted-foreground [&_p_a]:text-mira-ice [&_p_a]:underline [&_h2]:mt-8 [&_h2]:font-display [&_h2]:text-2xl [&_h2]:text-foreground [&_li]:ml-5 [&_li]:list-disc">
          {children}
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
