import { ArrowRight, Quote, Star } from "lucide-react";

import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";

const featured = [
  {
    quote:
      "Mira helped me break down my biology revision into a plan I could actually follow — my grades went up a full letter.",
    name: "Amara Osei",
    role: "University student",
  },
  {
    quote:
      "What used to take me two hours of brainstorming now takes fifteen minutes, and the ideas are genuinely better.",
    name: "Diego Ramírez",
    role: "Content creator",
  },
];

export function TestimonialsSpotlight() {
  return (
    <section className="animate-rise mt-24 w-full max-w-5xl" style={{ animationDelay: "560ms" }}>
      <div className="relative overflow-hidden rounded-3xl border border-border bg-card/40 p-8 backdrop-blur-sm transition-colors hover:border-mira-periwinkle/40 md:p-12">
        <span
          aria-hidden
          className="bg-gradient-mira pointer-events-none absolute -top-24 -left-16 size-64 rounded-full opacity-20 blur-3xl"
        />
        <span
          aria-hidden
          className="bg-gradient-mira pointer-events-none absolute -right-20 -bottom-24 size-72 rounded-full opacity-15 blur-3xl"
        />
        <span aria-hidden className="bg-stars pointer-events-none absolute inset-0 opacity-40" />
        <span aria-hidden className="bg-gradient-mira absolute inset-x-10 top-0 h-px opacity-60" />

        <div className="relative flex flex-col items-center text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-3 py-1 text-[11px] font-medium tracking-wide text-primary">
            <Star className="size-3 fill-current" />
            Loved by the Mira community
          </span>

          <h2 className="mt-4 font-display text-4xl leading-[1.05] tracking-tight md:text-5xl">
            Real people, <span className="text-gradient-mira italic">real results</span>
          </h2>

          <div className="mt-8 grid w-full gap-4 text-left md:grid-cols-2">
            {featured.map((t) => (
              <figure
                key={t.name}
                className="rounded-2xl border border-border bg-card/60 p-6 backdrop-blur-sm"
              >
                <Quote className="size-5 text-mira-periwinkle" />
                <blockquote className="mt-3 text-sm leading-relaxed text-foreground/90">
                  “{t.quote}”
                </blockquote>
                <figcaption className="mt-4">
                  <p className="font-display text-base">{t.name}</p>
                  <p className="text-xs text-muted-foreground">{t.role}</p>
                </figcaption>
              </figure>
            ))}
          </div>

          <div className="mt-7">
            <Button asChild type="button" variant="hero" size="xl">
              <Link to="/testimonials">
                Explore testimonials <ArrowRight />
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
