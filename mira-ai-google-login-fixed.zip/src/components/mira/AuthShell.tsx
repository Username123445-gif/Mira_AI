import { Link } from "@tanstack/react-router";
import { Eye, EyeOff, Loader2 } from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";

import { CopyrightNotice } from "@/components/mira/CopyrightNotice";
import { MiraLogo, MiraWordmark } from "@/components/mira/MiraLogo";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";

/** Shared layout for the Mira sign-in, sign-up and password pages. */
export function AuthShell({ title, subtitle, children, footer }: { title: string; subtitle: string; children: ReactNode; footer?: ReactNode }) {
  return (
    <div className="bg-night relative flex min-h-screen flex-col items-center px-4 py-8 sm:py-12">
      <Link to="/" className="mb-8 self-center sm:mb-12"><MiraWordmark /></Link>
      <div className="animate-rise w-full max-w-md">
        <div className="flex flex-col items-center text-center">
          <MiraLogo glow className="size-16 sm:size-20" />
          <h1 className="mt-6 font-display text-3xl sm:text-4xl">{title}</h1>
          <p className="mt-2 text-sm text-muted-foreground">{subtitle}</p>
        </div>
        <div className="mt-8 rounded-3xl border border-border bg-card/70 p-5 shadow-2xl backdrop-blur-md sm:p-7">{children}</div>
        {footer && <p className="mt-6 text-center text-sm text-muted-foreground">{footer}</p>}
        <CopyrightNotice className="mt-8" />
      </div>
    </div>
  );
}

export function PasswordInput({ id, value, onChange, autoComplete }: { id: string; value: string; onChange: (v: string) => void; autoComplete: string }) {
  const [show, setShow] = useState(false);
  return (
    <div className="relative">
      <Input id={id} type={show ? "text" : "password"} autoComplete={autoComplete} required minLength={8}
        value={value} onChange={(e) => onChange(e.target.value)} className="h-11 rounded-xl pr-11" />
      <button type="button" onClick={() => setShow((s) => !s)} aria-label={show ? "Hide password" : "Show password"}
        className="absolute inset-y-0 right-0 flex w-11 items-center justify-center text-muted-foreground hover:text-foreground">
        {show ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
      </button>
    </div>
  );
}

export function FormError({ message }: { message: string | null }) {
  if (!message) return null;
  return <p role="alert" className="rounded-xl border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">{message}</p>;
}

export function FormNotice({ message }: { message: string | null }) {
  if (!message) return null;
  return <p role="status" className="rounded-xl bg-accent px-3 py-2 text-sm text-accent-foreground">{message}</p>;
}

export function Spinner() {
  return <Loader2 className="size-4 animate-spin" aria-hidden="true" />;
}

/** Turns raw auth errors into friendly copy. */
export function friendlyAuthError(err: unknown): string {
  const msg = err instanceof Error ? err.message : String(err ?? "");
  if (/invalid login credentials/i.test(msg)) return "That email and password don't match. Please try again.";
  if (/email not confirmed/i.test(msg)) return "Please confirm your email first — check your inbox for the link.";
  if (/already registered|already exists/i.test(msg)) return "An account with this email already exists. Try signing in.";
  if (/rate limit|too many/i.test(msg)) return "Too many attempts. Please wait a minute and try again.";
  if (/password/i.test(msg) && /weak|pwned|leaked|short|characters/i.test(msg)) return "Please choose a stronger password (at least 8 characters).";
  return msg || "Something went wrong. Please try again.";
}

/** Sends already-signed-in visitors straight to chat. */
export function useRedirectIfSignedIn(goToChat: () => void) {
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => { if (data.session) goToChat(); });
    const { data } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "SIGNED_IN" && session) goToChat();
    });
    return () => data.subscription.unsubscribe();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
}
