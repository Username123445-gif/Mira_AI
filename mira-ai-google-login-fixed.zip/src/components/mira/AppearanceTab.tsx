import { Moon, Snowflake, Sun } from "lucide-react";
import { useEffect, useState } from "react";

import { Switch } from "@/components/ui/switch";
import { getSnow, getTheme, onAppearanceChange, setSnow, setTheme, type ThemeMode } from "@/lib/appearance";
import { cn } from "@/lib/utils";

const modes = [
  { value: "light" as ThemeMode, label: "Bright", icon: Sun },
  { value: "dark" as ThemeMode, label: "Dark", icon: Moon },
];

export function AppearanceTab() {
  const [theme, setThemeState] = useState<ThemeMode>("dark");
  const [snow, setSnowState] = useState(true);
  useEffect(() => {
    const sync = () => { setThemeState(getTheme()); setSnowState(getSnow()); };
    sync();
    return onAppearanceChange(sync);
  }, []);

  return (
    <div className="space-y-6">
      <section className="rounded-3xl border border-border bg-card/60 p-6">
        <h2 className="font-display text-2xl">Theme</h2>
        <p className="mt-1 text-sm text-muted-foreground">Choose a bright or dark look for Mira.</p>
        <div className="mt-4 grid grid-cols-2 gap-3 sm:max-w-md">
          {modes.map(({ value, label, icon: Icon }) => (
            <button
              key={value}
              type="button"
              aria-pressed={theme === value}
              onClick={() => setTheme(value)}
              className={cn(
                "flex items-center justify-center gap-2 rounded-2xl border px-4 py-4 text-sm font-medium transition-colors",
                theme === value ? "border-primary bg-primary/10 text-foreground" : "border-border hover:bg-accent",
              )}
            >
              <Icon className="size-4" /> {label}
            </button>
          ))}
        </div>
      </section>
      <section className="flex items-center justify-between gap-4 rounded-3xl border border-border bg-card/60 p-6">
        <div className="flex items-start gap-3">
          <Snowflake className="mt-1 size-5 text-primary" />
          <div>
            <h2 className="font-display text-2xl">Snowflakes</h2>
            <p className="mt-1 text-sm text-muted-foreground">Show falling snow during the Christmas season.</p>
          </div>
        </div>
        <Switch aria-label="Show snowflakes" checked={snow} onCheckedChange={setSnow} />
      </section>
    </div>
  );
}
