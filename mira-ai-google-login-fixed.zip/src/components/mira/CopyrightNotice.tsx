import { MiraLogo } from "@/components/mira/MiraLogo";

export function CopyrightNotice({ className = "" }: { className?: string }) {
  return (
    <div
      className={`relative overflow-hidden rounded-2xl border border-border bg-card/60 p-5 text-left backdrop-blur-sm ${className}`}
    >
      <span
        aria-hidden
        className="bg-gradient-mira pointer-events-none absolute -right-10 -top-10 size-32 rounded-full opacity-15 blur-3xl"
      />
      <div className="relative flex items-start gap-4">
        <MiraLogo className="mt-0.5 size-10" />
        <div className="min-w-0">
          <p className="font-display text-base leading-snug text-foreground">
            © 2026 <span className="text-gradient-mira font-semibold">MIRA AI</span>. All rights
            reserved.
          </p>
          <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
            MIRA AI is an independently developed AI platform. Its original human-authored content,
            creative contributions, branding, and other eligible intellectual property are protected
            by applicable intellectual property laws. Third-party materials and AI-generated content
            may have separate ownership and licensing terms.
          </p>
        </div>
      </div>
    </div>
  );
}
