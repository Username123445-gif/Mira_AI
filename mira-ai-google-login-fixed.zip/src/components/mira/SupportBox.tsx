import { LifeBuoy, Mail } from "lucide-react";

import { MiraLogo } from "@/components/mira/MiraLogo";

export const SUPPORT_EMAIL = "mikhailharris14@gmail.com";

export function SupportBox({ className = "" }: { className?: string }) {
  return (
    <div
      className={`relative overflow-hidden rounded-2xl border border-border bg-card/60 p-5 text-left backdrop-blur-sm ${className}`}
    >
      <span
        aria-hidden
        className="bg-gradient-mira pointer-events-none absolute -left-10 -bottom-10 size-32 rounded-full opacity-15 blur-3xl"
      />
      <div className="relative flex items-start gap-4">
        <span className="relative mt-0.5 inline-flex size-10 shrink-0 items-center justify-center">
          <MiraLogo className="size-10" />
          <LifeBuoy className="absolute -bottom-1 -right-1 size-4 rounded-full bg-card p-0.5 text-primary" />
        </span>
        <div className="min-w-0">
          <p className="font-display text-base leading-snug text-foreground">Need a hand?</p>
          <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">
            Questions, bugs, billing or ideas — the Mira team reads every message and replies as
            fast as we can.
          </p>
          <a
            href={`mailto:${SUPPORT_EMAIL}?subject=Mira%20AI%20support`}
            className="mt-3 inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-4 py-2 text-xs font-medium text-primary transition-colors hover:bg-primary/20"
          >
            <Mail className="size-3.5" />
            Contact support
          </a>
        </div>
      </div>
    </div>
  );
}
