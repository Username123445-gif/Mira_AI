import { useChat } from "@ai-sdk/react";
import { ConfirmDeleteDialog } from "@/components/mira/ConfirmDeleteDialog";
import { useQueryClient } from "@tanstack/react-query";
import { useRouteContext } from "@tanstack/react-router";
import { DefaultChatTransport, type UIMessage } from "ai";
import { CheckIcon, CopyIcon, DownloadIcon, GlobeIcon, ImageIcon, Loader2Icon, MicIcon, RotateCcwIcon, SparklesIcon, Trash2Icon, SquareIcon, ThumbsDownIcon, ThumbsUpIcon } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";

import {
  Conversation,
  ConversationContent,
  ConversationEmptyState,
  ConversationScrollButton,
} from "@/components/ai-elements/conversation";
import {
  Message,
  MessageAction,
  MessageActions,
  MessageContent,
  MessageResponse,
} from "@/components/ai-elements/message";
import {
  PromptInput,
  PromptInputFooter,
  PromptInputSubmit,
  PromptInputTextarea,
  type PromptInputMessage,
} from "@/components/ai-elements/prompt-input";
import { Reasoning, ReasoningContent, ReasoningTrigger } from "@/components/ai-elements/reasoning";
import { Shimmer } from "@/components/ai-elements/shimmer";
import { MIRA_VERSION } from "@/lib/version";
import { Source, Sources, SourcesContent, SourcesTrigger } from "@/components/ai-elements/sources";
import { Tool, ToolContent, ToolHeader, ToolInput, ToolOutput } from "@/components/ai-elements/tool";
import { MiraLogo } from "@/components/mira/MiraLogo";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { listGeneratedImages, saveGeneratedImage } from "@/lib/images";
import { recordWav } from "@/lib/record-wav";
import { streamImage } from "@/lib/stream-image";
import { transcribeRecording } from "@/lib/voice-input";
import { threadMessagesQuery } from "@/lib/threads";
import { notifyMira } from "@/lib/notifications";

type GeneratedImage = { id: string; prompt: string; src?: string; final: boolean; error?: string };

const SUGGESTIONS = [
  "Help me plan a relaxing weekend",
  "Explain how compound interest works",
  "Write a friendly follow-up email",
  "Give me 5 ideas for a quick dinner",
];

function messageText(m: UIMessage) {
  return m.parts.map((p) => (p.type === "text" ? p.text : "")).join("");
}

function uniqueSources(m: UIMessage) {
  const seen = new Map<string, string>();
  for (const p of m.parts) {
    if (p.type === "source-url" && !seen.has(p.url)) seen.set(p.url, p.title || hostOf(p.url));
  }
  return [...seen].slice(0, 8).map(([url, title]) => ({ url, title }));
}

function hostOf(url: string) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return url;
  }
}

function searchQuery(input: unknown): string | null {
  if (!input || typeof input !== "object") return null;
  const action = (input as { action?: { query?: unknown } }).action;
  return typeof action?.query === "string" ? action.query : null;
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <MessageAction
      tooltip={copied ? "Copied" : "Copy"}
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(text);
          setCopied(true);
          setTimeout(() => setCopied(false), 1500);
        } catch {
          toast.error("Couldn't copy that reply. You can select and copy the text instead.");
        }
      }}
    >
      {copied ? <CheckIcon /> : <CopyIcon />}
    </MessageAction>
  );
}

function RateButtons({ threadId, messageId, value, onChange }: { threadId: string; messageId: string; value: number; onChange: (v: number) => void }) {
  async function rate(v: number) {
    const next = value === v ? 0 : v;
    const prev = value;
    onChange(next);
    const { data } = await supabase.auth.getUser();
    const uid = data.user?.id;
    if (!uid) return onChange(prev);
    const { error } = next === 0
      ? await supabase.from("message_ratings").delete().eq("user_id", uid).eq("message_id", messageId)
      : await supabase.from("message_ratings").upsert({ user_id: uid, message_id: messageId, thread_id: threadId, rating: next }, { onConflict: "user_id,message_id" });
    if (error) {
      onChange(prev);
      toast.error("Couldn't save your rating.");
    } else if (next) toast.success(next > 0 ? "Thanks for the feedback!" : "Thanks — we'll use this to improve Mira.");
  }
  return (
    <>
      <MessageAction tooltip="Good answer" onClick={() => rate(1)} className={value === 1 ? "text-primary" : ""}>
        <ThumbsUpIcon className={value === 1 ? "fill-current" : ""} />
      </MessageAction>
      <MessageAction tooltip="Bad answer" onClick={() => rate(-1)} className={value === -1 ? "text-primary" : ""}>
        <ThumbsDownIcon className={value === -1 ? "fill-current" : ""} />
      </MessageAction>
    </>
  );
}

export function ChatWindow({ threadId, initialMessages }: { threadId: string; initialMessages: UIMessage[] }) {
  const { user } = useRouteContext({ from: "/_authenticated" });
  const queryClient = useQueryClient();
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [draft, setDraft] = useState("");
  const imageController = useRef<AbortController | null>(null);
  const [generatingImage, setGeneratingImage] = useState(false);
  const [ratings, setRatings] = useState<Record<string, number>>({});

  useEffect(() => {
    let alive = true;
    void supabase
      .from("message_ratings")
      .select("message_id, rating")
      .eq("thread_id", threadId)
      .then(({ data }) => {
        if (alive && data) setRatings(Object.fromEntries(data.map((r) => [r.message_id, r.rating])));
      });
    return () => {
      alive = false;
    };
  }, [threadId]);

  const transport = useMemo(
    () =>
      new DefaultChatTransport({
        api: "/api/chat",
        prepareSendMessagesRequest: async ({ id, messages }) => {
          const { data } = await supabase.auth.getSession();
          const token = data.session?.access_token;
          return {
            headers: token ? { Authorization: `Bearer ${token}` } : {},
            body: { threadId: id, message: messages[messages.length - 1] },
          };
        },
      }),
    [],
  );

  const { messages, sendMessage, regenerate, setMessages, status, stop, error } = useChat({
    id: threadId,
    messages: initialMessages,
    transport,
    onError: (err) => {
      toast.error(err.message || "Mira couldn't reply. Please try again.");
    },
    onFinish: ({ messages: finalMessages, isAbort, isError, isDisconnect }) => {
      queryClient.setQueryData(threadMessagesQuery(threadId).queryKey, {
        exists: true,
        messages: finalMessages,
      });
      queryClient.invalidateQueries({ queryKey: ["threads"], exact: true });
      if (!isAbort && !isError && !isDisconnect) void notifyMira(user.id, threadId, "answer");
    },
  });

  const [clearOpen, setClearOpen] = useState(false);
  const [clearing, setClearing] = useState(false);
  const [imageMode, setImageMode] = useState(false);
  const [images, setImages] = useState<GeneratedImage[]>([]);
  useEffect(() => {
    let cancelled = false;
    setImages([]);
    listGeneratedImages(threadId)
      .then((saved) => {
        if (cancelled) return;
        setImages((list) => [
          ...saved.map((i) => ({ id: i.id, prompt: i.prompt, src: i.url, final: true })),
          ...list,
        ]);
      })
      .catch(() => { if (!cancelled) toast.error("Couldn't load this chat's saved images. Please refresh to try again."); });
    return () => {
      cancelled = true;
    };
  }, [threadId]);
  const imageBusy = generatingImage;
  const busy = status === "submitted" || status === "streaming" || imageBusy;

  async function createImage(prompt: string) {
    if (imageController.current) return;
    const controller = new AbortController();
    imageController.current = controller;
    setGeneratingImage(true);
    const id = crypto.randomUUID();
    let finishedImage: string | undefined;
    const update = (patch: Partial<GeneratedImage>) =>
      setImages((list) => list.map((i) => (i.id === id ? { ...i, ...patch } : i)));
    setImages((list) => [...list, { id, prompt, final: false }]);
    try {
      const { data } = await supabase.auth.getSession();
      const token = data.session?.access_token;
      await streamImage(
        "/api/generate-image",
        { prompt },
        (src, final) => {
          update({ src, final });
          if (final) finishedImage = src;
        },
        controller.signal,
        token ? { Authorization: `Bearer ${token}` } : {},
      );
      if (finishedImage) {
        void notifyMira(user.id, threadId, "image");
        try {
          await saveGeneratedImage(finishedImage, prompt, threadId);
          queryClient.invalidateQueries({ queryKey: ["threads"], exact: true });
        } catch {
          toast.error("Image created, but it couldn't be saved to your gallery.");
        }
      }
    } catch (err) {
      if (controller.signal.aborted) {
        update({ error: "Image generation stopped." });
        return;
      }
      const raw = err instanceof Error ? err.message : "";
      const msg = raw.includes(" 402")
        ? "Mira is out of AI credits right now. Please try again later."
        : raw.includes(" 429")
          ? "Mira is busy right now. Please try again in a moment."
          : raw.includes(" 401")
            ? "Please sign in again to create images."
            : "Mira couldn't create that image. Try a different description.";
      update({ error: msg });
      toast.error(msg);
    } finally {
      if (imageController.current === controller) imageController.current = null;
      setGeneratingImage(false);
    }
  }

  const [voice, setVoice] = useState<"idle" | "starting" | "recording" | "transcribing">("idle");
  const voiceStarting = useRef(false);
  const mounted = useRef(true);
  const recorderRef = useRef<{ stop: () => Promise<File> } | null>(null);
  const voiceTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  async function startVoice() {
    if (busy || voice !== "idle" || voiceStarting.current) return;
    if (!navigator.mediaDevices?.getUserMedia) {
      toast.error("Voice input isn't supported in this browser.");
      return;
    }
    voiceStarting.current = true;
    setVoice("starting");
    try {
      const recorder = await recordWav();
      if (!mounted.current) {
        await recorder.stop().catch(() => {});
        return;
      }
      recorderRef.current = recorder;
      setVoice("recording");
      // Keep clips comfortably under the upload limit.
      voiceTimer.current = setTimeout(() => void stopVoice(), 120_000);
    } catch {
      if (mounted.current) {
        setVoice("idle");
        toast.error("Mira couldn't use your microphone. Check your browser's microphone permission.");
      }
    } finally {
      voiceStarting.current = false;
    }
  }

  async function stopVoice() {
    if (voiceTimer.current) clearTimeout(voiceTimer.current);
    const rec = recorderRef.current;
    recorderRef.current = null;
    if (!rec) return;
    setVoice("transcribing");
    const before = textareaRef.current?.value.trim() ?? "";
    const prefix = before ? `${before} ` : "";
    try {
      const file = await rec.stop();
      const { data } = await supabase.auth.getSession();
      const token = data.session?.access_token;
      const text = await transcribeRecording(file, token ? { Authorization: `Bearer ${token}` } : {}, (t) =>
        { if (mounted.current) setDraft(prefix + t); },
      );
      if (!mounted.current) return;
      if (!text) toast.error("Didn't catch anything. Please try again.");
      setDraft(prefix + text);
    } catch (err) {
      if (mounted.current) {
        setDraft(before);
        toast.error(err instanceof Error ? err.message : "Couldn't understand that recording.");
      }
    } finally {
      if (mounted.current) {
        setVoice("idle");
        textareaRef.current?.focus();
      }
    }
  }

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
      imageController.current?.abort();
      if (voiceTimer.current) clearTimeout(voiceTimer.current);
      void recorderRef.current?.stop().catch(() => {});
    };
  }, []);

  useEffect(() => {
    if (!busy && voice === "idle" && window.matchMedia("(pointer: fine)").matches) textareaRef.current?.focus();
  }, [busy, voice, threadId]);

  function send(text: string) {
    const trimmed = text.trim();
    if (!trimmed || busy || voice !== "idle") return;
    setDraft("");
    if (imageMode) {
      void createImage(trimmed);
      requestAnimationFrame(() => textareaRef.current?.focus());
      return;
    }
    void sendMessage({ text: trimmed });
    // Thread title is set on the first message; refresh the list shortly after.
    if (messages.length === 0) {
      setTimeout(() => queryClient.invalidateQueries({ queryKey: ["threads"], exact: true }), 1200);
    }
    requestAnimationFrame(() => textareaRef.current?.focus());
  }

  function handleSubmit(message: PromptInputMessage) {
    if (busy || voice !== "idle") throw new Error("Please wait for the current response.");
    send(message.text);
  }

  const last = messages[messages.length - 1];
  const waitingForFirstToken =
    status === "submitted" || (status === "streaming" && last?.role === "assistant" && last.parts.length === 0);

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <Conversation className="min-h-0">
        <ConversationContent className="mx-auto w-full max-w-3xl gap-8 px-4 py-8 md:px-6">
          {messages.length === 0 && images.length === 0 ? (
            <ConversationEmptyState className="h-auto min-h-0 gap-2 p-0 md:min-h-[60vh]">
              <MiraLogo glow className="animate-float size-16 shrink-0 md:size-24" />
              <div className="mt-3 inline-flex items-center gap-2 rounded-full border border-border bg-card/60 px-3.5 py-1 text-[11px] font-medium text-muted-foreground md:mt-5">
                <SparklesIcon className="size-3 text-mira-periwinkle" />
                Mira · {MIRA_VERSION}
              </div>
              <h1 className="mt-3 font-display text-3xl md:mt-4 md:text-5xl">
                How can I <span className="text-gradient-mira italic">help</span> today?
              </h1>
              <p className="mt-2 text-sm text-muted-foreground">
                Ask Mira anything — big plans or small questions. She can search the live web for fresh answers.
              </p>
              <div className="mt-4 flex max-w-xl flex-wrap justify-center gap-2 md:mt-6">
                {SUGGESTIONS.map((s) => (
                  <Button
                    key={s}
                    variant="glass"
                    size="sm"
                    className="rounded-full transition-colors hover:border-mira-periwinkle/40"
                    onClick={() => send(s)}
                    disabled={busy || voice !== "idle"}
                  >
                    {s}
                  </Button>
                ))}
              </div>
            </ConversationEmptyState>
          ) : (
            messages.map((message, mi) => {
              const isLast = mi === messages.length - 1;
              const streamingThis = isLast && status === "streaming" && message.role === "assistant";
              const text = messageText(message);
              return (
                <Message key={message.id} from={message.role}>
                  {message.role === "assistant" && (
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <MiraLogo className="size-5" /> Mira
                    </div>
                  )}
                  <MessageContent
                    className={
                      message.role === "user"
                        ? "group-[.is-user]:rounded-2xl group-[.is-user]:rounded-br-md group-[.is-user]:bg-user-bubble group-[.is-user]:text-user-bubble-foreground"
                        : "w-full text-[15px] leading-relaxed"
                    }
                  >
                    {message.parts.map((part, pi) => {
                      if (part.type === "text") {
                        return message.role === "user" ? (
                          <p key={pi} className="whitespace-pre-wrap">
                            {part.text}
                          </p>
                        ) : (
                          <MessageResponse key={pi} isAnimating={streamingThis}>
                            {part.text}
                          </MessageResponse>
                        );
                      }
                      if (part.type === "tool-web_search") {
                        const running = part.state === "input-streaming" || part.state === "input-available";
                        const query = searchQuery(part.input);
                        return (
                          <Tool key={pi} defaultOpen={false} className="mb-0 rounded-xl bg-card/60">
                            <ToolHeader
                              type={part.type}
                              state={part.state}
                              icon={<GlobeIcon className="size-4 text-mira-periwinkle" />}
                              title={
                                running
                                  ? "Searching the web…"
                                  : query
                                    ? `Searched the web: “${query}”`
                                    : "Searched the web"
                              }
                            />
                            <ToolContent>
                              <ToolInput input={part.input} />
                              <ToolOutput output={part.output} errorText={part.errorText} />
                            </ToolContent>
                          </Tool>
                        );
                      }
                      if (part.type === "reasoning" && part.text.trim()) {
                        const reasoningStreaming = streamingThis && pi === message.parts.length - 1;
                        return (
                          <Reasoning key={pi} isStreaming={reasoningStreaming} defaultOpen={false}>
                            <ReasoningTrigger />
                            <ReasoningContent>{part.text}</ReasoningContent>
                          </Reasoning>
                        );
                      }
                      return null;
                    })}
                  </MessageContent>
                  {message.role === "assistant" && uniqueSources(message).length > 0 && (
                    <Sources className="mb-0">
                      <SourcesTrigger count={uniqueSources(message).length} />
                      <SourcesContent>
                        {uniqueSources(message).map((src) => (
                          <Source key={src.url} href={src.url} title={src.title} />
                        ))}
                      </SourcesContent>
                    </Sources>
                  )}
                  {message.role === "assistant" && text && !streamingThis && (
                    <MessageActions className="-ml-2 opacity-60 transition-opacity hover:opacity-100">
                      <CopyButton text={text} />
                      {message.id === last?.id && !busy && (
                        <MessageAction tooltip="Regenerate" label="Regenerate response" onClick={() => void regenerate()}>
                          <RotateCcwIcon />
                        </MessageAction>
                      )}
                      <RateButtons
                        threadId={threadId}
                        messageId={message.id}
                        value={ratings[message.id] ?? 0}
                        onChange={(v) => setRatings((r) => ({ ...r, [message.id]: v }))}
                      />
                    </MessageActions>
                  )}
                </Message>
              );
            })
          )}

          {messages.length + images.length > 0 &&
            images.map((img) => (
              <Message key={img.id} from="assistant">
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <MiraLogo className="size-5" /> Mira · Image
                </div>
                <MessageContent className="w-full">
                  <p className="text-sm text-muted-foreground">“{img.prompt}”</p>
                  {img.error ? (
                    <p className="rounded-xl border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm">{img.error}</p>
                  ) : img.src ? (
                    <img
                      src={img.src}
                      alt={img.prompt}
                      className={`aspect-square w-full max-w-md rounded-2xl border border-border object-cover transition-[filter] duration-700 ${img.final ? "blur-0" : "blur-2xl"}`}
                    />
                  ) : (
                    <div className="flex aspect-square w-full max-w-md items-center justify-center rounded-2xl border border-border bg-card/60">
                      <Shimmer duration={1.5}>Mira is painting…</Shimmer>
                    </div>
                  )}
                </MessageContent>
                {img.final && img.src && (
                  <MessageActions className="-ml-2 opacity-60 transition-opacity hover:opacity-100">
                    <MessageAction tooltip="Download" onClick={() => {
                      const a = document.createElement("a");
                      if (!img.src) return;
                      a.href = img.src;
                      a.download = "mira-image.png";
                      a.click();
                    }}>
                      <DownloadIcon />
                    </MessageAction>
                  </MessageActions>
                )}
              </Message>
            ))}

          {waitingForFirstToken && (
            <div className="flex items-center gap-2 text-sm">
              <MiraLogo className="size-5 animate-pulse" />
              <Shimmer duration={1.5}>Mira is thinking…</Shimmer>
            </div>
          )}

          {error && !busy && (
            <div className="rounded-xl border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm text-foreground">
              <p>{error.message || "Mira couldn't reply. Please try again."}</p>
              {last?.role === "user" && <Button variant="glass" size="sm" className="mt-3" onClick={() => void sendMessage({
                parts: last.parts, messageId: last.id,
              })}><RotateCcwIcon /> Try again</Button>}
            </div>
          )}
        </ConversationContent>
        <ConversationScrollButton />
      </Conversation>

      <div className="mx-auto w-full max-w-3xl px-4 pb-4 md:px-6 md:pb-6">
        {messages.length > 0 && !busy && (
          <div className="mb-2 flex justify-end">
            <Button variant="ghost" size="sm" type="button" className="text-muted-foreground" onClick={() => setClearOpen(true)}>
              <Trash2Icon /> Clear chat
            </Button>
          </div>
        )}
        <ConfirmDeleteDialog open={clearOpen} busy={clearing} title="Clear this chat?"
          description="All messages in this chat will be removed so you can start fresh. This can't be undone."
          confirmLabel="Clear chat" onOpenChange={setClearOpen}
          onConfirm={async () => {
            setClearing(true);
            const { error: clearError } = await supabase.from("messages").delete().eq("thread_id", threadId);
            setClearing(false);
            if (clearError) { toast.error("Couldn't clear this chat. Please try again."); return; }
            setMessages([]);
            queryClient.setQueryData(threadMessagesQuery(threadId).queryKey, { exists: true, messages: [] });
            setClearOpen(false);
            toast.success("Chat cleared.");
          }} />
        <PromptInput
          onSubmit={handleSubmit}
          className="shadow-composer rounded-2xl bg-card transition-shadow focus-within:ring-1 focus-within:ring-mira-periwinkle/50"
        >
          <PromptInputTextarea
            ref={textareaRef}
            value={draft}
            onChange={(event) => setDraft(event.target.value)}
            readOnly={voice === "starting" || voice === "recording" || voice === "transcribing"}
            placeholder={imageMode ? "Describe an image for Mira to create…" : "Message Mira…"}
            className="min-h-14 px-4 text-[15px]"
          />
          <PromptInputFooter className="justify-between px-3 pb-3">
            <Button
              type="button"
              variant={imageMode ? "hero" : "glass"}
              size="sm"
              aria-pressed={imageMode}
              disabled={busy || voice !== "idle"}
              className="rounded-full"
              onClick={() => setImageMode((v) => !v)}
            >
              <ImageIcon className="size-4" /> Image
            </Button>
            <div className="flex items-center gap-2">
              <Button
                type="button"
                variant={voice === "recording" ? "hero" : "glass"}
                size="icon-sm"
                className={`rounded-full ${voice === "recording" ? "animate-pulse" : ""}`}
                aria-label={voice === "recording" ? "Stop recording" : "Speak your message"}
                aria-pressed={voice === "recording"}
                disabled={busy || voice === "starting" || voice === "transcribing"}
                onClick={() => (voice === "recording" ? void stopVoice() : void startVoice())}
              >
                {voice === "recording" ? <SquareIcon /> : voice === "starting" || voice === "transcribing" ? <Loader2Icon className="animate-spin" /> : <MicIcon />}
              </Button>
            <PromptInputSubmit
              status={imageBusy ? "submitted" : status}
              onStop={() => { if (imageBusy) imageController.current?.abort(); else void stop(); }}
              disabled={!busy && (!draft.trim() || voice !== "idle")}
              className="bg-gradient-mira rounded-full text-primary-foreground hover:brightness-110"
            />
            </div>
          </PromptInputFooter>
        </PromptInput>
        <p className="mt-3 text-center text-xs font-medium text-muted-foreground">
          {voice === "recording" ? "Listening… tap the square when you're done." : voice === "transcribing" ? "Turning your voice into text…" : "Powered by Mira AI"}
        </p>
        <p className="mt-2 text-center text-[11px] text-muted-foreground">
          Mira can make mistakes. Double-check important info.
        </p>
      </div>
    </div>
  );
}
