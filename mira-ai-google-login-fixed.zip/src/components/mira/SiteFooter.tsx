import { Link } from "@tanstack/react-router";

import { CopyrightNotice } from "@/components/mira/CopyrightNotice";
import { SupportBox } from "@/components/mira/SupportBox";

export function SiteFooter() {
  return (
    <footer className="relative z-10 px-6 pb-8 text-center text-xs text-muted-foreground">
      <div className="mx-auto mb-5 grid max-w-3xl gap-4 sm:grid-cols-2">
        <SupportBox />
        <CopyrightNotice />
      </div>
      <nav className="mb-3 flex flex-wrap justify-center gap-4">
        <Link to="/whats-new" className="hover:text-foreground">What's new</Link>
        <Link to="/testimonials" className="hover:text-foreground">Testimonials</Link>
        <Link to="/terms" className="hover:text-foreground">Terms</Link>
        <Link to="/privacy" className="hover:text-foreground">Privacy</Link>
        <Link to="/refunds" className="hover:text-foreground">Refunds</Link>
      </nav>
      © {new Date().getFullYear()} Mira AI
    </footer>
  );
}
