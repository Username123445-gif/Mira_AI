import { Download, ImageIcon, Trash2 } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { ConfirmDeleteDialog } from "@/components/mira/ConfirmDeleteDialog";
import { deleteGeneratedImage, listGeneratedImages, type SavedImage } from "@/lib/images";

export function ImageGallery() {
  const [images, setImages] = useState<SavedImage[] | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<SavedImage | null>(null);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    listGeneratedImages()
      .then(setImages)
      .catch(() => {
        setImages([]);
        toast.error("Couldn't load your images.");
      });
  }, []);

  async function remove(img: SavedImage) {
    setDeleting(true);
    try {
      await deleteGeneratedImage(img);
      setImages((l) => l?.filter((i) => i.id !== img.id) ?? null);
      setDeleteTarget(null);
      toast.success("Image deleted");
    } catch {
      toast.error("Couldn't delete that image.");
    } finally {
      setDeleting(false);
    }
  }

  async function download(img: SavedImage) {
    try {
      const response = await fetch(img.url);
      if (!response.ok) throw new Error("Download failed");
      const blob = await response.blob();
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "mira-image.png";
      a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    } catch {
      toast.error("Couldn't download this image. Refresh the gallery and try again.");
    }
  }

  if (images === null) return <p className="text-sm text-muted-foreground">Loading your images…</p>;
  if (!images.length)
    return (
      <div className="rounded-2xl border border-border bg-card/60 p-10 text-center">
        <ImageIcon className="mx-auto size-8 text-mira-periwinkle" />
        <p className="mt-3 font-display text-xl">No images yet</p>
        <p className="mt-1 text-sm text-muted-foreground">Turn on Image in chat and describe something — it'll be saved here.</p>
      </div>
    );

  return (
    <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
      {images.map((img) => (
        <figure key={img.id} className="group overflow-hidden rounded-2xl border border-border bg-card/60">
          <img src={img.url} alt={img.prompt} loading="lazy" className="aspect-square w-full object-cover" />
          <figcaption className="flex items-start gap-1 p-2">
            <p className="line-clamp-2 flex-1 text-xs text-muted-foreground">{img.prompt}</p>
            <Button size="icon" variant="ghost" className="size-7" aria-label="Download image" onClick={() => void download(img)}>
              <Download className="size-3.5" />
            </Button>
            <Button size="icon" variant="ghost" className="size-7" aria-label="Delete image" onClick={() => setDeleteTarget(img)}>
              <Trash2 className="size-3.5" />
            </Button>
          </figcaption>
        </figure>
      ))}
      <ConfirmDeleteDialog open={deleteTarget !== null} busy={deleting} title="Delete this image?"
        description="This image will be removed from your gallery and its chat. This can't be undone."
        confirmLabel="Delete image" onOpenChange={(next) => { if (!next) setDeleteTarget(null); }}
        onConfirm={async () => { if (deleteTarget) await remove(deleteTarget); }} />
    </div>
  );
}
