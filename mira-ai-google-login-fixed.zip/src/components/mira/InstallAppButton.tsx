import { useState } from "react";
import { Download, Share, SquarePlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useInstallPrompt } from "@/hooks/use-install-prompt";
import { cn } from "@/lib/utils";

export function InstallAppButton({ className, variant = "glass" }: { className?: string; variant?: "glass" | "ghost" }) {
  const { canPrompt, showIosHelp, install } = useInstallPrompt();
  const [open, setOpen] = useState(false);
  if (!canPrompt && !showIosHelp) return null;
  return (
    <>
      <Button
        type="button"
        variant={variant}
        className={cn("rounded-full", className)}
        onClick={() => (canPrompt ? void install() : setOpen(true))}
      >
        <Download className="size-4" />
        Install app
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="font-display">Install Mira AI on your iPhone</DialogTitle>
            <DialogDescription>Add Mira to your home screen to open it like an app.</DialogDescription>
          </DialogHeader>
          <ol className="grid gap-3 text-sm">
            <li className="flex items-center gap-3"><Share className="size-5 text-primary" /> Tap the Share button in Safari.</li>
            <li className="flex items-center gap-3"><SquarePlus className="size-5 text-primary" /> Choose “Add to Home Screen”, then tap Add.</li>
          </ol>
        </DialogContent>
      </Dialog>
    </>
  );
}
