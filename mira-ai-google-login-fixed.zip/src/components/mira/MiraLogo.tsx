import badge from "@/assets/mira-verified-badge.png.asset.json";
import logo from "@/assets/mira-logo.png.asset.json";
import { cn } from "@/lib/utils";
import { MIRA_VERSION } from "@/lib/version";

export function MiraLogo({ className, glow = false }: { className?: string; glow?: boolean }) {
  return (
    <span className={cn("relative inline-flex shrink-0 items-center justify-center", className)}>
      {glow && (
        <span
          aria-hidden
          className="bg-gradient-mira absolute inset-[12%] animate-glow rounded-full blur-2xl"
        />
      )}
      <img src={logo.url} alt="Mira AI" className="relative size-full object-contain" />
    </span>
  );
}

export function MiraVerifiedBadge({ className }: { className?: string }) {
  return (
    <img
      src={badge.url}
      alt="Verified"
      title="Verified — this is the official Mira AI"
      aria-label="Verified"
      className={cn("size-[0.72em] shrink-0 object-contain drop-shadow-mira", className)}
    />
  );
}

export function MiraWordmark({ className }: { className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-2", className)}>
      <MiraLogo className="size-7" />
      <span className="font-display text-xl tracking-tight">
        Mira{" "}
        <span className="text-gradient-mira font-semibold italic tracking-wider drop-shadow-mira">
          AI
        </span>
        <MiraVerifiedBadge className="ml-[0.18em] inline-block align-[-0.04em]" />
      </span>
      <span className="rounded-full border border-primary/40 bg-primary/10 px-2 py-0.5 text-[10px] font-medium tracking-wide text-primary">
        {MIRA_VERSION}
      </span>
    </span>
  );
}
