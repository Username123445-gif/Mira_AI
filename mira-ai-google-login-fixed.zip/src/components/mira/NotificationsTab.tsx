import { Bell, BellOff, Loader2 } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { NOTIFICATION_EVENT, notificationPermission, notificationsEnabled, notifyMira, setNotificationsEnabled } from "@/lib/notifications";

export function NotificationsTab({ userId }: { userId: string }) {
  const [enabled, setEnabled] = useState(false);
  const [permission, setPermission] = useState<NotificationPermission | "unsupported">("default");
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    const sync = () => { setEnabled(notificationsEnabled(userId)); setPermission(notificationPermission()); };
    sync();
    window.addEventListener(NOTIFICATION_EVENT, sync);
    window.addEventListener("storage", sync);
    window.addEventListener("focus", sync);
    return () => {
      window.removeEventListener(NOTIFICATION_EVENT, sync);
      window.removeEventListener("storage", sync);
      window.removeEventListener("focus", sync);
    };
  }, [userId]);

  async function toggle(on: boolean) {
    setBusy(true);
    try {
      if (on) {
        const current = notificationPermission();
        if (current === "unsupported") return;
        const result = current === "default" ? await Notification.requestPermission() : current;
        setPermission(result);
        if (result !== "granted") {
          setNotificationsEnabled(userId, false);
          toast.error("Notifications weren't allowed. You can change this in your browser's site settings.");
          return;
        }
      }
      setNotificationsEnabled(userId, on);
      setEnabled(on);
      toast.success(on ? "Notifications turned on." : "Notifications turned off.");
    } catch { toast.error("Couldn't save your notification preference. Please try again."); }
    finally { setBusy(false); }
  }

  return (
    <div className="max-w-2xl space-y-6">
      <section className="border-b border-border pb-6">
        <div className="flex items-start justify-between gap-5">
          <div className="flex items-start gap-3">
            {enabled && permission === "granted" ? <Bell className="mt-1 size-5 shrink-0 text-primary" /> : <BellOff className="mt-1 size-5 shrink-0 text-muted-foreground" />}
            <div>
              <Label htmlFor="mira-notifications" className="font-display text-2xl font-normal">Notifications</Label>
              <p className="mt-2 text-sm text-muted-foreground">Replies and finished images</p>
            </div>
          </div>
          <Switch id="mira-notifications" aria-label="Mira notifications" checked={enabled && permission === "granted"} disabled={busy || permission === "unsupported" || permission === "denied"} onCheckedChange={(on) => void toggle(on)} />
        </div>
        <p className="mt-4 text-sm text-muted-foreground">For this account on this device. Alerts arrive while Mira is open and you're in another tab or window, not after the app is closed. Chat content stays private.</p>
        {permission === "unsupported" && <p role="status" className="mt-3 text-sm text-muted-foreground">Notifications aren't available here. Try the published Mira app in a supported browser; on iPhone, add Mira to your Home Screen first.</p>}
        {permission === "denied" && <p role="status" className="mt-3 text-sm text-destructive">Notifications are blocked. Allow them in your browser's site settings, then return to Mira.</p>}
      </section>
      {enabled && permission === "granted" && <Button variant="glass" disabled={busy} onClick={async () => {
        setBusy(true);
        try {
          const delivered = await notifyMira(userId, "test", "answer", true);
          if (!delivered) toast.error("Couldn't show an alert. Check your browser and device notification settings.");
        } finally { setBusy(false); }
      }}>{busy ? <Loader2 className="size-4 animate-spin" /> : <Bell className="size-4" />} Send test notification</Button>}
    </div>
  );
}