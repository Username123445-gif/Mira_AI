import { useRef } from "react";

import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";

/** Destructive operations stay open until success and cannot be repeated while pending. */
export function ConfirmDeleteDialog({ open, busy, title, description, confirmLabel, onOpenChange, onConfirm }: {
  open: boolean;
  busy: boolean;
  title: string;
  description: string;
  confirmLabel: string;
  onOpenChange: (open: boolean) => void;
  onConfirm: () => Promise<void>;
}) {
  const pending = useRef(false);
  return (
    <Dialog open={open} onOpenChange={(next) => { if (!busy && !pending.current) onOpenChange(next); }}>
      <DialogContent className="max-h-[85dvh] w-[calc(100%-2rem)] overflow-y-auto rounded-lg">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription className="break-words">{description}</DialogDescription>
        </DialogHeader>
        <DialogFooter className="gap-2">
          <Button variant="glass" disabled={busy} onClick={() => { if (!pending.current) onOpenChange(false); }}>Cancel</Button>
          <Button variant="destructive" disabled={busy} onClick={async () => {
            if (pending.current) return;
            pending.current = true;
            try { await onConfirm(); } finally { pending.current = false; }
          }}>{busy ? "Deleting…" : confirmLabel}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}