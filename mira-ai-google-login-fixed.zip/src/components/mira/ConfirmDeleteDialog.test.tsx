import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";

import { ConfirmDeleteDialog } from "./ConfirmDeleteDialog";

afterEach(cleanup);
const defaults = { open: true, busy: false, title: "Delete?", description: "Permanent removal", confirmLabel: "Delete" };

describe("Destructive confirmations", () => {
  it("cancels without performing the destructive operation", () => {
    const onConfirm = vi.fn().mockResolvedValue(undefined);
    const onOpenChange = vi.fn();
    render(<ConfirmDeleteDialog {...defaults} onConfirm={onConfirm} onOpenChange={onOpenChange} />);
    fireEvent.click(screen.getByRole("button", { name: "Cancel" }));
    expect(onOpenChange).toHaveBeenCalledWith(false);
    expect(onConfirm).not.toHaveBeenCalled();
  });
  it("blocks duplicate operations and dismissal while confirmation is pending", async () => {
    let finish: (() => void) | undefined;
    const onConfirm = vi.fn(() => new Promise<void>((resolve) => { finish = resolve; }));
    const onOpenChange = vi.fn();
    render(<ConfirmDeleteDialog {...defaults} onConfirm={onConfirm} onOpenChange={onOpenChange} />);
    const confirm = screen.getByRole("button", { name: "Delete" });
    fireEvent.click(confirm);
    fireEvent.click(confirm);
    fireEvent.click(screen.getByRole("button", { name: "Close" }));
    fireEvent.click(screen.getByRole("button", { name: "Cancel" }));
    expect(onConfirm).toHaveBeenCalledTimes(1);
    expect(onOpenChange).not.toHaveBeenCalled();
    finish?.();
    await waitFor(() => expect(onConfirm).toHaveBeenCalledTimes(1));
  });
  it("does not invoke confirmation while the operation is busy", () => {
    const onConfirm = vi.fn().mockResolvedValue(undefined);
    render(<ConfirmDeleteDialog {...defaults} busy onConfirm={onConfirm} onOpenChange={vi.fn()} />);
    fireEvent.click(screen.getByRole("button", { name: "Deleting…" }));
    expect(onConfirm).not.toHaveBeenCalled();
  });
});