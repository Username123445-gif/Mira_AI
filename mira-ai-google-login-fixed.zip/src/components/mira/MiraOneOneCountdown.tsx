import { useEffect, useState } from "react";

import miraOneOneMark from "@/assets/mira-1-1-mark-hd.png.asset.json";
import { MIRA_ONE_ONE_RELEASE_LABEL, miraOneOneCountdown } from "@/lib/mira-1-1";

const units = [
  { key: "days", label: "days" },
  { key: "hours", label: "hrs" },
  { key: "minutes", label: "min" },
  { key: "seconds", label: "sec" },
] as const;

function pad(value: number) {
  return String(value).padStart(2, "0");
}

/**
 * Slim bar across the top of the screen counting down to the Mira AI 1.1 launch.
 * The clock only starts after hydration, so the server and the first client
 * render always agree.
 */
export function MiraOneOneCountdown() {
  const [now, setNow] = useState<Date | null>(null);

  useEffect(() => {
    const tick = () => setNow(new Date());
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);

  const countdown = now ? miraOneOneCountdown(now) : null;
  if (countdown?.isLive) return null;

  const label = countdown
    ? `${countdown.days} days, ${countdown.hours} hours, ${countdown.minutes} minutes and ${countdown.seconds} seconds until Mira AI 1.1 launches`
    : "Counting down to the Mira AI 1.1 launch";

  return (
    <div className="relative z-20 shrink-0 border-b border-border bg-card/70 backdrop-blur-sm">
      <div className="mx-auto flex w-full max-w-6xl flex-wrap items-center justify-center gap-x-3 gap-y-1 px-4 py-2">
        <span className="flex items-center gap-2 text-xs font-medium">
          <img src={miraOneOneMark.url} alt="" className="size-5 shrink-0 rounded-sm object-contain" aria-hidden />
          <span>
            Mira AI <span className="text-gradient-mira font-semibold">1.1</span>
            <span className="hidden text-muted-foreground sm:inline">
              {" "}
              · launches {MIRA_ONE_ONE_RELEASE_LABEL}
            </span>
          </span>
        </span>

        <span role="timer" aria-label={label} className="flex items-center gap-1.5">
          {units.map((unit) => (
            <span
              key={unit.key}
              className="flex items-baseline gap-1 rounded-md border border-border bg-background/60 px-1.5 py-0.5"
            >
              <span className="font-mono text-xs font-semibold tabular-nums">
                {countdown ? pad(countdown[unit.key]) : "--"}
              </span>
              <span className="text-[10px] uppercase tracking-wide text-muted-foreground">
                {unit.label}
              </span>
            </span>
          ))}
        </span>
      </div>
    </div>
  );
}
