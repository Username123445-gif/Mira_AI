import { Link } from "@tanstack/react-router";
import { Star } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { accountName } from "@/lib/account-name";

type Review = { id: string; is_mine: boolean; display_name: string; rating: number; comment: string; created_at: string };

function Stars({ value, onPick, size = "size-5" }: { value: number; onPick?: (n: number) => void; size?: string }) {
  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map((n) => (
        <button
          key={n}
          type="button"
          disabled={!onPick}
          onClick={() => onPick?.(n)}
          aria-label={`${n} star${n > 1 ? "s" : ""}`}
          className="disabled:cursor-default"
        >
          <Star className={`${size} ${n <= value ? "fill-primary text-primary" : "text-muted-foreground/50"}`} />
        </button>
      ))}
    </div>
  );
}

export function ReviewsSection() {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [userId, setUserId] = useState<string | null>(null);
  const [name, setName] = useState("Mira user");
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");
  const [saving, setSaving] = useState(false);

  async function load() {
    const { data } = await supabase.rpc("list_public_reviews");
    setReviews(data ?? []);
    return data ?? [];
  }

  useEffect(() => {
    void (async () => {
      const list = await load();
      const { data } = await supabase.auth.getUser();
      if (!data.user) return;
      setUserId(data.user.id);
      setName(accountName(data.user.user_metadata ?? {}) ?? "Mira user");
      const mine = list.find((r) => r.is_mine);
      if (mine) {
        setRating(mine.rating);
        setComment(mine.comment);
      }
    })();
  }, []);

  async function submit() {
    if (!userId || rating < 1) return;
    setSaving(true);
    const { error } = await supabase
      .from("reviews")
      .upsert({ user_id: userId, rating, comment: comment.trim().slice(0, 500), display_name: name.slice(0, 60), updated_at: new Date().toISOString() }, { onConflict: "user_id" });
    setSaving(false);
    if (error) {
      toast.error("Couldn't save your rating. Please try again.");
      return;
    }
    toast.success("Thanks for rating Mira!");
    void load();
  }

  const avg = reviews.length ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length : 0;

  return (
    <section className="mt-20">
      <div className="text-center">
        <h2 className="font-display text-3xl md:text-4xl">
          Rate <span className="text-gradient-mira italic">Mira</span>
        </h2>
        <div className="mt-4 flex items-center justify-center gap-3">
          <Stars value={Math.round(avg)} />
          <span className="text-sm text-muted-foreground">
            {reviews.length ? `${avg.toFixed(1)} out of 5 · ${reviews.length} rating${reviews.length > 1 ? "s" : ""}` : "No ratings yet — be the first!"}
          </span>
        </div>
      </div>

      <div className="mx-auto mt-8 max-w-xl rounded-2xl border border-border bg-card/40 p-6 backdrop-blur-sm">
        {userId ? (
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">Your rating</p>
            <Stars value={rating} onPick={setRating} size="size-7" />
            <Textarea value={comment} onChange={(e) => setComment(e.target.value)} maxLength={500} placeholder="Tell others what you think of Mira (optional)" />
            <Button variant="hero" disabled={rating < 1 || saving} onClick={submit}>
              {saving ? "Saving…" : "Submit rating"}
            </Button>
          </div>
        ) : (
          <div className="text-center">
            <p className="text-sm text-muted-foreground">Sign in to rate Mira.</p>
            <Button asChild variant="hero" className="mt-4">
              <Link to="/login">Sign in to rate</Link>
            </Button>
          </div>
        )}
      </div>

      {reviews.some((r) => r.comment) && (
        <div className="mt-8 grid gap-4 sm:grid-cols-2">
          {reviews.filter((r) => r.comment).map((r) => (
            <figure key={r.id} className="rounded-2xl border border-border bg-card/40 p-5">
              <Stars value={r.rating} size="size-4" />
              <blockquote className="mt-3 text-sm text-foreground/90">“{r.comment}”</blockquote>
              <figcaption className="mt-3 text-xs text-muted-foreground">{r.display_name}</figcaption>
            </figure>
          ))}
        </div>
      )}
    </section>
  );
}
