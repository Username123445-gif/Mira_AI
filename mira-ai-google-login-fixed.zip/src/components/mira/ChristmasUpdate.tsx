import { Gift, Snowflake, TreePine } from "lucide-react";
import { useEffect, useState } from "react";

import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { isChristmasUpdateActive } from "@/lib/christmas";

const KEY = "mira-christmas-2026-dismissed";

const items = [
  { icon: TreePine, title: "Festive Mira", text: "Falling snow and holiday colors across Mira all season." },
  { icon: Gift, title: "Gift ideas & holiday help", text: "Ask Mira for gift ideas, recipes, cards and holiday plans." },
  { icon: Snowflake, title: "Mira 1.1 is almost here", text: "Watch the countdown — Mira AI 1.1 arrives January 1, 2027." },
];

/** Christmas update popup, shown once per visit until January 1, 2027. */
export function ChristmasUpdate() {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    if (!isChristmasUpdateActive(new Date())) return;
    try {
      if (sessionStorage.getItem(KEY)) return;
    } catch {}
    setOpen(true);
  }, []);

  const close = (next: boolean) => {
    setOpen(next);
    if (!next) {
      try { sessionStorage.setItem(KEY, "1"); } catch {}
    }
  };

  return (
    <Dialog open={open} onOpenChange={close}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="mx-auto mb-2 flex size-14 items-center justify-center rounded-2xl bg-gradient-mira text-primary-foreground shadow-lg">
            <TreePine className="size-7" />
          </div>
          <DialogTitle className="text-center font-display text-2xl">
            Merry Christmas from <span className="text-gradient-mira">Mira AI</span>
          </DialogTitle>
          <DialogDescription className="text-center">
            Our Christmas update is here — enjoy it through the holidays until January 1, 2027.
          </DialogDescription>
        </DialogHeader>
        <ul className="space-y-3">
          {items.map(({ icon: Icon, title, text }) => (
            <li key={title} className="flex gap-3 rounded-xl border border-border bg-card/60 p-3">
              <Icon className="mt-0.5 size-5 shrink-0 text-primary" />
              <div>
                <p className="text-sm font-semibold">{title}</p>
                <p className="text-xs text-muted-foreground">{text}</p>
              </div>
            </li>
          ))}
        </ul>
        <DialogFooter>
          <Button variant="hero" className="w-full" onClick={() => close(false)}>Happy holidays!</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
